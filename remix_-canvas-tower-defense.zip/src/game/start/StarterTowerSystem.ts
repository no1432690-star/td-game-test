export const StarterTowerSystem = {
  active: false,
  choices: [] as string[],

  start(towerPool: string[]) {
    this.active = true;
    this.choices = [];
    for (let i = 0; i < 3; i++) {
      const rand = towerPool[Math.floor(Math.random() * towerPool.length)];
      this.choices.push(rand);
    }
  },

  choose(index: number) {
    const tower = this.choices[index];
    this.active = false;
    this.choices = [];
    return tower;
  }
};
