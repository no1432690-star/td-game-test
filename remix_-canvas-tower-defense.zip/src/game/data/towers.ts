export type TowerStats = {
  damage: number
  range: number
  cooldown: number
  projectileSpeed?: number
}

export type TowerDefinition = {
  name: string
  stats: TowerStats
  targeting?: string
  projectile?: {
    type: string
    splashRadius?: number
    pierce?: number
  }
}

export const TOWER_DATA: Record<string, TowerDefinition> = {

  archer: {
    name: "Archer Tower",
    stats: {
      damage: 10,
      range: 160,
      cooldown: 0.8,
      projectileSpeed: 420
    },
    targeting: "first",
    projectile: {
      type: "arrow",
      pierce: 1
    }
  },

  bomber: {
    name: "Bomb Tower",
    stats: {
      damage: 40,
      range: 130,
      cooldown: 2.4
    },
    projectile: {
      type: "bomb",
      splashRadius: 70
    }
  },

  frost: {
    name: "Frost Tower",
    stats: {
      damage: 10,
      range: 100,
      cooldown: 1.2
    },
    projectile: {
      type: "frost"
    }
  },

  tesla: {
    name: "Tesla Tower",
    stats: {
      damage: 5,
      range: 150,
      cooldown: 1.4
    },
    projectile: {
      type: "lightning"
    }
  }

}
