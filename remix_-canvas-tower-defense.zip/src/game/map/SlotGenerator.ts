import { getSlotCost } from "./SlotEconomy";
import { densifyPath } from "./PathUtils";

export type Point = {
  x: number;
  y: number;
};

export type TowerSlot = {
  x: number;
  y: number;
  tier: number;
  unlocked: boolean;
  unlockCost: number;
};

function previousGenerateSlotsFromPath(path: Point[]): TowerSlot[] {
  const slots: TowerSlot[] = [];

  const SLOT_TARGET = 50;
  const DIST_FROM_PATH = 90;
  const MIN_SLOT_DIST = 70;

  function dist(a: Point, b: Point) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function tooClose(p: Point) {
    for (const s of slots) {
      if (dist(p, s) < MIN_SLOT_DIST) return true;
    }
    return false;
  }

  for (let i = 0; i < path.length; i++) {
    const p = path[i];

    const left = {
      x: p.x - DIST_FROM_PATH,
      y: p.y
    };

    const right = {
      x: p.x + DIST_FROM_PATH,
      y: p.y
    };

    if (!tooClose(left)) {
      slots.push({
        x: left.x,
        y: left.y,
        tier: 1,
        unlocked: true,
        unlockCost: 0
      });
    }

    if (!tooClose(right)) {
      slots.push({
        x: right.x,
        y: right.y,
        tier: 1,
        unlocked: true,
        unlockCost: 0
      });
    }

    if (slots.length >= SLOT_TARGET) break;
  }

  return slots.slice(0, SLOT_TARGET);
}

export function generateSlotsFromPath(path: Point[]): TowerSlot[] {
  if (path.length > 1) {
    path = densifyPath(path, 120);
  }

  if (path.length < 10) {
    return previousGenerateSlotsFromPath(path);
  }

  const slots: TowerSlot[] = [];

  const TARGET = 50;
  const DIST = 120;
  const MIN_DIST = 65;
  const mapWidth = 1600;
  const mapHeight = 900;

  function dist(a: Point, b: Point) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function tooClose(p: Point) {
    for (const s of slots) {
      if (dist(p, s) < MIN_DIST) return true;
    }
    return false;
  }

  function insideMap(p: Point) {
    return (
      p.x > 40 &&
      p.y > 40 &&
      p.x < mapWidth - 40 &&
      p.y < mapHeight - 40
    );
  }

  function midpoint(a: Point, b: Point) {
    return {
      x: (a.x + b.x) / 2,
      y: (a.y + b.y) / 2
    };
  }

  function normal(dx: number, dy: number) {
    const len = Math.hypot(dx, dy);
    if (len === 0) return { x: 0, y: 0 };
    return {
      x: -dy / len,
      y: dx / len
    };
  }

  for (let i = 0; i < path.length - 1; i++) {
    const p1 = path[i];
    const p2 = path[i + 1];

    const mid = midpoint(p1, p2);

    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    const n = normal(dx, dy);

    const left = {
      x: mid.x + n.x * DIST,
      y: mid.y + n.y * DIST
    };

    const right = {
      x: mid.x - n.x * DIST,
      y: mid.y - n.y * DIST
    };

    if (insideMap(left) && !tooClose(left)) {
      slots.push({
        x: left.x,
        y: left.y,
        tier: 1,
        unlocked: true,
        unlockCost: 0
      });
    }

    if (insideMap(right) && !tooClose(right)) {
      slots.push({
        x: right.x,
        y: right.y,
        tier: 1,
        unlocked: true,
        unlockCost: 0
      });
    }
  }

  const cornerSlots: TowerSlot[] = [];

  for (let i = 1; i < path.length - 1; i++) {
    const p0 = path[i - 1];
    const p1 = path[i];
    const p2 = path[i + 1];

    const v1x = p1.x - p0.x;
    const v1y = p1.y - p0.y;

    const v2x = p2.x - p1.x;
    const v2y = p2.y - p1.y;

    const dot = v1x * v2x + v1y * v2y;

    const mag1 = Math.hypot(v1x, v1y);
    const mag2 = Math.hypot(v2x, v2y);

    if (mag1 === 0 || mag2 === 0) continue;

    let cosTheta = dot / (mag1 * mag2);
    if (cosTheta > 1) cosTheta = 1;
    if (cosTheta < -1) cosTheta = -1;

    const angle = Math.acos(cosTheta);

    if (angle > 0.5) {
      const n = normal(v2x, v2y);

      const choke = {
        x: p1.x + n.x * (DIST * 0.7),
        y: p1.y + n.y * (DIST * 0.7)
      };

      if (insideMap(choke)) {
        cornerSlots.push({
          x: choke.x,
          y: choke.y,
          tier: 3,
          unlocked: false,
          unlockCost: 0
        });
      }
    }
  }

  for (const c of cornerSlots) {
    if (!tooClose(c)) {
      slots.push(c);
    }
  }

  slots.splice(TARGET);

  for (let i = 0; i < slots.length; i++) {
    const cost = getSlotCost(i);

    slots[i].unlockCost = cost;
    slots[i].unlocked = i < 30;

    if (i >= 40) {
      slots[i].tier = 3;
    } else if (i >= 30) {
      slots[i].tier = 2;
    } else {
      slots[i].tier = 1;
    }
  }

  return slots;
}
