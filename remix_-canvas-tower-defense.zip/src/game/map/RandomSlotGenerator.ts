export function generateRandomSlots(path: any[], mapWidth: number, mapHeight: number, slotCount = 50) {

  const slots: any[] = [];

  const MIN_SLOT_DISTANCE = 70;
  const PATH_SAFE_DISTANCE = 85;
  const MAX_ATTEMPTS = 5000;

  function distance(a: any, b: any) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function pointToSegmentDistance(p: any, v: any, w: any) {

    const l2 =
      (v.x - w.x) * (v.x - w.x) +
      (v.y - w.y) * (v.y - w.y);

    if (l2 === 0) return distance(p, v);

    let t =
      ((p.x - v.x) * (w.x - v.x) +
        (p.y - v.y) * (w.y - v.y)) / l2;

    t = Math.max(0, Math.min(1, t));

    const proj = {
      x: v.x + t * (w.x - v.x),
      y: v.y + t * (w.y - v.y)
    };

    return distance(p, proj);
  }

  function nearPath(point: any) {

    for (let i = 0; i < path.length - 1; i++) {

      const dist = pointToSegmentDistance(
        point,
        path[i],
        path[i + 1]
      );

      if (dist < PATH_SAFE_DISTANCE) {
        return true;
      }
    }

    return false;
  }

  function nearSlot(point: any) {

    for (const s of slots) {

      if (distance(point, s) < MIN_SLOT_DISTANCE) {
        return true;
      }
    }

    return false;
  }

  let attempts = 0;

  while (slots.length < slotCount && attempts < MAX_ATTEMPTS) {

    attempts++;

    const point = {
      x: 100 + Math.random() * (mapWidth - 200),
      y: 100 + Math.random() * (mapHeight - 200)
    };

    if (nearPath(point)) continue;
    if (nearSlot(point)) continue;

    slots.push({
      x: point.x,
      y: point.y,
      tier: 1,
      unlocked: true,
      unlockCost: 0
    });
  }

  return slots;
}
