import { getSlotCost } from "./SlotEconomy";

export function initializeSlots(slots: any[]) {
  return slots.map((s, i) => {
    s.unlockCost = getSlotCost(i);
    s.unlocked = i < 30;

    if (i >= 40) {
      s.tier = 3;
    } else if (i >= 30) {
      s.tier = 2;
    } else {
      s.tier = 1;
    }

    return s;
  });
}
