export function getSlotCost(index: number) {
  if (index < 30) return 0;

  const tierIndex = index - 30;

  return Math.floor(10000 * Math.pow(1.35, tierIndex));
}
