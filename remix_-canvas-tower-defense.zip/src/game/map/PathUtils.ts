export type Point = {
  x: number;
  y: number;
};

export function densifyPath(path: Point[], spacing: number): Point[] {
  if (!path || path.length < 2) return path;

  const result: Point[] = [];

  for (let i = 0; i < path.length - 1; i++) {
    const a = path[i];
    const b = path[i + 1];

    result.push(a);

    const dx = b.x - a.x;
    const dy = b.y - a.y;

    const dist = Math.hypot(dx, dy);
    const steps = Math.floor(dist / spacing);

    for (let s = 1; s < steps; s++) {
      const t = s / steps;
      result.push({
        x: a.x + dx * t,
        y: a.y + dy * t
      });
    }
  }

  result.push(path[path.length - 1]);

  return result;
}
