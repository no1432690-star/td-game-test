export const DebugSpeed = {
  enabled: false,
  multiplier: 6,

  toggle() {
    this.enabled = !this.enabled;
  },

  apply(dt: number) {
    if (this.enabled) {
      return dt * this.multiplier;
    }
    return dt;
  }
};
