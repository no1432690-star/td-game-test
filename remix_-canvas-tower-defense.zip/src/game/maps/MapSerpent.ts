import { GameMap } from "./MapTypes";

export const MAP_SERPENT: GameMap = {
  name: 'MAP_SERPENT',
  spawn: { x: 100, y: 450 },
  base: { x: 1500, y: 450 },
  path: [
    { x: 100, y: 450 },
    { x: 1400, y: 450 },
    { x: 1400, y: 200 },
    { x: 200, y: 200 },
    { x: 200, y: 700 },
    { x: 1400, y: 700 },
    { x: 1500, y: 450 }
  ],
  slots: [
    { x: 200, y: 350, tier: 1 }, { x: 260, y: 360, tier: 1 }, { x: 320, y: 340, tier: 1 },
    { x: 380, y: 360, tier: 1 }, { x: 440, y: 340, tier: 1 }, { x: 500, y: 360, tier: 1 },
    { x: 560, y: 340, tier: 1 }, { x: 620, y: 360, tier: 1 }, { x: 680, y: 340, tier: 1 },
    { x: 740, y: 360, tier: 1 }, { x: 800, y: 340, tier: 1 }, { x: 860, y: 360, tier: 1 },
    { x: 920, y: 340, tier: 1 }, { x: 980, y: 360, tier: 1 }, { x: 1040, y: 340, tier: 1 },
    { x: 1100, y: 360, tier: 1 }, { x: 1160, y: 340, tier: 1 }, { x: 1220, y: 360, tier: 1 },
    { x: 1280, y: 340, tier: 1 }, { x: 1340, y: 360, tier: 1 },
    { x: 400, y: 500, tier: 1 }, { x: 460, y: 520, tier: 1 }, { x: 520, y: 500, tier: 1 },
    { x: 580, y: 520, tier: 1 }, { x: 640, y: 500, tier: 1 }, { x: 700, y: 520, tier: 1 },
    { x: 760, y: 500, tier: 1 }, { x: 820, y: 520, tier: 1 }, { x: 880, y: 500, tier: 1 },
    { x: 940, y: 520, tier: 1 },
    { x: 1000, y: 500, tier: 1 }, { x: 1060, y: 520, tier: 1 }, { x: 1120, y: 500, tier: 1 },
    { x: 1180, y: 520, tier: 1 }, { x: 1240, y: 500, tier: 1 },
    { x: 300, y: 600, tier: 1 }, { x: 360, y: 620, tier: 1 }, { x: 420, y: 600, tier: 1 },
    { x: 480, y: 620, tier: 1 }, { x: 540, y: 600, tier: 1 },
    { x: 900, y: 600, tier: 1 }, { x: 960, y: 620, tier: 1 }, { x: 1020, y: 600, tier: 1 },
    { x: 1080, y: 620, tier: 1 }, { x: 1140, y: 600, tier: 1 },
    { x: 700, y: 250, tier: 1 }, { x: 760, y: 250, tier: 1 }, { x: 820, y: 250, tier: 1 }
  ]
};
