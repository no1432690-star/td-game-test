export type TowerSlot = {
  x: number;
  y: number;
  tier: number;
  unlocked?: boolean;
  unlockCost?: number;
};

export type GameMap = {
  name: string;
  spawn: { x: number; y: number };
  base: { x: number; y: number };
  path: { x: number; y: number }[];
  slots: TowerSlot[];
};
