import { MAP_SERPENT } from "./MapSerpent";
import { MAP_ARENA } from "./MapArena";
import { generateRandomSlots } from "../map/RandomSlotGenerator";
import { initializeSlots } from "../map/SlotInitializer";

export function loadRandomMap() {
  const MAPS = [MAP_SERPENT, MAP_ARENA];
  const map = MAPS[Math.floor(Math.random() * MAPS.length)];
  
  if (map.path && (!map.slots || map.slots.length === 0)) {
    console.log('[MapManager] Generating random slots for map:', map.name);
    map.slots = generateRandomSlots(
      map.path,
      (map as any).width || 1600,
      (map as any).height || 900,
      50
    );
  } else {
    console.log('[MapManager] Using predefined slots for map:', map.name, '(', map.slots?.length, 'slots )');
  }
  
  if (map.slots && map.slots.length > 0) {
    map.slots = initializeSlots(map.slots);
  }
  
  return map;
}
