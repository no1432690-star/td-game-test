import { GameMap } from "./MapTypes";

export const MAP_ARENA: GameMap = {
  name: 'MAP_ARENA',
  spawn: { x: 100, y: 450 },
  base: { x: 1500, y: 450 },
  path: [
    { x: 100, y: 450 },
    { x: 400, y: 450 },
    { x: 400, y: 200 },
    { x: 1200, y: 200 },
    { x: 1200, y: 700 },
    { x: 400, y: 700 },
    { x: 400, y: 450 },
    { x: 1500, y: 450 }
  ],
  slots: [
    { x: 650, y: 350, tier: 1 }, { x: 720, y: 350, tier: 1 }, { x: 790, y: 350, tier: 1 },
    { x: 860, y: 350, tier: 1 }, { x: 930, y: 350, tier: 1 }, { x: 1000, y: 350, tier: 1 },
    { x: 650, y: 420, tier: 1 }, { x: 720, y: 420, tier: 1 }, { x: 790, y: 420, tier: 1 },
    { x: 860, y: 420, tier: 1 }, { x: 930, y: 420, tier: 1 }, { x: 1000, y: 420, tier: 1 },
    { x: 650, y: 490, tier: 1 }, { x: 720, y: 490, tier: 1 }, { x: 790, y: 490, tier: 1 },
    { x: 860, y: 490, tier: 1 }, { x: 930, y: 490, tier: 1 }, { x: 1000, y: 490, tier: 1 },
    { x: 400, y: 350, tier: 1 }, { x: 450, y: 420, tier: 1 }, { x: 400, y: 490, tier: 1 },
    { x: 1200, y: 350, tier: 1 }, { x: 1150, y: 420, tier: 1 }, { x: 1200, y: 490, tier: 1 },
    { x: 250, y: 300, tier: 1 }, { x: 300, y: 250, tier: 1 }, { x: 350, y: 300, tier: 1 },
    { x: 1400, y: 300, tier: 1 }, { x: 1350, y: 250, tier: 1 }, { x: 1300, y: 300, tier: 1 },
    { x: 250, y: 600, tier: 1 }, { x: 300, y: 650, tier: 1 }, { x: 350, y: 600, tier: 1 },
    { x: 1400, y: 600, tier: 1 }, { x: 1350, y: 650, tier: 1 }, { x: 1300, y: 600, tier: 1 },
    { x: 500, y: 600, tier: 1 }, { x: 550, y: 650, tier: 1 }, { x: 600, y: 600, tier: 1 },
    { x: 1000, y: 600, tier: 1 }, { x: 1050, y: 650, tier: 1 }, { x: 1100, y: 600, tier: 1 },
    { x: 700, y: 150, tier: 1 }, { x: 760, y: 150, tier: 1 }, { x: 820, y: 150, tier: 1 }
  ]
};
