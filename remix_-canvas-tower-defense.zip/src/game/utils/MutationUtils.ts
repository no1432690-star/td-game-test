export function getMutationChance(wave: number): number {
  if (wave < 50) return 0;

  const bossIndex = Math.floor(wave / 5);
  const startBossIndex = 10; // wave 50

  const chance = 0.01 * (bossIndex - startBossIndex + 1);
  return Math.min(0.10, Math.max(0, chance));
}
