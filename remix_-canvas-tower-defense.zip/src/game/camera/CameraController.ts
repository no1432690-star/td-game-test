import { Camera } from "./Camera";

export class CameraController {
  camera: Camera;

  dragging: boolean = false;
  lastX: number = 0;
  lastY: number = 0;

  constructor(camera: Camera) {
    this.camera = camera;
  }

  onMouseDown(x: number, y: number) {
    this.dragging = true;
    this.lastX = x;
    this.lastY = y;
  }

  onMouseUp() {
    this.dragging = false;
  }

  onMouseMove(x: number, y: number) {
    if (!this.dragging) return;

    const dx = (x - this.lastX) / this.camera.zoom;
    const dy = (y - this.lastY) / this.camera.zoom;

    this.camera.pan(-dx, -dy);

    this.lastX = x;
    this.lastY = y;
  }

  onWheel(delta: number) {
    const zoomChange = delta > 0 ? -0.1 : 0.1;

    this.camera.setZoom(this.camera.zoom + zoomChange);
  }
}
