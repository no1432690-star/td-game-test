export class Camera {
  x: number = 0;
  y: number = 0;

  zoom: number = 1;

  minZoom: number = 0.6;
  maxZoom: number = 1.6;

  viewportWidth: number;
  viewportHeight: number;

  worldWidth: number;
  worldHeight: number;

  constructor(viewW: number, viewH: number, worldW: number, worldH: number) {
    this.viewportWidth = viewW;
    this.viewportHeight = viewH;

    this.worldWidth = worldW;
    this.worldHeight = worldH;
  }

  setZoom(value: number) {
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, value));
    this.clamp();
  }

  pan(dx: number, dy: number) {
    this.x += dx;
    this.y += dy;
    this.clamp();
  }

  clamp() {
    const maxX = this.worldWidth - this.viewportWidth / this.zoom;
    const maxY = this.worldHeight - this.viewportHeight / this.zoom;

    this.x = Math.max(0, Math.min(this.x, maxX));
    this.y = Math.max(0, Math.min(this.y, maxY));
  }

  worldToScreen(x: number, y: number) {
    return {
      x: (x - this.x) * this.zoom,
      y: (y - this.y) * this.zoom
    };
  }

  screenToWorld(x: number, y: number) {
    return {
      x: (x / this.zoom) + this.x,
      y: (y / this.zoom) + this.y
    };
  }
}
