export type Rarity =
  | "Common"
  | "Uncommon"
  | "Rare"
  | "Gold"
  | "Legendary"
  | "Quality";

export const RARITY_WEIGHT: Record<Rarity, number> = {
  Common: 55,
  Uncommon: 25,
  Rare: 12,
  Gold: 5,
  Legendary: 2.5,
  Quality: 0.5,
};
