export const GOLD_HP_RATIO = 0.08;

export const TOWER_TYPES = {
  Archer: {
    damage: 25,
    range: 150,
    rewardable: true
  },
  Bomber: {
    damage: 40,
    range: 120,
    rewardable: true
  },
  Frost: {
    damage: 10,
    range: 100,
    rewardable: true
  },
  CursedArcher: {
    damage: 30,
    range: 150,
    mutationOnly: true,
    rewardable: false
  },
  Tesla: {
    damage: 8,
    range: 150,
    attackSpeed: 0.8,
    chainTargets: 2,
    rewardable: true
  }
};
