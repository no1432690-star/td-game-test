import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';
import { UpgradeManager } from '../systems/UpgradeManager';
import { applyDamage } from '../systems/BuffSystem';
import { ArtifactEventBus } from '../systems/artifactEventBus';
import { TowerEventSystem } from '../systems/tower/TowerEventSystem';
import { projectilePool } from '../pools/ProjectilePool';

export class Bomber extends Tower {
  private enemiesRef: Enemy[];

  constructor(x: number, y: number, enemies: Enemy[]) {
    super("bomber", x, y);
    this.baseCost = 100;
    this.enemiesRef = enemies;
    this.baseSplashRadius = 80;
    this.maxVisualProjectiles = 2;
    this.recalculateFinalStats();
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, enemies?: Enemy[], activeProjectilesCount: number = 0): Projectile | null {
    ArtifactEventBus.emit("onAttack", {
      attacker: this,
      target
    });
    const damage = this.getCalculatedDamage(runModifiers, target, upgradeManager);
    
    // Calculate AoE parameters
    let aoeRadius = this.flatSplashRadius > 0 ? this.flatSplashRadius : 80;
    let splashDamageMultiplier = this.flatSplashDamage > 0 ? this.flatSplashDamage : 1.0;
    
    if (runModifiers?.explosionRadiusBonus) {
      aoeRadius *= (1 + runModifiers.explosionRadiusBonus);
    }

    if (upgradeManager) {
      const radiusBonus = upgradeManager.getClassMultiplier("Bomber", "radius") - 1.0;
      const splashDamageBonus = upgradeManager.getClassMultiplier("Bomber", "splash_damage") - 1.0;
      aoeRadius *= (1 + radiusBonus);
      splashDamageMultiplier += splashDamageBonus;
    }

    if (this.level >= 3) {
      aoeRadius = Math.max(aoeRadius, 120 * (upgradeManager ? upgradeManager.getClassMultiplier("Bomber", "radius") : 1.0)); // Level 3 Special: Huge Explosion
    }

    // Apply damage instantly
    if (this.corruptionType === 0 && Math.random() <= 0.2) { // CorruptionType.UnstableCore
      // Missed
    } else {
      // Determine if mini or double explosion
      const isMini = runModifiers?.miniExplosionChance ? Math.random() < runModifiers.miniExplosionChance : false;
      const isDouble = runModifiers?.doubleExplosionChance ? Math.random() < runModifiers.doubleExplosionChance : false;
      
      const applyExplosion = (mini: boolean) => {
        const radius = mini ? aoeRadius * 0.5 : aoeRadius;
        const baseDamage = (mini ? damage * 0.5 : damage) * splashDamageMultiplier;
        
        TowerEventSystem.emit('onExplosion', {
          sourceTower: this,
          position: target.position.clone(),
          enemies: this.enemiesRef,
          towerType: this.constructor.name
        });

        for (const enemy of this.enemiesRef) {
          if (!enemy.active) continue;
          
          if (target.position.dist(enemy.position) <= radius) {
            let finalDamage = baseDamage;
            
            if (enemy.effects.some(e => e.type === 'slow') && runModifiers?.crossBomberFrost) {
              if (enemy.health / enemy.maxHealth < 0.2) {
                finalDamage = enemy.health; // Instantly kill
              } else {
                finalDamage *= 2;
              }
            }
            
            if (enemy.isMarked && runModifiers?.crossArcherBomber) {
              finalDamage *= 1.5;
              enemy.isMarked = false;
            }
            
            enemy.lastHitBy = this;
            applyDamage(enemy, { amount: finalDamage, type: 'physical', sourceTower: this, crit: false });
            
            TowerEventSystem.emit('onHitEnemy', {
              sourceTower: this,
              targetEnemy: enemy,
              damage: finalDamage,
              towerType: this.constructor.name
            });
            
            if (runModifiers?.applyBurn || this.flatBurnDuration > 0) {
              enemy.burnTimer = Math.max(enemy.burnTimer || 0, this.flatBurnDuration > 0 ? this.flatBurnDuration : 2.0);
              (enemy as any).burnDamage = Math.max((enemy as any).burnDamage || 0, this.flatBurnDamage > 0 ? this.flatBurnDamage : 10);
            }
            
            if (enemy.health <= 0) {
              enemy.active = false;
            }
          }
        }
      };

      applyExplosion(isMini);
      if (isDouble) {
        applyExplosion(false);
      }
    }

    // Visual projectile logic
    if (this.visualProjectileCount >= this.maxVisualProjectiles || activeProjectilesCount >= 120) {
      return null;
    }
    
    this.visualProjectileCount++;
    const p = projectilePool.get();
    if (p.reset) {
      p.reset(this.position, target, damage, this, 'bomb');
    }
    return p;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    const cx = this.position.x, cy = this.position.y;
    const color = '#f97316', mid = '#ea580c', dim = '#431407';
    const sides = 6, rot = 0;

    const poly = (r: number, s: number, rotation: number) => {
      ctx.beginPath();
      for (let i = 0; i < s; i++) {
        const a = (i / s) * Math.PI * 2 + rotation;
        i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
                : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };

    poly(22, sides, rot);
    ctx.strokeStyle = color + '44'; ctx.lineWidth = 1; ctx.stroke();

    poly(18, sides, rot);
    ctx.fillStyle = dim; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();

    poly(11, sides, rot + Math.PI / sides);
    ctx.fillStyle = '#0a1828'; ctx.fill();
    ctx.strokeStyle = mid + 'aa'; ctx.lineWidth = 1; ctx.stroke();

    for (let k = 0; k < sides; k++) {
      const a1 = (k / sides) * Math.PI * 2 + rot;
      const a2 = ((k + 1) / sides) * Math.PI * 2 + rot;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a1) * 11, cy + Math.sin(a1) * 11);
      ctx.lineTo(cx + Math.cos(a1) * 18, cy + Math.sin(a1) * 18);
      ctx.lineTo(cx + Math.cos((a1 + a2) / 2) * 21, cy + Math.sin((a1 + a2) / 2) * 21);
      ctx.lineTo(cx + Math.cos(a2) * 18, cy + Math.sin(a2) * 18);
      ctx.lineTo(cx + Math.cos(a2) * 11, cy + Math.sin(a2) * 11);
      ctx.closePath();
      ctx.fillStyle = k % 2 === 0 ? color + '30' : color + '10';
      ctx.fill();
    }

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 7 : 4;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 3.5 : 2;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.globalAlpha = 0.7; ctx.fill(); ctx.globalAlpha = 1;

    ctx.beginPath(); ctx.arc(cx - 1, cy - 1, 1.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();

    this.drawLevel(ctx);
  }
}
