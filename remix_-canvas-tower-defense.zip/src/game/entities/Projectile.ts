import { Vector2 } from '../utils/Vector2';
import { Enemy } from './Enemy';
import { Tower, CorruptionType } from './Tower';

import { applyDamage } from '../systems/BuffSystem';
import { TowerEventSystem } from '../systems/tower/TowerEventSystem';

export class Projectile {
  public position: Vector2;
  public target?: Enemy;
  public targetPosition: Vector2;
  public speed: number = 400;
  public damage: number;
  public active: boolean = true;
  public sourceTower?: Tower;
  public lifetime: number = 0;
  public maxLifetime: number = 1.5;
  public type: 'normal' | 'bomb' | 'frost' = 'normal';

  constructor(start?: Vector2, target?: Enemy, damage?: number, sourceTower?: Tower) {
    this.position = start ? start.clone() : new Vector2(0, 0);
    this.target = target;
    this.targetPosition = target ? target.position.clone() : new Vector2(0, 0);
    this.damage = damage || 0;
    this.sourceTower = sourceTower;
    this.active = true;
    this.lifetime = 0;
  }

  public reset(start: Vector2, target: Enemy, damage: number, sourceTower?: Tower, type: 'normal' | 'bomb' | 'frost' = 'normal') {
    this.position = start.clone();
    this.target = target;
    this.targetPosition = target.position.clone();
    this.damage = damage;
    this.sourceTower = sourceTower;
    this.active = true;
    this.lifetime = 0;
    this.type = type;
    
    if (type === 'bomb') {
      this.speed = 250;
    } else if (type === 'frost') {
      this.speed = 500;
    } else {
      this.speed = 400;
    }
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    this.lifetime += dt;
    if (this.lifetime >= this.maxLifetime) {
      this.destroy();
      return;
    }

    if (this.target && this.target.active) {
      this.targetPosition = this.target.position.clone();
    }

    const dir = this.targetPosition.sub(this.position);
    const dist = dir.mag();

    // Check collision (visual only)
    if (dist < 10) {
      this.destroy();
    } else {
      // Move towards target
      const move = dir.normalize().mult(this.speed * dt);
      this.position = this.position.add(move);
    }
  }

  protected destroy(): void {
    this.active = false;
    if (this.sourceTower) {
      this.sourceTower.visualProjectileCount = Math.max(0, this.sourceTower.visualProjectileCount - 1);
    }
  }
}
