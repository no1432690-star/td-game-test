import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';
import { UpgradeManager } from '../systems/UpgradeManager';

export class LegendaryTower extends Tower {
  public baseTower: Tower;
  public legendaryType: string;
  private shotsFired: number = 0;

  constructor(baseTower: Tower, legendaryType: string) {
    super(baseTower.type, baseTower.position.x, baseTower.position.y, baseTower.baseRange, baseTower.baseCooldown, baseTower.baseDamage);
    this.baseTower = baseTower;
    this.legendaryType = legendaryType;
    this.isLegendary = true;
    this.level = baseTower.level;
    this.baseCost = baseTower.baseCost;
    this.critChance = baseTower.critChance;
    
    if (this.legendaryType === 'Archer' || this.legendaryType === 'CursedArcher') {
      this.baseTower.baseDamage *= 2;
      this.baseTower.critChance += 0.5;
    }
  }

  public get targetMode(): string { return this.baseTower ? this.baseTower.targetMode : "FIRST"; }
  public set targetMode(value: string) { if (this.baseTower) this.baseTower.targetMode = value; }

  public get damage(): number { return this.baseTower ? this.baseTower.damage : 0; }
  public set damage(value: number) { if (this.baseTower) this.baseTower.damage = value; }
  public get range(): number { return this.baseTower ? this.baseTower.range : 0; }
  public set range(value: number) { if (this.baseTower) this.baseTower.range = value; }
  public get attackSpeed(): number { return this.baseTower ? this.baseTower.attackSpeed : 0; }
  public set attackSpeed(value: number) { if (this.baseTower) this.baseTower.attackSpeed = value; }

  public cycleTargetMode(): void {
    this.baseTower.cycleTargetMode();
  }

  public applyMeta(damageMultiplier: number, critChance: number, isCursed: boolean = false): void {
    this.baseTower.applyMeta(damageMultiplier, critChance, isCursed);
    if (this.legendaryType === 'Archer' || this.legendaryType === 'CursedArcher') {
      this.baseTower.baseDamage *= 2;
      this.baseTower.critChance += 0.5;
    }
    this.critChance = this.baseTower.critChance;
  }

  public upgrade(): boolean {
    const success = this.baseTower.upgrade();
    if (success) {
      this.level = this.baseTower.level;
    }
    return success;
  }

  public update(dt: number, enemies: Enemy[], runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, activeProjectilesCount: number = 0): Projectile[] {
    this.baseTower.position = this.position;
    
    const legendaryModifiers: RunModifiers = { ...(runModifiers || {
      damageMultiplier: 1,
      speedMultiplier: 1,
      goldMultiplier: 1,
      rangeMultiplier: 1
    }) };

    if (this.legendaryType === 'Bomber') {
      legendaryModifiers.explosionRadiusBonus = (legendaryModifiers.explosionRadiusBonus || 0) + 1.0;
      legendaryModifiers.applyBurn = true;
      legendaryModifiers.miniExplosionChance = (legendaryModifiers.miniExplosionChance || 0) + 0.30;
    } else if (this.legendaryType === 'Frost') {
      legendaryModifiers.damageToSlowedBonus = (legendaryModifiers.damageToSlowedBonus || 0) + 0.40;
      legendaryModifiers.slowBonus = (legendaryModifiers.slowBonus || 0) + 0.50;
      
      if (this.shotsFired % 5 === 4) {
        legendaryModifiers.freezeChance = 1.0;
      }
    } else if (this.legendaryType === 'Archer' || this.legendaryType === 'CursedArcher') {
      legendaryModifiers.speedMultiplier *= 2;
    }

    const projectiles = this.baseTower.update(dt, enemies, legendaryModifiers, upgradeManager, activeProjectilesCount);
    if (projectiles && projectiles.length > 0) {
      if (this.legendaryType === 'Frost') {
        this.shotsFired += projectiles.length;
      }
    }
    return projectiles;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    this.baseTower.position = this.position;
    
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 25, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(250, 204, 21, 0.2)';
    ctx.fill();
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.closePath();

    this.baseTower.draw(ctx);
  }
}
