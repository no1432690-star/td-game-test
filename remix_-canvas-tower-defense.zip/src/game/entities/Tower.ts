import { Vector2 } from '../utils/Vector2';
import { TOWER_DATA } from "../data/towers";
import { calculateTowerStats } from '../combat/StatCalculator';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { projectilePool } from '../pools/ProjectilePool';
import { RunModifiers } from '../systems/RunSystem';
import { UpgradeManager } from '../systems/UpgradeManager';
import { CorruptedShardManager } from '../systems/CorruptedShardManager';
import { CorruptionSystem } from '../../systems/corruption/CorruptionSystem';
import { LegendarySystem } from '../../systems/legendary/LegendarySystem';
import { applyLegendaryModifier } from '../../systems/legendary/LegendaryModifier';
import { selectTarget } from '../../tower/selectTarget';
import { TARGET_MODES } from '../../tower/targetModes';
import { enemyGrid } from '../spatial/EnemyGrid';

import { recalculateTowerStats, applyDamage } from '../systems/BuffSystem';
import { TowerEventSystem } from '../systems/tower/TowerEventSystem';
import { applyArtifactCritCascade } from '../systems/artifactHooks';
import { ArtifactEventBus } from '../systems/artifactEventBus';

export enum CorruptionType {
  UnstableCore,
  BloodPact,
  Overclock,
  FrozenCore,
  Firework
}

export class Tower {
  public position: Vector2;
  public baseRange: number;
  public baseCooldown: number;
  public baseDamage: number;

  public bonusDamageMultiplier: number = 1;
  public bonusRangeMultiplier: number = 1;
  public bonusSpeedMultiplier: number = 1;

  protected timer: number = 0;

  public level: number = 1;
  public maxLevel: number = 25;
  public baseCost: number = 100;
  public critChance: number = 0;
  public isLegendary: boolean = false;
  public isCorrupted?: boolean = false;
  public corruptionType: CorruptionType | string | null = null;
  public overclockDamagePenalty: number = 0;
  public fireRate: number = 1;
  public visualProjectileCount: number = 0;
  public maxVisualProjectiles: number = 3; // Default
  public activeTeslaLinks: number = 0;
  protected _targetMode: string = TARGET_MODES.FIRST;
  public get targetMode(): string { return this._targetMode; }
  public set targetMode(value: string) { this._targetMode = value; }

  public type: string = "";
  public baseStats: any = {};
  public finalStats: any = {};
  public buffs: any[] = [];
  public teslaLinks: any[] = [];

  // BASE (design stats)
  public baseAttackSpeed: number = 1;
  public baseCritChance: number = 0;
  public baseCritDamage: number = 2;
  public baseSplashRadius: number = 0;
  public baseSplashDamage: number = 1;
  public baseSlowDuration: number = 0;
  public baseSlowEffect: number = 0;
  public baseBurnDamage: number = 0;
  public baseBurnDuration: number = 0;

  // FLAT (level-scaled stats)
  public flatDamage: number = 0;
  public flatAttackSpeed: number = 0;
  public flatRange: number = 0;
  public flatCritChance: number = 0;
  public flatCritDamage: number = 0;
  public flatSplashRadius: number = 0;
  public flatSplashDamage: number = 0;
  public flatSlowDuration: number = 0;
  public flatSlowEffect: number = 0;
  public flatBurnDamage: number = 0;
  public flatBurnDuration: number = 0;
  
  public multiTargetSlow: number = 1;

  protected _damage: number = 0;
  protected _range: number = 0;
  protected _attackSpeed: number = 0;

  public get damage(): number { return this._damage; }
  public set damage(value: number) { this._damage = value; }

  public get range(): number { return this._range; }
  public set range(value: number) { this._range = value; }

  public get attackSpeed(): number { return this._attackSpeed; }
  public set attackSpeed(value: number) { this._attackSpeed = value; }

  constructor(type: string, x: number, y: number, range: number = 0, cooldown: number = 0, damage: number = 0) {
    this.type = type;
    this.position = new Vector2(x, y);
    
    const def = TOWER_DATA[type];
    if (def) {
      this.baseStats = { ...this.baseStats, ...def.stats };
      this.baseRange = def.stats.range;
      this.baseCooldown = def.stats.cooldown;
      this.baseDamage = def.stats.damage;
    } else {
      this.baseRange = range;
      this.baseCooldown = cooldown;
      this.baseDamage = damage;
    }
    
    this.baseAttackSpeed = this.baseCooldown > 0 ? 1 / this.baseCooldown : 0;
    this.targetMode ??= TARGET_MODES.FIRST;
    this.recalculateFinalStats();
  }

  public cycleTargetMode(): void {
    const list = [TARGET_MODES.FIRST, TARGET_MODES.LAST, TARGET_MODES.STRONG, TARGET_MODES.CLOSE];
    const i = list.indexOf(this.targetMode);
    this.targetMode = list[(i + 1) % list.length];
  }

  public applyMeta(damageMultiplier: number, critChance: number, isCursed: boolean = false): void {
    this.bonusDamageMultiplier *= damageMultiplier;
    if (isCursed) {
      this.bonusDamageMultiplier *= 1.4; // +40% damage
      this.bonusSpeedMultiplier /= 1.25; // -20% fire rate (takes 25% longer to fire)
    }
    this.critChance = critChance;
    this.baseCritChance = critChance;
    this.recalculateFinalStats();
  }

  public getUpgradeCost(): number {
    return Math.floor(100 * Math.pow(1.18, this.level));
  }

  public canUpgrade(gameGold: number): boolean {
    return this.level < this.maxLevel && gameGold >= this.getUpgradeCost();
  }

  public upgrade(): boolean {
    if (this.level >= this.maxLevel) return false;

    this.level++;

    if (
      this.level === 25 &&
      !this.isLegendary &&
      this.corruptionType === null
    ) {
      LegendarySystem.tryRollLegendary(this);
    }

    this.applyLevelScaling();
    this.applyMilestoneBonuses();
    this.recalculateFinalStats();

    return true;
  }

  public applyLevelScaling() {
    const DAMAGE_SCALE = 0.15;
    const SPEED_SCALE = 0.05;
    const RANGE_SCALE = 0.05;

    // Scale base stats (NOT final stats)
    this.baseDamage *= (1 + DAMAGE_SCALE);
    this.baseAttackSpeed *= (1 + SPEED_SCALE);
    this.baseRange *= (1 + RANGE_SCALE);
  }

  public applyMilestoneBonuses() {
    if (this.level === 5) this.applyMilestone5();
    if (this.level === 10) this.applyMilestone10();
    if (this.level === 15) this.applyMilestone15();

    if (this.level >= 16) this.applyPost15Scaling();
  }

  public applyMilestone5() {
    const type = this.constructor.name.toLowerCase();
    if (type === "bomber") {
      this.baseSplashRadius *= 1.25;
    } else if (type === "archer" || type === "cursedarcher") {
      this.baseCritDamage *= 1.1;
    } else if (type === "frost") {
      this.baseSlowDuration *= 1.1;
    }
  }

  public applyMilestone10() {
    const type = this.constructor.name.toLowerCase();
    if (type === "bomber") {
      this.baseSplashDamage *= 1.15;
    } else if (type === "archer" || type === "cursedarcher") {
      this.baseCritChance += 0.05;
    } else if (type === "frost") {
      this.baseAttackSpeed *= 1.1;
    }
  }

  public applyMilestone15() {
    const type = this.constructor.name.toLowerCase();
    if (type === "bomber") {
      this.baseBurnDamage = 5;
      this.baseBurnDuration = 5;
    } else if (type === "archer" || type === "cursedarcher") {
      this.baseAttackSpeed *= 1.5;
    } else if (type === "frost") {
      this.multiTargetSlow = 5;
    }
  }

  public applyPost15Scaling() {
    const type = this.constructor.name.toLowerCase();
    if (type === "bomber") {
      this.baseBurnDamage *= 1.2;
      this.baseBurnDuration += 1;
    } else if (type === "frost") {
      this.baseSlowEffect *= 1.05;
    }
  }

  private getLegendaryMultiplier(): number {
    return this.isLegendary ? 1.5 : 1;
  }

  private getCorruptionMultipliers() {
    const base = {
      damage: 1,
      attackSpeed: 1,
      range: 1,
      splashDamage: 1,
      splashRadius: 1,
      slowDuration: 1
    };

    if (this.corruptionType === null || this.corruptionType === undefined) return base;

    switch (this.corruptionType) {
      case CorruptionType.UnstableCore:
        base.damage = 1.8;
        break;

      case CorruptionType.BloodPact:
        base.damage = 1.6;
        break;

      case CorruptionType.Overclock:
        base.attackSpeed = 1.7;
        base.damage *= (1 - this.overclockDamagePenalty);
        break;

      case CorruptionType.FrozenCore:
        base.slowDuration = 1.5;
        base.damage = 0.75;
        base.attackSpeed = 0.95;
        break;

      case CorruptionType.Firework:
        base.damage = 0.5;
        base.range = 1.25;
        base.splashRadius = 1.25;
        base.splashDamage = 1.25;
        base.attackSpeed = 0.95;
        break;
    }

    return base;
  }

  public applyOverclockDecay() {
    if (this.corruptionType !== CorruptionType.Overclock) return;

    if (this.overclockDamagePenalty < 0.25) {
      this.overclockDamagePenalty += 0.05;
    }
  }

  public applyCorruption(type: CorruptionType): boolean {
    if (this.level < 16) return false;
    if (this.isLegendary) return false;
    if (this.corruptionType !== null) return false;

    const manager = CorruptedShardManager.instance;
    const cost = manager.getCorruptionCost();

    if (!manager.spendShards(cost)) return false;

    this.corruptionType = type;
    this.isCorrupted = true;
    this.isLegendary = false;

    manager.registerCorruption(cost);

    return true;
  }

  public recalculateFinalStats(runModifiers?: RunModifiers) {
    const dmgMult = (runModifiers?.damageMultiplier ?? 1) * this.bonusDamageMultiplier;
    const spdMult = (runModifiers?.speedMultiplier ?? 1) * this.bonusSpeedMultiplier;
    const rngMult = (runModifiers?.rangeMultiplier ?? 1) * this.bonusRangeMultiplier;

    this.flatDamage = this.baseDamage;
    this.flatAttackSpeed = this.baseAttackSpeed;
    this.flatRange = this.baseRange;
    
    this.flatCritChance = this.baseCritChance;
    this.flatCritDamage = this.baseCritDamage;
    this.flatSplashRadius = this.baseSplashRadius;
    this.flatSplashDamage = this.baseSplashDamage;
    this.flatSlowDuration = this.baseSlowDuration;
    this.flatSlowEffect = this.baseSlowEffect;
    this.flatBurnDamage = this.baseBurnDamage;
    this.flatBurnDuration = this.baseBurnDuration;

    const corruption = this.getCorruptionMultipliers();
    const legendary = this.getLegendaryMultiplier();

    this.damage = this.flatDamage * legendary * corruption.damage * dmgMult;
    this.attackSpeed = this.flatAttackSpeed * legendary * corruption.attackSpeed * spdMult;
    this.range = this.flatRange * legendary * corruption.range * rngMult;
    
    this.flatSplashDamage *= legendary * corruption.splashDamage;
    this.flatSplashRadius *= legendary * corruption.splashRadius;
    this.flatSlowDuration *= legendary * corruption.slowDuration;

    // Phase 3: Apply new corruption system modifiers
    if (this.corruptionType && typeof this.corruptionType === 'string') {
      const modified = CorruptionSystem.applyModifiers({
        damage: this.damage,
        attackSpeed: this.attackSpeed,
        range: this.range
      }, this.corruptionType);
      
      this.damage = modified.damage;
      this.attackSpeed = modified.attackSpeed;
      this.range = modified.range;
    }

    // Phase 4: Apply legendary modifier
    const legendaryStats = applyLegendaryModifier({
      damage: this.damage,
      attackSpeed: this.attackSpeed,
      range: this.range,
      splashRadius: this.flatSplashRadius,
      slowDuration: this.flatSlowDuration
    }, this);

    this.damage = legendaryStats.damage;
    this.attackSpeed = legendaryStats.attackSpeed;
    this.range = legendaryStats.range;
    this.flatSplashRadius = legendaryStats.splashRadius;
    this.flatSlowDuration = legendaryStats.slowDuration;

    this.baseStats = {
      damage: this.damage,
      attackSpeed: this.attackSpeed,
      range: this.range,
      critChance: this.flatCritChance + this.critChance,
      critMultiplier: this.flatCritDamage,
      aoeRadius: this.flatSplashRadius
    };

    recalculateTowerStats(this);

    this.damage = this.finalStats.damage ?? this.damage;
    this.attackSpeed = this.finalStats.attackSpeed ?? this.attackSpeed;
    this.range = this.finalStats.range ?? this.range;
    this.flatCritChance = (this.finalStats.critChance ?? (this.flatCritChance + this.critChance)) - this.critChance;
    this.flatCritDamage = this.finalStats.critMultiplier ?? this.flatCritDamage;
    this.flatSplashRadius = this.finalStats.aoeRadius ?? this.flatSplashRadius;

    // Apply Relic Bonuses
    const relicBonuses = (window as any).gameInstance?.getRelicBonuses() || {};
    
    if (relicBonuses.atkSpeedPercent) {
      this.attackSpeed *= (1 + relicBonuses.atkSpeedPercent);
    }
    
    if (relicBonuses.rangePercent) {
      this.range *= (1 + relicBonuses.rangePercent);
    }
  }

  public clone(): Tower {
    const clone = Object.assign(Object.create(Object.getPrototypeOf(this)), this);
    clone.position = this.position.clone();
    return clone;
  }

  public update(dt: number, enemies: Enemy[], runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, activeProjectilesCount: number = 0): Projectile[] {
    this.recalculateFinalStats(runModifiers);
    
    const stats = calculateTowerStats(this);
    const currentAttackSpeed = stats?.cooldown ? 1 / stats.cooldown : this.attackSpeed;
    const currentRange = stats?.range ?? this.range;
    const currentDamage = stats?.damage ?? this.damage;
    
    const originalRange = this.range;
    const originalDamage = this.damage;
    
    this.range = currentRange;
    this.damage = currentDamage;
    
    const classSpeedMult = upgradeManager ? upgradeManager.getClassMultiplier(this.constructor.name, "attack_speed") : 1.0;
    
    this.timer -= (dt * currentAttackSpeed * classSpeedMult * this.fireRate);
    
    const spawnedProjectiles: Projectile[] = [];
    if (this.timer <= 0) {
      const target = this.findTarget(enemies, runModifiers);
      if (target) {
        this.timer = 1;
        
        if (this.corruptionType === CorruptionType.Firework) {
          for (let i = 0; i < 3; i++) {
            const proj = this.attack(target, runModifiers, upgradeManager, enemies, activeProjectilesCount + spawnedProjectiles.length);
            if (proj) spawnedProjectiles.push(proj);
          }
        } else {
          const proj = this.attack(target, runModifiers, upgradeManager, enemies, activeProjectilesCount);
          if (proj) spawnedProjectiles.push(proj);
        }
      }
    }
    
    this.range = originalRange;
    this.damage = originalDamage;
    
    return spawnedProjectiles;
  }

  protected findTarget(enemies: Enemy[], runModifiers?: RunModifiers): Enemy | null {
    const effectiveRange = this.range;

    let nearbyEnemies = enemyGrid && enemyGrid.getEnemiesNear ? enemyGrid.getEnemiesNear(this.position.x, this.position.y, effectiveRange) : null;
    if (!nearbyEnemies || nearbyEnemies.length === 0) {
      nearbyEnemies = enemies;
    }

    const inRange: Enemy[] = [];
    for (const enemy of nearbyEnemies) {
      if (enemy.active && this.position.dist(enemy.position) <= effectiveRange) {
        inRange.push(enemy);
      }
    }

    const target = selectTarget(inRange, this);
    if (!target) return null;

    return target;
  }

  protected getCalculatedDamage(runModifiers?: RunModifiers, target?: Enemy, upgradeManager?: UpgradeManager): number {
    const classDmgMult = upgradeManager ? upgradeManager.getClassMultiplier(this.constructor.name, "bonus_damage") : 1.0;
    
    // Lightning Resonance
    let lightningResonanceBonus = 0;
    if (upgradeManager && upgradeManager.stacks["tesla_lightning_resonance"] > 0) {
      lightningResonanceBonus = 0.05 * (this.teslaLinks?.length || 0);
    }

    let finalDamage = this.damage * (classDmgMult + lightningResonanceBonus);
    
    // Frost synergy: +15% damage to slowed enemies
    if (target && target.effects.some(e => e.type === 'slow')) {
      if (runModifiers?.damageToSlowedBonus) {
        finalDamage *= (1 + runModifiers.damageToSlowedBonus);
      }
      if (upgradeManager && this.constructor.name === "Frost") {
        const frostBonus = upgradeManager.getClassMultiplier("Frost", "bonus_vs_slowed") - 1.0;
        finalDamage *= (1 + frostBonus);
      }
    }

    let currentCritChance = this.flatCritChance + this.critChance + (runModifiers?.critChanceBonus || 0);
    
    const relicBonuses = (window as any).gameInstance?.getRelicBonuses() || {};
    if (relicBonuses.critChance) {
      currentCritChance += relicBonuses.critChance;
    }

    if (upgradeManager && (this.constructor.name === "Archer" || this.constructor.name === "CursedArcher")) {
      currentCritChance += (upgradeManager.getClassMultiplier("Archer", "crit_chance") - 1.0);
    }
    
    // Archer + Frost cross synergy
    if (target && target.effects.some(e => e.type === 'slow') && runModifiers?.crossArcherFrost) {
      currentCritChance += 0.25;
    }

    const isCrit = runModifiers?.guaranteedCrit || Math.random() < currentCritChance;
    if (isCrit) {
      let critDmg = this.flatCritDamage + (runModifiers?.critDamageBonus || 0);
      if (upgradeManager && (this.constructor.name === "Archer" || this.constructor.name === "CursedArcher")) {
        critDmg += (upgradeManager.getClassMultiplier("Archer", "crit_damage") - 1.0);
      }
      finalDamage *= critDmg;
      
      // Archer + Bomber cross synergy: mark target on crit
      if (target && runModifiers?.crossArcherBomber) {
        target.isMarked = true;
      }

      // Artifact Crit Cascade
      const game = (window as any).gameInstance;
      if (game && target) {
        applyArtifactCritCascade(target, finalDamage, game, (t) => {
          if (game.getNearbyEnemies) {
            const nearby = game.getNearbyEnemies(t.position.x, t.position.y, 150);
            return nearby.find((n: any) => n !== t && n.active);
          }
          return null;
        }, (t, d) => {
          applyDamage(t, { amount: d, type: 'physical', sourceTower: this, crit: false });
        });
      }
    }
    return finalDamage;
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, enemies?: Enemy[], activeProjectilesCount: number = 0): Projectile | null {
    ArtifactEventBus.emit("onAttack", {
      attacker: this,
      target
    });
    const damage = this.getCalculatedDamage(runModifiers, target, upgradeManager);
    
    // Apply damage instantly
    if (this.corruptionType === CorruptionType.UnstableCore && Math.random() <= 0.2) {
      // Missed
    } else {
      target.lastHitBy = this;
      applyDamage(target, { amount: damage, type: 'physical', sourceTower: this, crit: false });

      TowerEventSystem.emit('onHitEnemy', {
        sourceTower: this,
        targetEnemy: target,
        damage: damage,
        towerType: this.constructor.name
      });

      if (target.health <= 0) {
        target.active = false;
      }
    }

    // Visual projectile logic
    if (this.visualProjectileCount >= this.maxVisualProjectiles || activeProjectilesCount >= 120) {
      return null;
    }
    
    this.visualProjectileCount++;
    const proj = projectilePool.get();
    if (proj.reset) {
      proj.reset(this.position, target, damage, this);
    }
    return proj;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 15, 0, Math.PI * 2);
    ctx.fillStyle = 'gray';
    ctx.fill();
    ctx.closePath();
  }

  protected drawLevel(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = '#fff';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Lv.${this.level}`, this.position.x, this.position.y - 20);
    if (this.level >= 3) {
      ctx.fillStyle = '#fbbf24'; // Gold star for special ability
      ctx.fillText('★', this.position.x, this.position.y - 30);
    }
    ctx.textAlign = 'left';
  }
}
