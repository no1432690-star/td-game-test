import { Tower } from './Tower';

export class Archer extends Tower {
  constructor(x: number, y: number) {
    super("archer", x, y);
    this.baseCost = 50;
    this.maxVisualProjectiles = 3;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    const cx = this.position.x, cy = this.position.y;
    const color = '#22c55e', mid = '#16a34a', dim = '#052e16';
    const sides = 8, rot = Math.PI / 8;

    const poly = (r: number, s: number, rotation: number) => {
      ctx.beginPath();
      for (let i = 0; i < s; i++) {
        const a = (i / s) * Math.PI * 2 + rotation;
        i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
                : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };

    // Layer 1: outer halo (stroke only)
    poly(22, sides, rot);
    ctx.strokeStyle = color + '44'; ctx.lineWidth = 1; ctx.stroke();

    // Layer 2: main body
    poly(18, sides, rot);
    ctx.fillStyle = dim; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();

    // Layer 3: inner plate (rotated)
    poly(11, sides, rot + Math.PI / sides);
    ctx.fillStyle = '#0a1828'; ctx.fill();
    ctx.strokeStyle = mid + 'aa'; ctx.lineWidth = 1; ctx.stroke();

    // Layer 4: facet highlights between body and inner plate
    for (let k = 0; k < sides; k++) {
      const a1 = (k / sides) * Math.PI * 2 + rot;
      const a2 = ((k + 1) / sides) * Math.PI * 2 + rot;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a1) * 11, cy + Math.sin(a1) * 11);
      ctx.lineTo(cx + Math.cos(a1) * 18, cy + Math.sin(a1) * 18);
      ctx.lineTo(cx + Math.cos((a1 + a2) / 2) * 21, cy + Math.sin((a1 + a2) / 2) * 21);
      ctx.lineTo(cx + Math.cos(a2) * 18, cy + Math.sin(a2) * 18);
      ctx.lineTo(cx + Math.cos(a2) * 11, cy + Math.sin(a2) * 11);
      ctx.closePath();
      ctx.fillStyle = k % 2 === 0 ? color + '30' : color + '10';
      ctx.fill();
    }

    // Layer 5: gem core (4-point star)
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 7 : 4;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 3.5 : 2;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.globalAlpha = 0.7; ctx.fill(); ctx.globalAlpha = 1;

    // Highlight
    ctx.beginPath(); ctx.arc(cx - 1, cy - 1, 1.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();

    this.drawLevel(ctx);
  }
}
