import { Enemy } from './Enemy';
import { EnemyType } from './EnemyType';
import { Vector2 } from '../utils/Vector2';
import { GOLD_HP_RATIO } from '../constants';

export class EnemyFactory {
  static calculateStatsForType(type: EnemyType, wave: number) {
    let baseRedHP = 100;
    let baseRedSpeed = 45;

    const baseHpMultiplier = Math.pow(1.12, wave - 1);
    baseRedHP = 100 * baseHpMultiplier;

    if (wave <= 3) {
      baseRedHP *= 0.8;
    }

    const baseSpeedMultiplier = Math.pow(1.02, wave - 1);
    baseRedSpeed = 45 * baseSpeedMultiplier;

    let hpMultiplier = 1;
    let speedMultiplier = 1;

    const bossMultiplier = 4 + Math.floor(wave / 5);

    switch (type) {
      case EnemyType.Red:
        hpMultiplier = 1;
        speedMultiplier = 1;
        break;
      case EnemyType.Yellow:
        hpMultiplier = 0.6;
        speedMultiplier = 1.6;
        break;
      case EnemyType.Gray:
        hpMultiplier = 2.5;
        speedMultiplier = 0.6;
        break;
      case EnemyType.BossRed:
        hpMultiplier = bossMultiplier;
        speedMultiplier = 0.8;
        break;
      case EnemyType.BossYellow:
        hpMultiplier = bossMultiplier * 0.6;
        speedMultiplier = 1.28;
        break;
      case EnemyType.BossGray:
        hpMultiplier = bossMultiplier * 2.5;
        speedMultiplier = 0.48;
        break;
    }

    const maxHealth = baseRedHP * hpMultiplier;
    const speed = Math.max(40, baseRedSpeed * speedMultiplier);

    return { maxHealth, speed };
  }

  static create(type: EnemyType, wave: number, waypoints: Vector2[], pool?: Enemy[]): Enemy {
    let enemy: Enemy;
    if (pool && pool.length > 0) {
      enemy = pool.pop()!;
      enemy.reset(waypoints);
    } else {
      enemy = new Enemy(waypoints);
    }

    enemy.type = type;

    let baseRedHP = 100;
    let baseRedSpeed = 45;

    const baseHpMultiplier = Math.pow(1.12, wave - 1);
    baseRedHP = 100 * baseHpMultiplier;

    if (wave <= 3) {
      baseRedHP *= 0.8;
    }

    const baseSpeedMultiplier = Math.pow(1.02, wave - 1);
    baseRedSpeed = 45 * baseSpeedMultiplier;

    let hpMultiplier = 1;
    let speedMultiplier = 1;
    let isBoss = false;

    const bossMultiplier = 4 + Math.floor(wave / 5);

    switch (type) {
      case EnemyType.Red:
        hpMultiplier = 1;
        speedMultiplier = 1;
        break;
      case EnemyType.Yellow:
        hpMultiplier = 0.6;
        speedMultiplier = 1.6;
        break;
      case EnemyType.Gray:
        hpMultiplier = 2.5;
        speedMultiplier = 0.6;
        break;
      case EnemyType.BossRed:
        hpMultiplier = bossMultiplier;
        speedMultiplier = 0.8;
        isBoss = true;
        break;
      case EnemyType.BossYellow:
        hpMultiplier = bossMultiplier * 0.6;
        speedMultiplier = 1.28; // 1.6 * 0.8
        isBoss = true;
        break;
      case EnemyType.BossGray:
        hpMultiplier = bossMultiplier * 2.5;
        speedMultiplier = 0.48; // 0.6 * 0.8
        isBoss = true;
        break;
    }

    enemy.maxHealth = baseRedHP * hpMultiplier;
    enemy.health = enemy.maxHealth;
    enemy.speed = Math.max(40, baseRedSpeed * speedMultiplier);
    enemy.baseStats.speed = enemy.speed;
    
    if (isBoss) {
      enemy.goldReward = Math.max(20, Math.floor(enemy.maxHealth * GOLD_HP_RATIO * 1.5));
      enemy.radius = 20;
    } else {
      enemy.goldReward = Math.max(1, Math.floor(enemy.maxHealth * GOLD_HP_RATIO));
      enemy.radius = 12;
    }

    return enemy;
  }
}
