import { Vector2 } from '../utils/Vector2';
import { difficultyScaler } from '../core/DifficultyScaler';
import { EnemyType } from './EnemyType';
import { getMutationChance } from '../utils/MutationUtils';
import { EnemyFactory } from './EnemyFactory';
import { GOLD_HP_RATIO } from '../constants';
import { updateEnemyEffects } from '../systems/BuffSystem';

export interface StatusEffect {
  type: string;
  source?: string;
  value: number;
  duration: number;
  multiplier?: number;
}

const MUTATION_START_WAVE = 50;

export class Enemy {
  public position: Vector2;
  
  public get x(): number { return this.position.x; }
  public get y(): number { return this.position.y; }
  
  private _health: number;
  public maxHealth: number;
  public speed: number = 100;
  public active: boolean = true;
  public effects: StatusEffect[] = [];
  
  public baseStats: any = {
    speed: 100,
    armor: 0,
    magicResist: 0
  };
  public finalStats: any = { ...this.baseStats };
  public timeAlive: number = 0;
  public threatCost: number = 1;
  public goldReward: number = 10;
  public reachedEnd: boolean = false;
  public type: EnemyType = EnemyType.Red;
  public radius: number = 12;

  public shield: number = 0;
  public maxShield: number = 0;
  public deathSpawnMini: number = 0;
  
  // Advanced Synergy Flags
  public isFrozen?: boolean;
  public isMarked?: boolean;
  public burnTimer?: number;
  public freezeTimer?: number;
  public explodeOnDeath?: boolean;

  public isMutating: boolean = false;
  public mutationDelay: number = 0;
  public hasMutated: boolean = false;
  public canMutate: boolean = false;

  public lastHitBy?: any; // Tower

  private path: Vector2[];
  public targetIndex: number = 1;

  constructor(path: Vector2[], xOffset: number = 0) {
    this.path = path;
    // Start at the first waypoint, with an optional offset to space out test spawns
    this.position = new Vector2(path[0].x + xOffset, path[0].y);
    this.maxHealth = 100;
    this._health = this.maxHealth;
  }

  public setTargetIndex(index: number): void {
    this.targetIndex = index;
  }

  public get progress(): number {
    if (this.targetIndex >= this.path.length) return this.targetIndex * 1000;
    const target = this.path[this.targetIndex];
    const dist = this.position.dist(target);
    return this.targetIndex * 1000 - dist;
  }

  public get health(): number {
    return this._health;
  }

  public set health(value: number) {
    let damage = this._health - value;
    if (damage <= 0) {
      this._health = value;
      return;
    }

    if (this.shield > 0) {
      if (damage <= this.shield) {
        this.shield -= damage;
        damage = 0;
      } else {
        damage -= this.shield;
        this.shield = 0;
      }
    }

    if (damage > 0) {
      difficultyScaler.reportDamage(damage);
    }
    this._health -= damage;
    if (this._health <= 0 && this.active) {
      if (this.tryMutate()) {
        return;
      }
      difficultyScaler.reportKill(this.timeAlive);
    }
  }

  public reset(path: Vector2[], xOffset: number = 0): void {
    this.path = path;
    this.targetIndex = 1;
    this.position = new Vector2(path[0].x + xOffset, path[0].y);
    this.active = true;
    this.effects = [];
    this.timeAlive = 0;
    this._health = this.maxHealth;
    this.shield = 0;
    this.maxShield = 0;
    this.deathSpawnMini = 0;
    this.reachedEnd = false;
    
    this.isFrozen = false;
    this.isMarked = false;
    this.burnTimer = 0;
    this.freezeTimer = 0;
    this.explodeOnDeath = false;

    this.isMutating = false;
    this.mutationDelay = 0;
    this.hasMutated = false;
    this.canMutate = false;

    this.lastHitBy = undefined;
  }

  private tryMutate(): boolean {
    const wave = (window as any).currentWave ?? 1;
    if (wave < MUTATION_START_WAVE) return false;
    if (!this.canMutate) return false;
    if (this.hasMutated) return false;
    if (this.type !== EnemyType.Red) return false;

    const chance = getMutationChance(wave);
    if (chance <= 0) return false;

    if (Math.random() > chance) return false;

    const mutateType = Math.random() < 0.5
      ? EnemyType.Yellow
      : EnemyType.Gray;

    const stats = EnemyFactory.calculateStatsForType(mutateType, wave);

    this.type = mutateType;
    this.maxHealth = stats.maxHealth;
    this._health = stats.maxHealth * 0.5;
    this.speed = stats.speed;
    this.baseStats.speed = stats.speed;

    this.goldReward = Math.max(
      1,
      Math.floor(this.maxHealth * GOLD_HP_RATIO)
    );

    this.isMutating = true;
    this.mutationDelay = 1;
    this.hasMutated = true;

    return true;
  }

  public applyEffect(effect: StatusEffect): void {
    // Check if we already have a slow effect to prevent infinite stacking
    // For simplicity, we just add it, but we could also replace or extend
    this.effects.push({ ...effect });
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    if (this.isMutating) {
      this.mutationDelay -= dt;
      if (this.mutationDelay <= 0) {
        this.isMutating = false;
      }
      return;
    }

    this.timeAlive += dt;
    
    if (this.targetIndex >= this.path.length) return;

    // Process status effects
    updateEnemyEffects(this, dt);
    let isFrozen = false;
    
    // Process advanced synergy timers
    if (this.burnTimer && this.burnTimer > 0) {
      this.burnTimer -= dt;
      this.health -= ((this as any).burnDamage || 10) * dt; // Arbitrary safe burn damage
      if (this.burnTimer <= 0) this.burnTimer = 0;
    }
    
    if (this.freezeTimer && this.freezeTimer > 0) {
      this.freezeTimer -= dt;
      this.isFrozen = true;
      isFrozen = true;
      if (this.freezeTimer <= 0) {
        this.freezeTimer = 0;
        this.isFrozen = false;
      }
    } else {
      this.isFrozen = false;
    }

    const target = this.path[this.targetIndex];
    const dir = target.sub(this.position);
    const dist = dir.mag();

    // If close enough to the waypoint, move to the next one
    if (dist < 5) {
      this.targetIndex++;
      if (this.targetIndex >= this.path.length) {
        this.active = false; // Reached the end of the path
        this.reachedEnd = true;
      }
    } else {
      // Move towards the target waypoint
      const effectiveSpeed = isFrozen ? 0 : this.speed;
      const move = dir.normalize().mult(effectiveSpeed * dt);
      this.position = this.position.add(move);
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    if (!this.active) return;

    const isSlowed = this.effects.some(e => e.type === 'slow');
    const isBoss = this.type === EnemyType.BossRed || this.type === EnemyType.BossYellow || this.type === EnemyType.BossGray;

    let fillColor = '#ef4444'; // Red-500
    let strokeColor = '#991b1b'; // Red-800

    if (this.type === EnemyType.Yellow || this.type === EnemyType.BossYellow) {
      fillColor = '#eab308'; // Yellow-500
      strokeColor = '#854d0e'; // Yellow-800
    } else if (this.type === EnemyType.Gray || this.type === EnemyType.BossGray) {
      fillColor = '#6b7280'; // Gray-500
      strokeColor = '#374151'; // Gray-700
    }

    if (isSlowed) {
      fillColor = '#60a5fa'; // Blue-400
      strokeColor = '#2563eb'; // Blue-600
    }

    if (isBoss) {
      strokeColor = '#ffffff';
    }

    if (this.isMutating) {
      strokeColor = '#ffffff';
      ctx.lineWidth = 4;
    }

    // Draw enemy body
    ctx.beginPath();
    if (this.type === EnemyType.Yellow || this.type === EnemyType.BossYellow) {
      // Triangle
      ctx.moveTo(this.position.x, this.position.y - this.radius);
      ctx.lineTo(this.position.x + this.radius, this.position.y + this.radius);
      ctx.lineTo(this.position.x - this.radius, this.position.y + this.radius);
      ctx.closePath();
    } else if (this.type === EnemyType.Gray || this.type === EnemyType.BossGray) {
      // Square
      ctx.rect(this.position.x - this.radius, this.position.y - this.radius, this.radius * 2, this.radius * 2);
    } else {
      // Circle
      ctx.arc(this.position.x, this.position.y, this.radius, 0, Math.PI * 2);
    }

    ctx.fillStyle = fillColor;
    ctx.fill();
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = isBoss ? 4 : 2;
    ctx.stroke();

    // Draw HP bar
    const hpPercent = Math.max(0, this.health / this.maxHealth);
    ctx.fillStyle = '#333';
    ctx.fillRect(this.position.x - 15, this.position.y - this.radius - 10, 30, 4);
    ctx.fillStyle = '#22c55e'; // Green-500
    ctx.fillRect(this.position.x - 15, this.position.y - this.radius - 10, 30 * hpPercent, 4);

    if (this.shield > 0) {
      ctx.strokeStyle = '#3b82f6'; // blue-500
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(this.position.x, this.position.y, this.radius + 2, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
}
