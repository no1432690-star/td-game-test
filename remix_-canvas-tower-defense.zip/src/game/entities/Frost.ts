import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';
import { UpgradeManager } from '../systems/UpgradeManager';
import { applyDamage } from '../systems/BuffSystem';
import { ArtifactEventBus } from '../systems/artifactEventBus';
import { TowerEventSystem } from '../systems/tower/TowerEventSystem';
import { projectilePool } from '../pools/ProjectilePool';

export class Frost extends Tower {
  constructor(x: number, y: number) {
    super("frost", x, y, 100, 1.5, 10);
    this.baseCost = 75;
    this.baseSlowDuration = 2.0;
    this.baseSlowEffect = 0.5;
    this.maxVisualProjectiles = 2;
    this.recalculateFinalStats();
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, enemies?: Enemy[], activeProjectilesCount: number = 0): Projectile | null {
    ArtifactEventBus.emit("onAttack", {
      attacker: this,
      target
    });
    const damage = this.getCalculatedDamage(runModifiers, target, upgradeManager);
    
    // Calculate slow parameters
    let slowMultiplier = 0.5;
    let slowDuration = 2.0;
    
    if (this.flatSlowDuration > 0) {
      slowDuration = this.flatSlowDuration;
    }
    if (this.flatSlowEffect > 0) {
      slowMultiplier = Math.max(0.1, 1 - this.flatSlowEffect);
    }

    if (upgradeManager) {
      const slowPowerBonus = upgradeManager.getClassMultiplier("Frost", "slow_power") - 1.0;
      const slowDurationBonus = upgradeManager.getClassMultiplier("Frost", "slow_duration") - 1.0;
      slowMultiplier = Math.max(0.1, slowMultiplier - slowPowerBonus);
      slowDuration += slowDurationBonus;
    }

    if (this.level >= 3) {
      slowMultiplier = Math.min(slowMultiplier, Math.max(0.1, 0.2 - (upgradeManager ? upgradeManager.getClassMultiplier("Frost", "slow_power") - 1.0 : 0))); // Level 3 Special: Deep Freeze (80% slow)
      slowDuration = Math.max(slowDuration, 4.0 + (upgradeManager ? upgradeManager.getClassMultiplier("Frost", "slow_duration") - 1.0 : 0));
    }

    const relicBonuses = (window as any).gameInstance?.getRelicBonuses() || {};
    if (relicBonuses.slowDuration) {
      slowDuration *= (1 + relicBonuses.slowDuration);
    }

    // Apply damage and slow instantly
    if (this.corruptionType === 0 && Math.random() <= 0.2) { // CorruptionType.UnstableCore
      // Missed
    } else {
      target.lastHitBy = this;
      applyDamage(target, { amount: damage, type: 'magic', sourceTower: this, crit: false });
      
      TowerEventSystem.emit('onHitEnemy', {
        sourceTower: this,
        targetEnemy: target,
        damage: damage,
        towerType: this.constructor.name
      });
      
      target.applyEffect({ type: 'slow', value: 1 - slowMultiplier, multiplier: slowMultiplier, duration: slowDuration });
      
      if (runModifiers?.freezeChance && Math.random() < runModifiers.freezeChance) {
        target.freezeTimer = 2.0;
      }
      
      if (runModifiers?.explodeOnDeath) {
        target.explodeOnDeath = true;
      }
      
      if (target.health <= 0) {
        target.active = false;
      }

      // Multi-target slow
      if (this.multiTargetSlow > 1 && enemies) {
        let count = 1;
        const nearby = enemies
          .filter(e => e.active && e !== target && e.position.dist(target.position) <= 100)
          .sort((a, b) => a.position.dist(target.position) - b.position.dist(target.position));
        
        for (const enemy of nearby) {
          if (count >= this.multiTargetSlow) break;
          enemy.applyEffect({ type: 'slow', value: 1 - slowMultiplier, multiplier: slowMultiplier, duration: slowDuration });
          count++;
        }
      }
    }

    // Visual projectile logic
    if (this.visualProjectileCount >= this.maxVisualProjectiles || activeProjectilesCount >= 120) {
      return null;
    }
    
    this.visualProjectileCount++;
    const p = projectilePool.get();
    if (p.reset) {
      p.reset(this.position, target, damage, this, 'frost');
    }
    return p;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    const cx = this.position.x, cy = this.position.y;
    const color = '#38bdf8', mid = '#0284c7', dim = '#082f49';
    const sides = 3, rot = -Math.PI / 2;

    const poly = (r: number, s: number, rotation: number) => {
      ctx.beginPath();
      for (let i = 0; i < s; i++) {
        const a = (i / s) * Math.PI * 2 + rotation;
        i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
                : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };

    poly(22, sides, rot);
    ctx.strokeStyle = color + '44'; ctx.lineWidth = 1; ctx.stroke();

    poly(18, sides, rot);
    ctx.fillStyle = dim; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();

    poly(11, sides, rot + Math.PI / sides);
    ctx.fillStyle = '#0a1828'; ctx.fill();
    ctx.strokeStyle = mid + 'aa'; ctx.lineWidth = 1; ctx.stroke();

    for (let k = 0; k < sides; k++) {
      const a1 = (k / sides) * Math.PI * 2 + rot;
      const a2 = ((k + 1) / sides) * Math.PI * 2 + rot;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a1) * 11, cy + Math.sin(a1) * 11);
      ctx.lineTo(cx + Math.cos(a1) * 18, cy + Math.sin(a1) * 18);
      ctx.lineTo(cx + Math.cos((a1 + a2) / 2) * 21, cy + Math.sin((a1 + a2) / 2) * 21);
      ctx.lineTo(cx + Math.cos(a2) * 18, cy + Math.sin(a2) * 18);
      ctx.lineTo(cx + Math.cos(a2) * 11, cy + Math.sin(a2) * 11);
      ctx.closePath();
      ctx.fillStyle = k % 2 === 0 ? color + '30' : color + '10';
      ctx.fill();
    }

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 7 : 4;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 3.5 : 2;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.globalAlpha = 0.7; ctx.fill(); ctx.globalAlpha = 1;

    ctx.beginPath(); ctx.arc(cx - 1, cy - 1, 1.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();

    this.drawLevel(ctx);
  }
}
