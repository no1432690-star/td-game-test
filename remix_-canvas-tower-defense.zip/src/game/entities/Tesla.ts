import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { Vector2 } from '../utils/Vector2';
import { RunModifiers } from '../systems/RunSystem';
import { UpgradeManager } from '../systems/UpgradeManager';
import { applyDamage } from '../systems/BuffSystem';
import { ArtifactEventBus } from '../systems/artifactEventBus';
import { TeslaSystem } from '../systems/TeslaSystem';
import { TowerLinkManager } from '../systems/tower/TowerLinkManager';
import { ENABLE_TESLA_DEBUG_FORCE } from '../systems/TeslaTopologySystem';

export class Tesla extends Tower {
  public chainTargets: number = 2;
  public flowMode: string = "BALANCED";
  public flowTarget: any = null;
  public energy: number = 100;
  public nextEnergy: number = 100;
  public depth: number = 0;
  public visited: boolean = false;

  constructor(x: number, y: number) {
    super("tesla", x, y, 150, 1.4, 5);
    this.baseCost = 220;
    this.maxVisualProjectiles = 0;
    if (ENABLE_TESLA_DEBUG_FORCE) {
        this.flowMode = "FOCUSED";
    }
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, enemies?: Enemy[], activeProjectilesCount: number = 0): Projectile | null {
    ArtifactEventBus.emit("onAttack", {
      attacker: this,
      target
    });
    this.lightningTimer = 0.2;
    this.lightningPath = [];

    const hitEnemies = new Set<Enemy>();
    let currentTarget: Enemy | null = target;
    let currentDamage = this.getCalculatedDamage(runModifiers, target, upgradeManager);
    let currentPos = this.position.clone();

    let shockChance = 0.10;
    let shockDuration = 2.0;
    
    if (upgradeManager) {
        const staticCharge = upgradeManager.getRawClassStat('Tesla', 'static_charge');
        shockChance += staticCharge * 0.08;
        shockDuration += staticCharge * 0.4;
    }

    if (this.isCorrupted) {
        if (this.corruptionType === 0) { // Overloaded Core
            shockChance += 0.30;
            shockDuration += 2.0;
        } else if (this.corruptionType === 1) { // Arc Reactor
            this.chainTargets += 1;
            // Cooldown +20% handled in stats
        } else if (this.corruptionType === 2) { // Wild Current
            if (Math.random() < 0.20 && enemies) {
                const randomEnemy = enemies.find(e => e.active && e.position.dist(this.position) <= 120);
                if (randomEnemy) {
                    applyDamage(randomEnemy, { amount: currentDamage * 0.5, type: 'magic', sourceTower: this, crit: false });
                    this.lightningPath.push(randomEnemy.position.clone());
                }
            }
        }
    }

    const selfBuffs = TeslaSystem.getTeslaSelfBuffs(this);
    shockChance += selfBuffs.shockChance;
    
    let chainRange = 100 + selfBuffs.chainRange;

    for (let i = 0; i <= this.chainTargets; i++) {
      if (!currentTarget) break;
      
      this.lightningPath.push(currentTarget.position.clone());
      hitEnemies.add(currentTarget);

      currentTarget.lastHitBy = this;
      applyDamage(currentTarget, { amount: currentDamage, type: 'magic', sourceTower: this, crit: false });
      
      if (Math.random() < shockChance) {
        currentTarget.applyEffect({ type: 'shock', value: 0.15, duration: shockDuration });
      }

      if (currentTarget.health <= 0) {
        currentTarget.active = false;
      }

      let chainDamageMult = 0.8;
      let overloadChance = 0;
      
      if (upgradeManager) {
          chainDamageMult += upgradeManager.getRawClassStat('Tesla', 'tesla_chain_damage');
          overloadChance += upgradeManager.getRawClassStat('Tesla', 'tesla_chain_overload');
      }

      currentDamage *= chainDamageMult;
      
      let nextTarget: Enemy | null = null;
      let minTargetDist = Infinity;

      if (i < this.chainTargets && enemies) {
        for (const e of enemies) {
          if (e.active && !hitEnemies.has(e)) {
            const dist = currentTarget.position.dist(e.position);
            if (dist < chainRange && dist < minTargetDist) {
              minTargetDist = dist;
              nextTarget = e;
            }
          }
        }
      }
      
      if (nextTarget && Math.random() < overloadChance) {
          // Overload: Next target takes 2x damage and gets stunned
          currentDamage *= 2;
          nextTarget.applyEffect({ type: 'stun', value: 1, duration: 1.5 });
      }
      
      currentTarget = nextTarget;
    }

    return null;
  }

  public lightningTimer: number = 0;
  public lightningPath: Vector2[] = [];

  public update(dt: number, enemies: Enemy[], runModifiers?: RunModifiers, upgradeManager?: UpgradeManager, activeProjectilesCount: number = 0): Projectile[] {
    if (this.lightningTimer > 0) {
      this.lightningTimer -= dt;
    }
    
    // Apply attack speed from self buffs
    const selfBuffs = TeslaSystem.getTeslaSelfBuffs(this);
    const oldAttackSpeed = this.baseAttackSpeed;
    this.baseAttackSpeed *= (1 + selfBuffs.attackSpeed);
    
    if (this.isCorrupted && this.corruptionType === 1) { // Arc Reactor
        this.baseAttackSpeed *= 0.8; // Cooldown +20%
    }

    const proj = super.update(dt, enemies, runModifiers, upgradeManager, activeProjectilesCount);
    
    this.baseAttackSpeed = oldAttackSpeed;
    return proj;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    const isSelected = (window as any).gameInstance?.selectedTower === this;

    if (isSelected) {
      const radius = TeslaSystem.getElectricFieldRadius(this, (window as any).gameInstance?.upgradeManager);
      ctx.beginPath();
      ctx.arc(this.position.x, this.position.y, radius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(14, 165, 233, 0.2)'; // Blue circle, 20% opacity
      ctx.fill();
      ctx.strokeStyle = 'rgba(14, 165, 233, 0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.closePath();

      // Draw links
      const allTowers = (window as any).gameInstance?.towers || [];
      for (const tower of allTowers) {
        if (tower.teslaLinks && tower.teslaLinks.includes(this)) {
          ctx.beginPath();
          ctx.moveTo(this.position.x, this.position.y);
          ctx.lineTo(tower.position.x, tower.position.y);
          
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)'; // Thin blue electric lines
          ctx.lineWidth = 1;
          ctx.setLineDash([5, 5]);
          ctx.stroke();
          ctx.closePath();
          ctx.setLineDash([]);
        }
      }
    }

    // Network visuals
    const inGrid = TeslaSystem.isTeslaInGrid(this);
    if (inGrid) {
      const gridType = TeslaSystem.getGridType(this);
      ctx.beginPath();
      ctx.arc(this.position.x, this.position.y, 18, 0, Math.PI * 2);
      
      if (gridType === 'Chaos') ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)'; // Red
      else if (gridType === 'Heavenly') ctx.strokeStyle = 'rgba(250, 204, 21, 0.8)'; // Gold
      else if (gridType === 'Hybrid') ctx.strokeStyle = 'rgba(168, 85, 247, 0.8)'; // Purple
      else ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)'; // Normal Blue
      
      ctx.lineWidth = 2;
      ctx.setLineDash([2, 4]);
      ctx.stroke();
      ctx.closePath();
      ctx.setLineDash([]);
    }

    const cx = this.position.x, cy = this.position.y;
    const color = '#facc15', mid = '#ca8a04', dim = '#1c1200';
    const sides = 4, rot = Math.PI / 4;

    const polyT = (r: number, s: number, rotation: number) => {
      ctx.beginPath();
      for (let i = 0; i < s; i++) {
        const a = (i / s) * Math.PI * 2 + rotation;
        i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
                : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };

    polyT(22, sides, rot);
    ctx.strokeStyle = color + '44'; ctx.lineWidth = 1; ctx.stroke();

    polyT(18, sides, rot);
    ctx.fillStyle = dim; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();

    polyT(11, sides, rot + Math.PI / sides);
    ctx.fillStyle = '#0a1828'; ctx.fill();
    ctx.strokeStyle = mid + 'aa'; ctx.lineWidth = 1; ctx.stroke();

    for (let k = 0; k < sides; k++) {
      const a1 = (k / sides) * Math.PI * 2 + rot;
      const a2 = ((k + 1) / sides) * Math.PI * 2 + rot;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a1) * 11, cy + Math.sin(a1) * 11);
      ctx.lineTo(cx + Math.cos(a1) * 18, cy + Math.sin(a1) * 18);
      ctx.lineTo(cx + Math.cos((a1 + a2) / 2) * 21, cy + Math.sin((a1 + a2) / 2) * 21);
      ctx.lineTo(cx + Math.cos(a2) * 18, cy + Math.sin(a2) * 18);
      ctx.lineTo(cx + Math.cos(a2) * 11, cy + Math.sin(a2) * 11);
      ctx.closePath();
      ctx.fillStyle = k % 2 === 0 ? color + '30' : color + '10';
      ctx.fill();
    }

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 7 : 4;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? 3.5 : 2;
      const a = (i / 8) * Math.PI * 2 + Math.PI / 4;
      i === 0 ? ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r)
              : ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.globalAlpha = 0.7; ctx.fill(); ctx.globalAlpha = 1;

    ctx.beginPath(); ctx.arc(cx - 1, cy - 1, 1.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();

    if (this.lightningTimer > 0 && this.lightningPath.length > 0) {
      ctx.beginPath();
      ctx.moveTo(this.position.x, this.position.y);
      for (const pos of this.lightningPath) {
        ctx.lineTo(pos.x, pos.y);
      }
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.closePath();
    }

    this.drawLevel(ctx);
  }
}
