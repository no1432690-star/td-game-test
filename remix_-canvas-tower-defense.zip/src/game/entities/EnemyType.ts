export enum EnemyType {
  Red = 'Red',
  Yellow = 'Yellow',
  Gray = 'Gray',
  BossRed = 'BossRed',
  BossYellow = 'BossYellow',
  BossGray = 'BossGray'
}
