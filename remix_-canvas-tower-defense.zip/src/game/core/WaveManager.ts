import { Enemy } from '../entities/Enemy';
import { Map } from './Map';
import { difficultyScaler } from './DifficultyScaler';
import { DifficultySystem } from '../systems/DifficultySystem';
import { EnemyType } from '../entities/EnemyType';
import { EnemyFactory } from '../entities/EnemyFactory';
import { getDifficultyMultiplier } from '../../meta/difficultyModifiers';
import { defaultMetaProgression } from '../../meta/metaProgression';
import { StarterTowerSystem } from '../start/StarterTowerSystem';
import { checkArtifactTemporalSurge } from '../systems/artifactHooks';

export class WaveManager {
  public wave: number = 1;
  public isWaveActive: boolean = false;
  public waveDelayTimer: number = 3.0; // 3 seconds before first wave
  
  private spawnTimer: number = 0;
  private spawnInterval: number = 1.0; // 1 second between spawns
  private readonly waveDelay: number = 5.0; // 5 seconds between waves
  
  private spentThreat: number = 0;
  public spawnCount: number = 0;
  private spawnedCount: number = 0;
  public difficultySystem: DifficultySystem;

  constructor(public map: Map, private enemies: Enemy[], private enemyPool: Enemy[]) {
    this.difficultySystem = new DifficultySystem();
  }

  public reset(): void {
    this.wave = 1;
    this.isWaveActive = false;
    this.waveDelayTimer = 3.0;
    this.spawnTimer = 0;
    this.spentThreat = 0;
    this.spawnCount = 0;
    this.spawnedCount = 0;
    difficultyScaler.reset();
    this.difficultySystem.reset();
    this.difficultySystem.updateForWave(this.wave);
  }

  public update(dt: number): void {
    if (StarterTowerSystem.active) {
      return;
    }

    (window as any).currentWave = this.wave;
    difficultyScaler.update(dt);

    if (!this.isWaveActive) {
      this.waveDelayTimer -= dt;
      if (this.waveDelayTimer <= 0) {
        this.startWave();
      }
      return;
    }

    // Spawning logic
    const canSpawn = this.spawnedCount < this.spawnCount;

    if (canSpawn) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        try {
          this.spawnEnemy();
          this.spawnedCount++;
          const multipliers = this.difficultySystem.getCurrentMultipliers();
          this.spawnInterval = multipliers.spawnRate;
          this.spawnTimer = this.spawnInterval;
        } catch (e) {
          console.error("Spawn error, falling back", e);
          this.spawnTimer = this.spawnInterval;
        }
      }
    } else if (this.enemies.length === 0) {
      // Wave complete when all enemies are spawned and destroyed/reached end
      this.endWave();
    }
  }

  private startWave(): void {
    this.isWaveActive = true;
    this.spentThreat = 0;
    this.spawnTimer = 0; // Spawn first enemy immediately
    this.difficultySystem.updateForWave(this.wave);

    const game = (window as any).gameInstance;
    if (game) {
      checkArtifactTemporalSurge(game, (buff) => {
        // applyGlobalBuff logic
        // For example, add to a global buff list or apply to all towers
        // The prompt says: applyGlobalBuff({ attackSpeed: 1 + fx.temporal_surge.bonusAS, duration: fx.temporal_surge.duration })
        // Let's add it to the run system modifiers temporarily
        const run = game.runSystem.modifiers;
        const originalSpeed = run.speedMultiplier;
        run.speedMultiplier *= buff.attackSpeed;
        
        // We need a timer to revert this.
        // Let's just use a simple setTimeout since it's a global buff
        setTimeout(() => {
          run.speedMultiplier = originalSpeed;
        }, buff.duration * 1000);
      });
    }

    this.spawnCount = 6 + Math.floor(Math.pow(this.wave, 1.2));
    if (this.wave <= 2) {
      this.spawnCount = Math.max(4, this.spawnCount - 2);
    }
    this.spawnedCount = 0;
  }

  private endWave(): void {
    this.isWaveActive = false;
    this.wave++;
    this.waveDelayTimer = this.waveDelay;
  }

  private getEnemyTypeForWave(): EnemyType {

    // Early waves
    if (this.wave <= 4) return EnemyType.Red;

    // Wave 5 Boss
    if (this.wave === 5) {
      if (this.spawnedCount === 0) return EnemyType.BossRed;
      return EnemyType.Red;
    }

    // Wave 6–9
    if (this.wave >= 6 && this.wave <= 9) {
      const r = Math.random();
      if (r < 0.7) return EnemyType.Red;
      return EnemyType.Yellow;
    }

    // Wave 10 Boss
    if (this.wave === 10) {
      if (this.spawnedCount === 0) return EnemyType.BossYellow;
      const r = Math.random();
      if (r < 0.6) return EnemyType.Red;
      return EnemyType.Yellow;
    }

    // Wave 11–14
    if (this.wave >= 11 && this.wave <= 14) {
      const r = Math.random();
      if (r < 0.5) return EnemyType.Red;
      if (r < 0.8) return EnemyType.Yellow;
      return EnemyType.Gray;
    }

    // Wave 15 Boss
    if (this.wave === 15) {
      if (this.spawnedCount === 0) return EnemyType.BossGray;
      const r = Math.random();
      if (r < 0.4) return EnemyType.Red;
      if (r < 0.75) return EnemyType.Yellow;
      return EnemyType.Gray;
    }

    // Wave 16+
    const r = Math.random();
    if (r < 0.45) return EnemyType.Red;
    if (r < 0.75) return EnemyType.Yellow;
    return EnemyType.Gray;
  }

  private spawnEnemy(): void {
    const type = this.getEnemyTypeForWave();
    const enemy = EnemyFactory.create(type, this.wave, this.map.waypoints, this.enemyPool);
    
    const multipliers = this.difficultySystem.getCurrentMultipliers();
    const corruption = this.difficultySystem.getCorruptionModifiers();
    
    // Meta Difficulty Multipliers
    const gameInstance = (window as any).gameInstance;
    const metaProgression = gameInstance?.newMetaProgression || defaultMetaProgression;
    const metaDifficulty = getDifficultyMultiplier(metaProgression);
    
    // Apply difficulty multipliers
    enemy.maxHealth *= multipliers.hp * metaDifficulty.hpMultiplier;
    
    // Apply relic scaling
    const relicBonuses = gameInstance?.getRelicBonuses?.() || {};
    const relicDamageBonus = relicBonuses.atkPercent || 0;
    enemy.maxHealth = difficultyScaler.getEnemyHealth(
      enemy.maxHealth,
      this.wave,
      relicDamageBonus
    );
    
    enemy.health = enemy.maxHealth;
    
    if (this.wave > 1) {
      enemy.speed *= multipliers.speed * metaDifficulty.speedMultiplier;
    }

    // Corruption
    enemy.shield = enemy.maxHealth * corruption.enemyShieldMultiplier;
    enemy.maxShield = enemy.shield;
    enemy.deathSpawnMini = corruption.enemyDeathSpawnMini;
    
    // Mutation
    enemy.canMutate = this.wave >= 50;
    
    this.enemies.push(enemy);
    this.spentThreat += enemy.threatCost;
  }

  public spawnMini(position: { x: number, y: number }, targetIndex: number): void {
    let enemy: Enemy;
    if (this.enemyPool.length > 0) {
      enemy = this.enemyPool.pop()!;
      enemy.reset(this.map.waypoints);
    } else {
      enemy = new Enemy(this.map.waypoints);
    }
    
    const multipliers = this.difficultySystem.getCurrentMultipliers();
    
    // Meta Difficulty Multipliers
    const gameInstance = (window as any).gameInstance;
    const metaProgression = gameInstance?.newMetaProgression || defaultMetaProgression;
    const metaDifficulty = getDifficultyMultiplier(metaProgression);
    
    enemy.maxHealth = 50 * multipliers.hp * metaDifficulty.hpMultiplier;
    
    // Apply relic scaling
    const relicBonuses = gameInstance?.getRelicBonuses?.() || {};
    const relicDamageBonus = relicBonuses.atkPercent || 0;
    enemy.maxHealth = difficultyScaler.getEnemyHealth(
      enemy.maxHealth,
      this.wave,
      relicDamageBonus
    );
    
    enemy.health = enemy.maxHealth;
    
    const baseSpeed = 75; // Minis are faster
    enemy.speed = baseSpeed + (this.wave - 1) * 5;
    enemy.speed = Math.max(40, enemy.speed);
    
    if (this.wave > 1) {
      enemy.speed *= multipliers.speed * metaDifficulty.speedMultiplier;
    }

    enemy.position.x = position.x + (Math.random() * 20 - 10);
    enemy.position.y = position.y + (Math.random() * 20 - 10);
    enemy.setTargetIndex(targetIndex);
    enemy.threatCost = 0;
    enemy.shield = 0;
    enemy.maxShield = 0;
    enemy.deathSpawnMini = 0;
    enemy.canMutate = false; // Minis cannot mutate
    
    this.enemies.push(enemy);
  }
}
