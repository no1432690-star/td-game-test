export interface MetaState {
  ink: number;
  upgrades: {
    damage: number; // level
    gold: number; // level
    life: number; // level
    crit: number; // level
  };
  corruptedMeta?: {
    metaShards: number;
    totalShardsSpentEver: number;
  };
}

export interface MetaBonuses {
  damageMultiplier: number;
  goldMultiplier: number;
  extraLife: number;
  critChance: number;
}

export class MetaSystem {
  private static readonly STORAGE_KEY = 'td_meta_save';

  public static load(): MetaState {
    const data = localStorage.getItem(this.STORAGE_KEY);
    if (data) {
      try {
        const save = JSON.parse(data);
        if (!save.corruptedMeta) {
          save.corruptedMeta = {
            metaShards: 0,
            totalShardsSpentEver: 0
          };
        }
        return save;
      } catch (e) {
        console.error('Failed to parse meta save', e);
      }
    }
    return {
      ink: 0,
      upgrades: {
        damage: 0,
        gold: 0,
        life: 0,
        crit: 0
      },
      corruptedMeta: {
        metaShards: 0,
        totalShardsSpentEver: 0
      }
    };
  }

  public static save(state: MetaState): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(state));
  }

  public static getBonuses(state: MetaState): MetaBonuses {
    return {
      damageMultiplier: 1 + state.upgrades.damage * 0.1, // +10% base damage per level
      goldMultiplier: 1 + state.upgrades.gold * 0.1, // +10% starting gold per level
      extraLife: state.upgrades.life * 5, // +5 starting lives per level
      critChance: state.upgrades.crit * 0.05 // +5% crit chance per level
    };
  }
}
