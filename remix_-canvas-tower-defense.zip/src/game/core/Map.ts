import { Vector2 } from '../utils/Vector2';
import { Tower } from '../entities/Tower';
import { loadRandomMap } from '../maps/MapManager';
import { SlotEconomy } from '../economy/SlotEconomy';

export interface BuildSlot {
  id: number;
  position: Vector2;
  occupied: boolean;
  tower?: Tower;
  tier?: number;
  unlocked?: boolean;
  unlockCost?: number;
}

export interface SavedMapData {
  name: string;
  waypoints: Array<{ x: number; y: number }>;
  buildSlots: Array<{
    id: number;
    x: number;
    y: number;
    tier?: number;
    unlocked?: boolean;
    unlockCost?: number;
  }>;
}

export class Map {
  public name: string;
  public waypoints: Vector2[];
  public buildSlots: BuildSlot[];
  public unlockedSlots: number = 3;

  constructor(savedMapData?: SavedMapData) {
    if (savedMapData) {
      this.name = savedMapData.name;
      
      this.waypoints = savedMapData.waypoints.map(
        (w) => new Vector2(w.x, w.y)
      );
      
      this.buildSlots = savedMapData.buildSlots.map((s) => ({
        id: s.id,
        position: new Vector2(s.x, s.y),
        occupied: false,
        tier: s.tier,
        unlocked: s.unlocked ?? false,
        unlockCost: s.unlockCost ?? 0,
      }));
      
    } else {
      const selectedMap = loadRandomMap();
      this.name = selectedMap.name || 'UNKNOWN';
      
      if (selectedMap && selectedMap.path && selectedMap.path.length > 0) {
        this.waypoints = selectedMap.path.map(p => new Vector2(p.x, p.y));
      } else {
        // Fallback
        this.waypoints = [
          new Vector2(0, 300),
          new Vector2(200, 300),
          new Vector2(200, 100),
          new Vector2(600, 100),
          new Vector2(600, 500),
          new Vector2(800, 500),
          new Vector2(800, 300),
          new Vector2(1200, 300)
        ];
      }

      if (selectedMap && selectedMap.slots && selectedMap.slots.length > 0) {
        this.buildSlots = selectedMap.slots.map((slot, index) => ({
          id: index,
          position: new Vector2(slot.x, slot.y),
          occupied: false,
          tier: slot.tier,
          unlocked: slot.unlocked,
          unlockCost: slot.unlockCost
        }));
      } else {
        // Fallback
        const rawSlots = [
          new Vector2(100, 240), new Vector2(100, 360), new Vector2(260, 200),
          new Vector2(140, 200), new Vector2(300, 40),  new Vector2(300, 160),
          new Vector2(500, 40),  new Vector2(500, 160), new Vector2(540, 300),
          new Vector2(660, 300), new Vector2(700, 440), new Vector2(700, 560),
          new Vector2(900, 240), new Vector2(900, 360)
        ];

        this.buildSlots = rawSlots.map((pos, index) => ({
          id: index,
          position: pos,
          occupied: false,
          unlocked: index < 3,
          unlockCost: index < 3 ? 0 : 10000
        }));
      }

      this.buildSlots.forEach((slot, index) => {
        const cost = SlotEconomy.getUnlockCost(index);
        slot.unlockCost = cost;
        slot.unlocked = cost === 0;
      });
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    // Draw Path
    if (this.waypoints.length > 0) {
      ctx.beginPath();
      ctx.moveTo(this.waypoints[0].x, this.waypoints[0].y);
      for (let i = 1; i < this.waypoints.length; i++) {
        ctx.lineTo(this.waypoints[i].x, this.waypoints[i].y);
      }
      ctx.strokeStyle = '#374151'; // Gray-700
      ctx.lineWidth = 40;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
      
      // Draw path center line for clarity
      ctx.strokeStyle = '#4b5563'; // Gray-600
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Draw Build Slots
    for (const slot of this.buildSlots) {
      ctx.beginPath();
      ctx.arc(slot.position.x, slot.position.y, 20, 0, Math.PI * 2);
      
      const isUnlocked = slot.unlocked !== undefined ? slot.unlocked : true;

      if (isUnlocked) {
        ctx.fillStyle = 'rgba(59, 130, 246, 0.2)'; // Blue-500 with opacity
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.5)';
      } else {
        ctx.fillStyle = 'rgba(75, 85, 99, 0.2)'; // Gray-600 with opacity
        ctx.strokeStyle = 'rgba(75, 85, 99, 0.5)';
      }
      
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.closePath();

      if (!isUnlocked) {
        // Draw a small lock icon or X for locked slots
        ctx.beginPath();
        ctx.moveTo(slot.position.x - 5, slot.position.y - 5);
        ctx.lineTo(slot.position.x + 5, slot.position.y + 5);
        ctx.moveTo(slot.position.x + 5, slot.position.y - 5);
        ctx.lineTo(slot.position.x - 5, slot.position.y + 5);
        ctx.strokeStyle = 'rgba(156, 163, 175, 0.5)'; // Gray-400
        ctx.lineWidth = 2;
        ctx.stroke();

        if (slot.unlockCost) {
          ctx.fillStyle = '#fbbf24'; // Amber-400
          ctx.font = '10px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`Unlock: ${slot.unlockCost}`, slot.position.x, slot.position.y + 15);
        }
      }
    }

    // Draw Base (End Node)
    const endNode = this.waypoints[this.waypoints.length - 1];
    ctx.beginPath();
    ctx.arc(endNode.x, endNode.y, 30, 0, Math.PI * 2);
    ctx.fillStyle = '#3b82f6'; // Blue-500
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('BASE', endNode.x, endNode.y);
    ctx.textAlign = 'left'; // Reset
  }
}
