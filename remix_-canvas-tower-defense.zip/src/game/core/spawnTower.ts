import { Tower } from "../entities/Tower"

export function spawnTower(type: string, x: number, y: number) {

  const tower = new Tower(type, x, y)
  if(!tower.targetMode){
    tower.targetMode = "first"
  }
  return tower

}
