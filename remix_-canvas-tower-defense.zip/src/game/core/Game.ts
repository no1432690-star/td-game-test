import { Loop } from './Loop';
import { ArtifactEventBus } from '../systems/artifactEventBus';
import { applyArtifactsForRun } from '../systems/applyArtifactsForRun';
import { Map } from './Map';
import { WaveManager } from './WaveManager';
import { MetaSystem, MetaState, MetaBonuses } from './MetaSystem';
import { GameState } from './GameState';
import { RunSystem } from '../systems/RunSystem';
import { TowerDraftSystem } from '../systems/TowerDraftSystem';
import { SynergySystem } from '../systems/SynergySystem';
import { updateTeslaNetwork } from '../systems/BuffSystem';
import { UpgradeManager, ENABLE_TESLA_UPGRADES } from '../systems/UpgradeManager';
import { CorruptedShardManager } from '../systems/CorruptedShardManager';
import { Enemy } from '../entities/Enemy';
import { Vector2 } from '../utils/Vector2';
import { Tower } from '../entities/Tower';
import { Archer } from '../entities/Archer';
import { Bomber } from '../entities/Bomber';
import { Frost } from '../entities/Frost';
import { Tesla } from '../entities/Tesla';
import { LegendaryTower } from '../entities/LegendaryTower';
import { Projectile } from '../entities/Projectile';
import { gameStateManager, uiManager, metaSaveManager, metaProgression } from '../../core/MenuSystem';
import { createGameOverMenu } from '../../ui/menu/GameOverMenu';
import { GameState as MenuGameState } from '../../core/GameState';
import { MutationRewardSystem } from '../../systems/mutation/MutationRewardSystem';
import { getTowerBorderColor } from '../../ui/render/TowerVisualSystem';
import { enemyGrid } from '../spatial/EnemyGrid';
import { TeslaSystem } from '../systems/TeslaSystem';
import { projectilePool } from '../pools/ProjectilePool';
import { Camera } from '../camera/Camera';
import { CameraController } from '../camera/CameraController';
import { DebugSpeed } from '../debug/DebugSpeed';
import { StarterTowerSystem } from '../start/StarterTowerSystem';
import { ENABLE_TOWER_MERGE } from '../../config';
import { TowerEventSystem } from '../systems/tower/TowerEventSystem';
import { EffectManager } from '../systems/tower/EffectManager';
import { DamagePipeline } from '../systems/tower/DamagePipeline';
import { SynergyManager } from '../systems/tower/SynergyManager';
import { TowerLinkManager } from '../systems/tower/TowerLinkManager';
import { TowerNetworkManager } from '../systems/tower/TowerNetworkManager';
import { TowerRegistry } from '../systems/tower/TowerRegistry';
import { TowerSpatialGrid } from '../systems/tower/TowerSpatialGrid';
import { BuffVisualizer } from '../systems/tower/BuffVisualizer';
import { SynergyGuard } from '../systems/tower/SynergyGuard';
import { GameTimerManager } from '../systems/tower/GameTimerManager';
import { ContentValidator } from '../systems/tower/ContentValidator';
import { RunUpgradeManager } from '../systems/tower/RunUpgradeManager';
import { CorruptionManager } from '../systems/tower/CorruptionManager';
import { LegendaryManager } from '../systems/tower/LegendaryManager';
import { TowerFactory } from '../systems/tower/TowerFactory';
import { ProjectileRenderer } from '../systems/render/ProjectileRenderer';
import { cycleTeslaFlowMode } from '../systems/TeslaTopologySystem';
import { RUN_SAVE_KEY } from '../systems/saveConfig';
import { initArtifacts, addArtifact, computeAllArtifacts } from '../systems/artifactEngine';
import { ARTIFACT_DEFS } from '../systems/artifactDefinitions';
import { updateArtifactEffects, applyArtifactGold, applyArtifactOnKill, shouldFreeReroll } from '../systems/artifactHooks';

export function getNearbyEnemies(x: number, y: number, radius: number) {
  return enemyGrid.getEnemiesNear(x, y, radius);
}

export enum IntermissionMode {
  None = 'None',
  Artifact = 'Artifact',
  Upgrade = 'Upgrade',
  Draft = 'Draft',
  Placement = 'Placement',
  GameOver = 'GameOver'
}

import { ArtifactSystem } from '../systems/ArtifactSystem';

import { PrestigeSystem } from '../systems/PrestigeSystem';
import { RelicShopSystem } from '../systems/relic/RelicShopSystem';

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private loop: Loop;
  private map: Map;
  private waveManager: WaveManager;
  public runSystem: RunSystem;
  public draftSystem: TowerDraftSystem;
  public upgradeManager: UpgradeManager;
  public artifactSystem: ArtifactSystem;
  public prestigeSystem: PrestigeSystem;
  public relicShopSystem: RelicShopSystem;
  
  public metaState: MetaState;
  public metaBonuses: MetaBonuses;
  public relicBonuses: any;
  
  public gold: number;
  public totalGoldEarned: number = 0;
  public lives: number;
  public costMultiplier: number = 1;

  public intermissionMode: IntermissionMode = IntermissionMode.None;
  public selectedDraftType: string | null = null;
  public pendingStarterTower: string | null = null;
  public isPlacingTower: boolean = false;
  public selectedTower: Tower | null = null;

  public isGameOver: boolean = false;

  private mouseX: number = 0;
  private mouseY: number = 0;
  private screenMouseX: number = 0;
  private screenMouseY: number = 0;
  private hoveredSlotId: number | null = null;
  private hoveredTower: Tower | null = null;
  private buildEffects: { x: number; y: number; timer: number }[] = [];
  public lightningEffects: { start: Vector2; end: Vector2; timer: number; color?: string }[] = [];
  private goldPopups: { x: number; y: number; value: number; timer: number }[] = [];

  private mutationWarningActive: boolean = false;
  private mutationWarningTimer: number = 0;
  private lastMutationWaveShown: number = 0;

  private draftRerollCount: number = 0;
  private draftRerollBaseCost: number = 50;

  private enemies: Enemy[] = [];
  private enemyPool: Enemy[] = [];
  private towers: Tower[] = [];
  private projectiles: Projectile[] = [];

  // Engine State
  public artifacts: { id: string, stacks: number }[] = [];
  public artifactEffects: Record<string, number> = {};
  public speedMultiplier: number = 1.0;
  public isPaused: boolean = false;
  private timeElapsed: number = 0;
  private frameCount: number = 0;

  private teslaUpdateTimer: number = 0;

  public camera?: Camera;
  public cameraController?: CameraController;
  private isContinuingRun: boolean = false;

  constructor(canvas: HTMLCanvasElement, continueRun: boolean = false) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('Could not get 2D context');
    }
    this.ctx = context;
    
    (window as any).gameInstance = this;

    this.isContinuingRun = continueRun;

    this.runSystem = new RunSystem();
    this.draftSystem = new TowerDraftSystem();
    this.upgradeManager = new UpgradeManager();
    this.artifactSystem = new ArtifactSystem();
    this.prestigeSystem = new PrestigeSystem(metaSaveManager);
    this.relicShopSystem = new RelicShopSystem();
    this.relicBonuses = {};

    ContentValidator.validate();
    RunUpgradeManager.init();
    CorruptionManager.init();
    LegendaryManager.init();
    initArtifacts(this);

    // Test artifacts
    addArtifact(this, "golden_momentum", 3);
    const effects = computeAllArtifacts(this, ARTIFACT_DEFS, {
      wave: 60,
      gold: 2000000
    });
    console.log("Artifact Effects:", effects);

    // Load Meta System
    this.metaState = MetaSystem.load();

    const manager = CorruptedShardManager.instance;
    manager.metaShards = this.metaState.corruptedMeta?.metaShards ?? 0;
    manager.totalShardsSpentEver = this.metaState.corruptedMeta?.totalShardsSpentEver ?? 0;
    
    // For testing purposes, give some initial meta upgrades if empty
    if (this.metaState.ink === 0 && this.metaState.upgrades.damage === 0) {
      this.metaState.ink = 500;
      this.metaState.upgrades.damage = 2; // +20% damage
      this.metaState.upgrades.crit = 2;   // +10% crit chance
      this.metaState.upgrades.gold = 1;   // +10% starting gold
      this.metaState.upgrades.life = 1;   // +5 starting lives
      MetaSystem.save(this.metaState);
    }
    
    // Calculate bonuses ONCE at game start
    this.metaBonuses = MetaSystem.getBonuses(this.metaState);

    // Apply starting resources based on meta
    this.gold = Math.floor(100 * this.metaBonuses.goldMultiplier);
    this.lives = 20 + this.metaBonuses.extraLife;

    if (continueRun) {
      const savedMapData = this.loadMapDataFromSave();
      if (savedMapData) {
        this.map = new Map(savedMapData);
        console.log('[Game] Map restored from save:', savedMapData.name);
      } else {
        console.warn('[Game] No saved map data, creating new map');
        this.map = new Map();
      }
    } else {
      this.map = new Map();
      console.log('[Game] New random map created:', this.map.name);
    }

    // Initialize WaveManager
    this.waveManager = new WaveManager(this.map, this.enemies, this.enemyPool);

    this.initializeNewGame();

    // Initialize Loop
    this.loop = new Loop(this.update.bind(this), this.draw.bind(this));

    // Handle Resize
    this.resize();
    window.addEventListener('resize', this.resize.bind(this));
    
    this.camera = new Camera(
      this.canvas.width,
      this.canvas.height,
      1600,
      900
    );
    this.cameraController = new CameraController(this.camera);

    this.canvas.addEventListener('mousedown', (e) => {
      this.cameraController?.onMouseDown(e.clientX, e.clientY);
    });
    this.canvas.addEventListener('mouseup', () => {
      this.cameraController?.onMouseUp();
    });
    this.canvas.addEventListener('mousemove', (e) => {
      this.cameraController?.onMouseMove(e.clientX, e.clientY);
      this.handleMouseMove(e);
    });
    this.canvas.addEventListener('wheel', (e) => {
      this.cameraController?.onWheel(e.deltaY);
    });
    
    this.canvas.addEventListener('click', this.handleClick.bind(this));
    this.canvas.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.handleRightClick(e);
    });
  }

  private loadMapDataFromSave(): any | null {
    try {
      const raw = localStorage.getItem(RUN_SAVE_KEY);
      if (!raw) return null;
      
      const save = JSON.parse(raw);
      if (!save || save.version < 2) {
        console.warn('[Game] Save version too old, cannot restore map');
        return null;
      }
      
      return save.mapData || null;
    } catch (e) {
      console.error('[Game] Failed to load map data from save', e);
      return null;
    }
  }

  private handleRightClick(e: MouseEvent): void {
    if (this.isGameOver || this.isPaused) return;

    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    let mouseX = (e.clientX - rect.left) * scaleX;
    let mouseY = (e.clientY - rect.top) * scaleY;

    if (this.camera) {
      const worldPos = this.camera.screenToWorld(mouseX, mouseY);
      mouseX = worldPos.x;
      mouseY = worldPos.y;
    }

    for (const slot of this.map.buildSlots) {
      const dx = slot.position.x - mouseX;
      const dy = slot.position.y - mouseY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 20) {
        if (slot.occupied && slot.tower && slot.tower.constructor.name === 'Tesla') {
          cycleTeslaFlowMode(slot.tower);
          break;
        }
      }
    }
  }

  public triggerGameOver(): void {
    this.isGameOver = true;
    this.isPaused = true;
    this.intermissionMode = IntermissionMode.GameOver;
    this.clearRunSave();

    const manager = CorruptedShardManager.instance;
    const retention = manager.currentRunShards * manager.getRetentionRate();
    manager.metaShards += Math.floor(retention);
    manager.currentRunShards = 0;
    manager.totalCorruptionsThisRun = 0;

    if (!this.metaState.corruptedMeta) {
      this.metaState.corruptedMeta = { metaShards: 0, totalShardsSpentEver: 0 };
    }
    this.metaState.corruptedMeta.metaShards = manager.metaShards;
    this.metaState.corruptedMeta.totalShardsSpentEver = manager.totalShardsSpentEver;
    MetaSystem.save(this.metaState);

    const currentWave = this.waveManager.wave;
    metaSaveManager.recordRun(currentWave);
    metaProgression.grantEndRunShards(currentWave);

    // Grant Ink: wave × 2, persists across runs
    try {
      const inkReward = currentWave * 2;
      this.metaState.ink = (this.metaState.ink || 0) + inkReward;
      
      const voidEssenceReward = Math.floor(currentWave / 10);
      if (voidEssenceReward > 0) {
        if (this.metaState.voidEssence === undefined) this.metaState.voidEssence = 0;
        if (!this.metaState.voidEssenceHistory) {
          this.metaState.voidEssenceHistory = { gained: 0, spent: 0, netBalance: 0 };
        }
        this.metaState.voidEssence += voidEssenceReward;
        this.metaState.voidEssenceHistory.gained += voidEssenceReward;
        this.metaState.voidEssenceHistory.netBalance = this.metaState.voidEssenceHistory.gained - this.metaState.voidEssenceHistory.spent;
      }
      
      MetaSystem.save(this.metaState);
    } catch (e) {
      console.warn('[Rewards] Failed to grant rewards', e);
    }

    try {
      gameStateManager.setState(MenuGameState.GAME_OVER);
    } catch (e) {
      console.error("Failed to set game over state", e);
    }
  }

  private getTowerBaseCost(type: string): number {
    const costMap: Record<string, number> = {
      Archer: 100,
      Bomber: 120,
      Frost: 110,
      CursedArcher: 110,
      Tesla: 220
    };
    return costMap[type] ?? 100;
  }

  private getFinalTowerCost(type: string): number {
    return Math.floor(
      this.getTowerBaseCost(type) * this.costMultiplier
    );
  }

  private handleMouseMove(event: MouseEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    let screenX = (event.clientX - rect.left) * scaleX;
    let screenY = (event.clientY - rect.top) * scaleY;

    this.screenMouseX = screenX;
    this.screenMouseY = screenY;

    if (this.camera) {
      const worldPos = this.camera.screenToWorld(screenX, screenY);
      this.mouseX = worldPos.x;
      this.mouseY = worldPos.y;
    } else {
      this.mouseX = screenX;
      this.mouseY = screenY;
    }

    this.hoveredSlotId = null;
    this.hoveredTower = null;
    
    // Check for hovered tower
    for (const tower of this.towers) {
      if (!tower) continue;
      const dx = tower.position.x - this.mouseX;
      const dy = tower.position.y - this.mouseY;
      if (Math.sqrt(dx * dx + dy * dy) < 20) {
        this.hoveredTower = tower;
        break;
      }
    }

    if (this.intermissionMode === IntermissionMode.Placement) {
      for (const slot of this.map.buildSlots) {
        const isUnlocked = slot.unlocked !== undefined ? slot.unlocked : (slot.id < this.map.unlockedSlots);
        if (!slot.occupied && isUnlocked) {
          const dx = slot.position.x - this.mouseX;
          const dy = slot.position.y - this.mouseY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 25) {
            this.hoveredSlotId = slot.id;
            break;
          }
        }
      }
    }
  }

  private handleClick(event: MouseEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    let screenX = (event.clientX - rect.left) * scaleX;
    let screenY = (event.clientY - rect.top) * scaleY;

    let mouseX = screenX;
    let mouseY = screenY;

    if (this.camera) {
      const worldPos = this.camera.screenToWorld(screenX, screenY);
      mouseX = worldPos.x;
      mouseY = worldPos.y;
    }

    // STEP 1 & 3: Prioritize UI click handling & Expand button hitbox
    const towerUI = document.getElementById("tower-ui");
    if (towerUI && towerUI.innerHTML !== "") {
      const buttons = towerUI.getElementsByTagName("button");
      for (let i = 0; i < buttons.length; i++) {
        const btn = buttons[i];
        const btnRect = btn.getBoundingClientRect();
        const padding = 6;
        
        if (
          event.clientX >= btnRect.left - padding &&
          event.clientX <= btnRect.right + padding &&
          event.clientY >= btnRect.top - padding &&
          event.clientY <= btnRect.bottom + padding
        ) {
          if (btn.innerText.includes("Upgrade") || btn.innerText.includes("MAX LEVEL")) {
            this.upgradeSelectedTower();
            return;
          } else if (btn.id === "target-mode-btn") {
            this.cycleTowerTargetMode();
            return;
          } else if (btn.innerText.includes("Corrupt")) {
            if (btn.onmouseup) {
              btn.onmouseup(new MouseEvent('mouseup') as any);
            }
            return;
          }
        }
      }

      // STEP 2 & 5: Prevent deselect on UI click / Ignore canvas click
      const uiRect = towerUI.getBoundingClientRect();
      if (
        event.clientX >= uiRect.left &&
        event.clientX <= uiRect.right &&
        event.clientY >= uiRect.top &&
        event.clientY <= uiRect.bottom
      ) {
        return;
      }
    }

    if (this.intermissionMode === IntermissionMode.Placement && (this.selectedDraftType || this.pendingStarterTower)) {
      for (const slot of this.map.buildSlots) {
        const dx = slot.position.x - mouseX;
        const dy = slot.position.y - mouseY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 20) { // slot radius
          const isUnlocked = slot.unlocked !== undefined ? slot.unlocked : true;
          
          if (!isUnlocked) {
            this.tryUnlockSlot(slot);
            return; // Don't place tower, just unlocked or failed to unlock
          }

          if (slot.occupied) {
            return;
          }

          const draftType = this.selectedDraftType || this.pendingStarterTower;
          let newTower: Tower | null = null;
          let isCursed = false;

          // STEP 1: Validate tower type
          if (!draftType || !['Archer', 'Bomber', 'Frost', 'CursedArcher', 'Tesla'].includes(draftType)) {
            console.error("Invalid tower type:", draftType);
            return;
          }

          // STEP 3: Validate grid position
          if (!slot || slot.position.x < 0 || slot.position.y < 0) {
            return;
          }

          // STEP 2: Safe tower creation
          if (draftType === 'CursedArcher') {
            newTower = TowerFactory.create('Archer', slot.position.x, slot.position.y, this.enemies);
            isCursed = true;
          } else {
            newTower = TowerFactory.create(draftType, slot.position.x, slot.position.y, this.enemies);
          }

          if (!newTower) {
            console.error("Missing tower data");
            return;
          }

          if(!newTower.targetMode){
            newTower.targetMode = "first"
          }

          if (newTower) {
            const finalCost = this.pendingStarterTower ? 0 : this.getFinalTowerCost(draftType);
            if (this.gold < finalCost) {
              return;
            }
            if (this.gold >= finalCost) {
              this.gold -= finalCost;
              newTower.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance, isCursed);
              
              // STEP 5: Safe array insert
              if (newTower) {
                this.towers.push(newTower);
                TowerRegistry.addTower(newTower);
                TowerEventSystem.emit('onTowerPlaced', { sourceTower: newTower });
              }
              
              slot.occupied = true;
              slot.tower = newTower;
              
              // STEP 6: Debug log
              console.log("Tower placed:", draftType, slot.position.x, slot.position.y);
              
              if (draftType === 'Archer' || draftType === 'CursedArcher') {
                this.upgradeManager.registerBuiltTower('Archer');
              } else if (draftType === 'Bomber') {
                this.upgradeManager.registerBuiltTower('Bomber');
              } else if (draftType === 'Frost') {
                this.upgradeManager.registerBuiltTower('Frost');
              } else if (draftType === 'Tesla') {
                this.upgradeManager.registerBuiltTower('Tesla');
              }
              
              this.buildEffects.push({
                x: slot.position.x,
                y: slot.position.y,
                timer: 0.3
              });

              this.draftSystem.clearDraft();
              this.selectedDraftType = null;
              this.pendingStarterTower = null;
              this.intermissionMode = IntermissionMode.None;
              this.isPaused = false;
              this.isPlacingTower = false;
            }
          }
          break;
        }
      }
      return;
    }

    // Handle tower selection or slot unlocking
    let clickedTower = false;
    for (const slot of this.map.buildSlots) {
      const dx = slot.position.x - mouseX;
      const dy = slot.position.y - mouseY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 20) {
        const isUnlocked = slot.unlocked !== undefined ? slot.unlocked : true;
        
        if (!isUnlocked) {
          this.tryUnlockSlot(slot);
          clickedTower = true; // Prevent deselecting
          break;
        }

        if (slot.occupied && slot.tower) {
          this.selectedTower = slot.tower;
          clickedTower = true;
          break;
        }
      }
    }

    if (!clickedTower) {
      this.selectedTower = null;
    }
  }

  private tryUnlockSlot(slot: any): void {
    const cost = slot.unlockCost;
    if (cost && this.gold >= cost) {
      this.gold -= cost;
      slot.unlocked = true;
    }
  }

  public start(): void {
    this.loop.start();
  }

  private spawnStarterTower(): void {
    if (this.map.buildSlots.length > 0) {
      const slot = this.map.buildSlots[0];
      const starter = TowerFactory.create('Archer', slot.position.x, slot.position.y, this.enemies);
      if(!starter.targetMode){
        starter.targetMode = "first"
      }
      starter.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
      this.towers.push(starter);
      TowerRegistry.addTower(starter);
      TowerEventSystem.emit('onTowerPlaced', { sourceTower: starter });
      slot.occupied = true;
      slot.tower = starter;
    }
  }

  private initializeNewGame(): void {
    // === [PATCH] Artifact Run State Init ===
    if (!(window as any).__artifactPatch) {
      (window as any).__artifactPatch = true;

      (window as any).ArtifactRuntime = {
        ensure(runState: any) {
          if (!runState.artifacts || !Array.isArray(runState.artifacts)) {
            runState.artifacts = [];
          }
        },

        reset(runState: any) {
          runState.artifacts = [];
        }
      };
    }

    // === [PATCH] Reset artifacts on run start ===
    const state = this || (window as any).runState || (window as any).player || {};
    if ((window as any).ArtifactRuntime) {
      (window as any).ArtifactRuntime.reset(state);
    }

    if (!ENABLE_TOWER_MERGE) {
      console.log("Tower merge system disabled");
    }

    this.gold = Math.floor(100 * this.metaBonuses.goldMultiplier);
    this.totalGoldEarned = 0;
    this.timeElapsed = 0;
    this.lives = 20 + this.metaBonuses.extraLife;
    
    // IMPORTANT: Do not reassign arrays because WaveManager
    // holds references to them. Only clear contents.
    this.towers.length = 0;
    this.enemies.length = 0;
    this.projectiles.length = 0;
    
    this.selectedTower = null;
    
    // FIX: Only create new map if NOT continuing run
    if (!this.isContinuingRun) {
      console.log('[Game] Creating new map for fresh run');
      // Create a new map for each run
      this.map = new Map();
      this.map.unlockedSlots = 3;
      
      // Reset slots
      for (const slot of this.map.buildSlots) {
        slot.occupied = false;
        slot.tower = undefined;
      }

      // Update WaveManager with new map
      if (this.waveManager) {
        this.waveManager.map = this.map;
      }
    } else {
      console.log('[Game] Skipping map creation (continuing run, map already restored)');
      // Map already restored in constructor
      // loadRunState() will restore tower placements
    }
    
    // Reset flag after first init
    this.isContinuingRun = false;
    
    TowerEventSystem.clear();
    EffectManager.clear();
    DamagePipeline.clear();
    SynergyManager.clear();
    TowerLinkManager.clear();
    TowerNetworkManager.clear();
    TowerRegistry.clear();
    TowerSpatialGrid.clear();
    GameTimerManager.clear();
    
    TowerNetworkManager.init();
    SynergyManager.init();

    TeslaSystem.init(this.towers);

    applyArtifactsForRun(this, this.artifacts || []);

    StarterTowerSystem.start(['Archer', 'Bomber', 'Frost', 'Tesla']);
  }

  public restart(): void {
    this.isGameOver = false;
    this.intermissionMode = IntermissionMode.None;
    
    this.initializeNewGame();
    
    this.costMultiplier = 1;
    this.waveManager.reset();
    this.runSystem.reset();
    this.draftSystem.clearDraft();
    this.upgradeManager.resetRun();
    CorruptedShardManager.instance.resetRun();
    this.draftRerollCount = 0;
    this.timeElapsed = 0;
    this.frameCount = 0;
    this.isPaused = false;
  }

  public destroy(): void {
    this.loop.stop();
    window.removeEventListener('resize', this.resize.bind(this));
    this.enemies.length = 0;
    this.enemyPool.length = 0;
    this.projectiles.length = 0;
    this.towers.length = 0;
  }

  public setSpeed(multiplier: number): void {
    this.speedMultiplier = multiplier;
  }

  public togglePause(): void {
    this.isPaused = !this.isPaused;
  }

  public finishArtifactPhase(): void {
    this.artifactSystem.skipArtifacts();
    this.runSystem.generateUpgradeChoices(this.waveManager.wave, this.upgradeManager);
    this.draftRerollCount = 0;
    this.intermissionMode = IntermissionMode.Upgrade;
    this.isPaused = true;
  }

  public applyUpgrade(choiceId: string): void {
    this.runSystem.applyUpgrade(choiceId, this.upgradeManager);
    
    // Update Tesla links if an upgrade was applied
    TeslaSystem.onTeslaUpgraded(null as any, this.towers);
    
    // Generate draft AFTER upgrade selection
    if (this.draftSystem && this.waveManager) {
      this.draftSystem.generateDraft(
        this.waveManager.wave,
        Math.floor(this.waveManager.wave / 10)
      );
    }
    
    // Keep game paused for draft selection
    this.intermissionMode = IntermissionMode.Draft;
    this.isPaused = true;
  }

  public selectDraft(index: number): void {
    if (!this.draftSystem.pendingDraft) return;

    const draftItem = this.draftSystem.pendingDraft[index];
    if (!draftItem) return;

    this.selectedDraftType = draftItem.type;

    // Enter placement mode
    this.intermissionMode = IntermissionMode.Placement;
    this.isPaused = false;
    this.isPlacingTower = true;
  }

  public selectStarterTower(index: number): void {
    if (!StarterTowerSystem.active) return;
    
    const towerType = StarterTowerSystem.choose(index);
    if (!towerType) return;
    
    this.pendingStarterTower = towerType;
    this.intermissionMode = IntermissionMode.Placement;
    this.isPaused = false;
    this.isPlacingTower = true;
  }

  public skipDraft(): void {
    if (this.intermissionMode !== IntermissionMode.Draft) return;

    this.draftSystem.clearDraft();
    this.selectedDraftType = null;
    this.intermissionMode = IntermissionMode.None;
    this.isPaused = false;
  }

  public getRerollCost(): number {
    return this.draftRerollBaseCost + this.draftRerollCount * 25;
  }

  public rerollDraft(): void {
    if (this.intermissionMode !== IntermissionMode.Draft) return;

    const cost = this.getRerollCost();

    if (this.gold < cost) return;

    if (!shouldFreeReroll(this)) {
      this.gold -= cost;
      this.draftRerollCount++;
    }

    this.draftSystem.generateDraft(
      this.waveManager.wave,
      Math.floor(this.waveManager.wave / 10)
    );
  }

  public cancelPlacement(): void {
    if (this.intermissionMode === IntermissionMode.Placement) {
      if (this.pendingStarterTower) {
        StarterTowerSystem.active = true;
        StarterTowerSystem.choices = [this.pendingStarterTower, ...StarterTowerSystem.choices].slice(0, 3);
        this.pendingStarterTower = null;
        this.intermissionMode = IntermissionMode.None;
        this.isPaused = true;
        this.isPlacingTower = false;
        return;
      }
      this.selectedDraftType = null;
      this.isPlacingTower = false;
      this.intermissionMode = IntermissionMode.Draft;
      this.isPaused = true;
    } else if (this.intermissionMode === IntermissionMode.Draft) {
      this.draftSystem.clearDraft();
      this.selectedDraftType = null;
      this.isPlacingTower = false;
      this.intermissionMode = IntermissionMode.None;
      this.isPaused = false;
    }
  }

  public upgradeSelectedTower(): void {
    if (!this.selectedTower) return;

    const cost = this.selectedTower.getUpgradeCost();

    if (this.gold < cost) return;

    const success = this.selectedTower.upgrade();

    if (success) {
        this.gold -= cost;
    }
  }

  public saveRunState(): void {
    if (this.isGameOver) return;

    try {
      const towersData = this.towers
        .filter(t => t && !t.isLegendary)
        .map(t => {
          const slot = this.map.buildSlots.find(s => s.tower === t);
          if (!slot) return null;
          return {
            type: t.constructor.name.toLowerCase(),
            slotId: slot.id,
            level: t.level,
            targetMode: t.targetMode,
            corruptionType: t.corruptionType !== null && t.corruptionType !== undefined
              ? String(t.corruptionType)
              : null
          };
        })
        .filter(Boolean);

      const unlockedSlotIds = this.map.buildSlots
        .filter(s => s.unlocked)
        .map(s => s.id);

      const runSave = {
        version: 2,
        wave: this.waveManager.wave,
        gold: this.gold,
        totalGoldEarned: this.totalGoldEarned,
        timeElapsed: this.timeElapsed,
        lives: this.lives,
        unlockedSlotIds,
        towers: towersData,
        upgradeStacks: { ...this.upgradeManager.stacks },
        activeTags: Array.from(this.upgradeManager.activeTags),
        runModifiers: { ...this.runSystem.modifiers },
        costMultiplier: this.costMultiplier,
        mapData: {
          name: this.map.name,
          waypoints: this.map.waypoints.map(w => ({ x: w.x, y: w.y })),
          buildSlots: this.map.buildSlots.map(s => ({
            id: s.id,
            x: s.position.x,
            y: s.position.y,
            tier: s.tier,
            unlocked: s.unlocked,
            unlockCost: s.unlockCost,
          })),
        },
      };

      localStorage.setItem(RUN_SAVE_KEY, JSON.stringify(runSave));
    } catch (e) {
      console.warn('[RunSave] Failed to save run state', e);
    }
  }

  public loadRunState(): boolean {
    try {
      const raw = localStorage.getItem(RUN_SAVE_KEY);
      if (!raw) return false;

      const save = JSON.parse(raw);
      if (!save || save.version < 2) {
        console.warn('[RunSave] Save version too old or invalid');
        localStorage.removeItem(RUN_SAVE_KEY);
        return false;
      }

      // Restore basic state
      this.waveManager.wave = save.wave ?? 1;
      this.gold = save.gold ?? 100;
      this.totalGoldEarned = save.totalGoldEarned ?? 0;
      this.timeElapsed = save.timeElapsed ?? 0;
      this.lives = save.lives ?? 20;
      this.costMultiplier = save.costMultiplier ?? 1;

      // Restore unlocked slots
      if (Array.isArray(save.unlockedSlotIds)) {
        for (const slot of this.map.buildSlots) {
          slot.unlocked = save.unlockedSlotIds.includes(slot.id);
          slot.occupied = false;
          slot.tower = undefined;
        }
      }

      // Restore run modifiers
      if (save.runModifiers) {
        Object.assign(this.runSystem.modifiers, save.runModifiers);
      }

      // Restore upgrade stacks
      if (save.upgradeStacks) {
        this.upgradeManager.stacks = { ...save.upgradeStacks };
      }

      // Restore activeTags
      if (Array.isArray(save.activeTags)) {
        this.upgradeManager.activeTags = new Set(save.activeTags);
      }

      // Restore towers
      if (Array.isArray(save.towers)) {
        for (const td of save.towers) {
          if (!td) continue;
          try {
            const slot = this.map.buildSlots.find(s => s.id === td.slotId);
            if (!slot || !slot.unlocked) continue;

            const tower = TowerFactory.create(td.type, slot.position.x, slot.position.y, this.enemies);
            if (!tower) continue;

            // Restore level by upgrading repeatedly (no cost)
            for (let i = 1; i < (td.level ?? 1); i++) {
              tower.level++;
              tower.applyLevelScaling?.();
            }
            tower.recalculateFinalStats?.(this.runSystem.modifiers);

            if (td.targetMode) tower.targetMode = td.targetMode;

            if (td.corruptionType !== null && td.corruptionType !== undefined) {
              tower.corruptionType = td.corruptionType;
              tower.isCorrupted = true;
            }

            tower.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance, false);

            slot.occupied = true;
            slot.tower = tower;
            this.towers.push(tower);
            TowerRegistry.addTower(tower);
            TowerEventSystem.emit('onTowerPlaced', { sourceTower: tower });
          } catch (towerErr) {
            console.warn('[RunSave] Failed to restore tower', td, towerErr);
          }
        }
      }

      // Update Tesla network after all towers are placed
      TeslaSystem.init(this.towers);

      // Tắt StarterTowerSystem vì run đã được restore — không cần chọn tháp đầu game
      StarterTowerSystem.active = false;
      StarterTowerSystem.choices = [];

      console.log('[RunSave] Run state loaded successfully');
      return true;
    } catch (e) {
      console.warn('[RunSave] Failed to load run state', e);
      localStorage.removeItem(RUN_SAVE_KEY);
      return false;
    }
  }

  public clearRunSave(): void {
    try {
      localStorage.removeItem(RUN_SAVE_KEY);
    } catch (e) {}
  }

  public sellSelectedTower(): void {
    if (!this.selectedTower) return;

    const tower = this.selectedTower;

    // Refund 50% of base cost * level
    const refund = Math.floor(tower.baseCost * tower.level * 0.5);
    this.gold += refund;

    // Remove from towers array
    this.towers = this.towers.filter(t => t !== tower);

    // Clear slot
    const slot = this.map.buildSlots.find(s => s.tower === tower);
    if (slot) {
      slot.occupied = false;
      slot.tower = undefined;
    }

    // Cleanup systems
    TowerRegistry.removeTower(tower);
    TowerEventSystem.emit('onTowerRemoved', { sourceTower: tower });

    this.selectedTower = null;
  }

  public selectTowerByIndex(index: number): void {
    // index is 0-based (key "1" → index 0)
    const occupiedSlots = this.map.buildSlots.filter(s => s.occupied && s.tower);
    if (index < occupiedSlots.length) {
      this.selectedTower = occupiedSlots[index].tower!;
    }
  }

  public cycleTowerTargetMode(): void {
    if (this.selectedTower) {
      this.selectedTower.cycleTargetMode();
    }
  }

  public getNextSlotPrice(): number {
    // New map system
    const firstLockedSlot = this.map.buildSlots.find(s => s.unlocked === false);
    if (firstLockedSlot && firstLockedSlot.unlockCost !== undefined) {
      return firstLockedSlot.unlockCost;
    }

    // Fallback
    const BASE_SLOT_COST = 125;
    return BASE_SLOT_COST + this.map.unlockedSlots * 75;
  }

  public buySlot(): void {
    const price = this.getNextSlotPrice();
    if (this.gold < price) return;

    // New map system
    const firstLockedSlot = this.map.buildSlots.find(s => s.unlocked === false);
    if (firstLockedSlot) {
      this.gold -= price;
      firstLockedSlot.unlocked = true;
      return;
    }

    // Fallback
    if (this.map.unlockedSlots >= this.map.buildSlots.length) return;
    this.gold -= price;
    this.map.unlockedSlots++;
  }

  getRelicBonuses() {
    return this.relicBonuses;
  }

  public getRunStats() {
    return {
      highestWave: this.waveManager.wave,
      totalTimeSeconds: this.timeElapsed || 0,
      livesRemaining: this.lives,
      startingLives: 20,
      totalGoldEarned: this.totalGoldEarned || 0,
      previousHighest: metaSaveManager.getSave().statistics.highestWave || 0,
      prestigeStreak: metaSaveManager.getSave().statistics.prestigeStreak || 0,
    };
  }

  public getState(): GameState {
    let nextBaseDamage = 0;
    let nextFinalDamage = 0;
    let nextAttackSpeed = 0;
    let nextRange = 0;

    let currentDamage = 0;
    let currentAttackSpeed = 0;

    if (this.selectedTower) {
      const tower = this.selectedTower;
      
      currentDamage = tower.damage;
      currentAttackSpeed = tower.attackSpeed;

      // Simulate next level stats
      const DAMAGE_SCALE = 0.15;
      const SPEED_SCALE = 0.05;
      const RANGE_SCALE = 0.05;

      const nextBaseDamageSim = tower.baseDamage * (1 + DAMAGE_SCALE);
      const nextBaseAttackSpeedSim = tower.baseAttackSpeed * (1 + SPEED_SCALE);
      const nextBaseRangeSim = tower.baseRange * (1 + RANGE_SCALE);

      const run = this.runSystem.modifiers;
      const dmgMult = (run.damageMultiplier ?? 1) * tower.bonusDamageMultiplier;
      const spdMult = (run.speedMultiplier ?? 1) * tower.bonusSpeedMultiplier;
      const rngMult = (run.rangeMultiplier ?? 1) * tower.bonusRangeMultiplier;

      nextFinalDamage = nextBaseDamageSim * dmgMult;
      nextAttackSpeed = nextBaseAttackSpeedSim * spdMult;
      nextRange = nextBaseRangeSim * rngMult;
      
      // Milestones simulation
      const type = tower.constructor.name.toLowerCase();
      const nextLvl = tower.level + 1;
      
      if (nextLvl === 10 && type === "frost") {
        nextAttackSpeed *= 1.1;
      }
      if (nextLvl === 15 && (type === "archer" || type === "cursedarcher")) {
        nextAttackSpeed *= 1.5;
      }
    }

    return {
      gold: this.gold,
      lives: this.lives,
      wave: this.waveManager.wave,
      isWaveActive: this.waveManager.isWaveActive,
      waveDelayTimer: this.waveManager.waveDelayTimer,
      isPaused: this.isPaused,
      speedMultiplier: this.speedMultiplier,
      pendingUpgrades: this.runSystem.pendingChoices,
      activeTags: Array.from(this.upgradeManager.activeTags),
      pendingArtifacts: this.artifactSystem.pendingChoices,
      playerArtifacts: this.artifactSystem.playerArtifacts,
      artifacts: this.artifacts,
      artifactEffects: this.artifactEffects,
      upgradeTimer: this.runSystem.choiceTimer,
      pendingDraft: this.draftSystem.pendingDraft,
      intermissionMode: this.intermissionMode,
      selectedDraftType: this.selectedDraftType,
      costMultiplier: this.costMultiplier,
      nextSlotPrice: this.getNextSlotPrice(),
      unlockedSlots: this.map.buildSlots[0]?.unlocked !== undefined ? this.map.buildSlots.filter(s => s.unlocked).length : this.map.unlockedSlots,
      maxSlots: this.map.buildSlots.length,
      rerollCost: this.getRerollCost(),
      draftRerollCount: this.draftRerollCount,
      isGameOver: this.isGameOver,
      isPlacingTower: this.isPlacingTower,
      starterTowerActive: StarterTowerSystem.active,
      starterTowerChoices: StarterTowerSystem.choices,
      pendingStarterTower: this.pendingStarterTower,
      enemyScaling: {
        hp: this.waveManager.difficultySystem.enemyHpMultiplier,
        speed: this.waveManager.difficultySystem.enemySpeedMultiplier,
        spawnRate: this.waveManager.difficultySystem.spawnRateMultiplier
      },
      selectedTower: this.selectedTower ? {
        type: this.selectedTower.constructor.name,
        level: this.selectedTower.level,
        maxLevel: this.selectedTower.maxLevel,
        damage: currentDamage,
        nextDamage: nextFinalDamage,
        attackSpeed: currentAttackSpeed,
        nextAttackSpeed: nextAttackSpeed,
        range: this.selectedTower.range,
        nextRange: nextRange,
        upgradeCost: this.selectedTower.getUpgradeCost(),
        canUpgrade: this.selectedTower.canUpgrade(this.gold),
        targetMode: this.selectedTower.targetMode,
        isLegendary: this.selectedTower.isLegendary,
        corruptionType: this.selectedTower.corruptionType !== null ? this.selectedTower.corruptionType.toString() : null
      } : null,
      artifactShopRerollCount: this.artifactSystem.rerollCount,
      artifactShopRerollCost: this.artifactSystem.getRerollCost(),
      canRerollArtifact: this.artifactSystem.canReroll()
    };
  }

  private resize(): void {
    this.canvas.width = 1600;
    this.canvas.height = 900;
  }

  private checkLegendaryFusion(): void {
    if (!ENABLE_TOWER_MERGE) {
      return;
    }

    const counts: Record<string, Tower[]> = {};
    
    for (const tower of this.towers) {
      if (!tower) continue;
      if (!tower.targetMode) tower.targetMode = "first";
      if (tower.isLegendary) continue;
      
      const type = tower.constructor.name;
      if (!counts[type]) counts[type] = [];
      counts[type].push(tower);
    }
    
    for (const type in counts) {
      if (counts[type].length >= 5) {
        const toFuse = counts[type].slice(0, 5);
        
        // Remove from towers array
        this.towers = this.towers.filter(t => !toFuse.includes(t));
        for (const t of toFuse) {
          TowerRegistry.removeTower(t);
          TowerEventSystem.emit('onTowerRemoved', { sourceTower: t });
        }
        
        let targetSlot = null;
        
        for (const tower of toFuse) {
          const slot = this.map.buildSlots.find(s => s.tower === tower);
          if (slot) {
            if (!targetSlot) {
              targetSlot = slot;
            } else {
              slot.occupied = false;
              slot.tower = undefined;
            }
          }
        }
        
        const baseTower = toFuse[0];
        const legendary = new LegendaryTower(baseTower, type);
        if(!legendary.targetMode){
          legendary.targetMode = "first"
        }
        
        if (targetSlot) {
          legendary.position.x = targetSlot.position.x;
          legendary.position.y = targetSlot.position.y;
          targetSlot.occupied = true;
          targetSlot.tower = legendary;
        }
        
        this.towers.push(legendary);
        TowerRegistry.addTower(legendary);
        TowerEventSystem.emit('onTowerPlaced', { sourceTower: legendary });
        console.log(`Fused 5 ${type}s into a Legendary ${type}!`);
        
        break; // Only 1 fusion per frame
      }
    }
  }

  private update(rawDt: number): void {
    ArtifactEventBus.emit("onTick", { deltaTime: rawDt });
    if (this.isGameOver) return;
    if (gameStateManager.getState() === MenuGameState.PAUSED) return;

    if (this.frameCount % 60 === 0) {
      const metaSave = metaSaveManager.getSave();
      this.relicBonuses = this.relicShopSystem.calculateAllBonuses(metaSave);
    }

    if (this.runSystem.pendingChoices) {
      const autoPicked = this.runSystem.update(rawDt, this.upgradeManager);
      if (autoPicked) {
        this.isPaused = false;
      }
    }

    if (this.isPaused) return;

    updateArtifactEffects(this);

    // Apply speed multiplier to delta time
    let dt = rawDt * this.speedMultiplier;
    dt = DebugSpeed.apply(dt);
    
    // Update build effects
    for (let i = this.buildEffects.length - 1; i >= 0; i--) {
      this.buildEffects[i].timer -= dt;
      if (this.buildEffects[i].timer <= 0) {
        this.buildEffects.splice(i, 1);
      }
    }

    // Update lightning effects
    for (let i = this.lightningEffects.length - 1; i >= 0; i--) {
      this.lightningEffects[i].timer -= dt;
      if (this.lightningEffects[i].timer <= 0) {
        this.lightningEffects.splice(i, 1);
      }
    }

    // Update gold popups
    for (let i = this.goldPopups.length - 1; i >= 0; i--) {
      this.goldPopups[i].timer -= dt;
      this.goldPopups[i].y -= 20 * dt; // Float upward
      if (this.goldPopups[i].timer <= 0) {
        this.goldPopups.splice(i, 1);
      }
    }

    this.timeElapsed += dt;
    this.frameCount++;

    const wasWaveActive = this.waveManager.isWaveActive;

    // Update WaveManager
    this.waveManager.update(dt);

    const currentWave = this.waveManager.wave ?? 1;

    if (
      currentWave >= 50 &&
      currentWave !== this.lastMutationWaveShown &&
      currentWave % 5 === 0
    ) {
      this.mutationWarningActive = true;
      this.mutationWarningTimer = 4; // seconds
      this.lastMutationWaveShown = currentWave;
      
      this.canvas.style.border = '3px solid red';
      setTimeout(() => {
        this.canvas.style.border = '';
      }, 500);
    }

    if (this.mutationWarningActive) {
      this.mutationWarningTimer -= dt;
      if (this.mutationWarningTimer <= 0) {
        this.mutationWarningActive = false;
      }
    }

    if (wasWaveActive && !this.waveManager.isWaveActive) {
      if ((this.waveManager.wave - 1) % 5 === 0) {
        // New map system
        const firstLockedSlot = this.map.buildSlots.find(s => s.unlocked === false);
        if (firstLockedSlot) {
          firstLockedSlot.unlocked = true;
        } else {
          // Fallback
          this.map.unlockedSlots = Math.min(this.map.buildSlots.length, this.map.unlockedSlots + 1);
        }
      }
      if ((this.waveManager.wave - 1) % 3 === 0 && this.waveManager.wave > 1) {
        this.costMultiplier = Math.min(3, this.costMultiplier + 0.05);
      }

      const completedWave = this.waveManager.wave - 1;
      if (completedWave >= 40 && (completedWave - 40) % 10 === 0) {
        this.artifactSystem.generateChoices();
        this.artifactSystem.resetReroll();
        this.intermissionMode = IntermissionMode.Artifact;
        this.isPaused = true;
      } else {
        this.runSystem.generateUpgradeChoices(this.waveManager.wave, this.upgradeManager);
        
        // FORCE TEST
        if (this.waveManager.wave === 2 && ENABLE_TESLA_UPGRADES) {
            const hasTesla = this.towers.some(t => t && t.constructor.name === 'Tesla');
            if (hasTesla) {
                this.runSystem.pendingChoices = [
                    { id: "tesla_amp_current", name: "⚡ Amplified Current", description: "+15% Tesla buff strength", type: "tesla_buff_global", value: 0.15, rarity: "Rare" },
                    { id: "tesla_chain_expansion", name: "⚡ Chain Expansion", description: "+1 max Tesla links per tower", type: "tesla_max_links", value: 1, rarity: "Rare" },
                    { id: "tesla_energy_surge", name: "⚡ Energy Surge", description: "+25 Tesla starting energy", type: "tesla_energy_bonus", value: 25, rarity: "Rare" }
                ];
            }
        }
        
        this.draftRerollCount = 0;
        this.intermissionMode = IntermissionMode.Upgrade;
        this.isPaused = true;
      }

      // Auto-save run state after every wave
      this.saveRunState();

    } else if (!wasWaveActive && this.waveManager.isWaveActive) {
      // Wave started
      for (const tower of this.towers) {
        if (!tower) continue;
        if (!tower.targetMode) tower.targetMode = "first";
        tower.applyOverclockDecay();
      }
    }

    // Populate Spatial Grid
    enemyGrid.clear();
    for (const enemy of this.enemies) {
      enemyGrid.add(enemy);
    }

    GameTimerManager.update(dt);
    EffectManager.update(dt);
    updateTeslaNetwork(this.towers, this.artifactSystem);
    // TeslaSystem.update is no longer needed as it uses GameTimerManager

    // Update towers
    const corruption = this.waveManager.difficultySystem.getCorruptionModifiers();
    const baseModifiers = {
      ...this.runSystem.modifiers,
      speedMultiplier: this.runSystem.modifiers.speedMultiplier * corruption.towerFireRateMultiplier,
      goldMultiplier: this.runSystem.modifiers.goldMultiplier * corruption.goldRewardMultiplier
    };

    const synergies = SynergySystem.calculateAdvanced(this.towers);
    if (ENABLE_TOWER_MERGE) {
      this.checkLegendaryFusion();
    }

    for (const tower of this.towers) {
      if (!tower) continue;
      if (!tower.targetMode) tower.targetMode = "first";
      const type = tower.constructor.name;
      const count = synergies.perType[type] || 0;
      const synergyBonus = SynergySystem.getDamageBonus(type, count);
      
      const combinedModifiers = {
        ...baseModifiers,
        damageMultiplier: baseModifiers.damageMultiplier * synergyBonus,
        crossArcherFrost: baseModifiers.crossArcherFrost || (this.upgradeManager.stacks["synergy_archer_frost"] > 0),
        crossBomberFrost: baseModifiers.crossBomberFrost || (this.upgradeManager.stacks["synergy_bomber_frost"] > 0),
        crossArcherBomber: baseModifiers.crossArcherBomber || (this.upgradeManager.stacks["synergy_archer_bomber"] > 0)
      };

      // Apply per-type scaling
      if (type === 'Archer' || type === 'CursedArcher') {
        if (count >= 2) combinedModifiers.critChanceBonus = 0.10;
        if (count >= 3) combinedModifiers.critDamageBonus = 0.20;
        if (count >= 4) combinedModifiers.speedMultiplier *= 1.25;
        if (count >= 5) combinedModifiers.guaranteedCrit = true;
      } else if (type === 'Bomber') {
        if (count >= 2) combinedModifiers.explosionRadiusBonus = 0.15;
        if (count >= 3) combinedModifiers.applyBurn = true;
        if (count >= 4) combinedModifiers.miniExplosionChance = 0.25;
        if (count >= 5) combinedModifiers.doubleExplosionChance = 0.20;
      } else if (type === 'Frost') {
        if (count >= 2) combinedModifiers.slowBonus = 0.30;
        if (count >= 3) combinedModifiers.damageToSlowedBonus = 0.15;
        if (count >= 4) combinedModifiers.freezeChance = 0.10; // Small freeze chance
        if (count >= 5) combinedModifiers.explodeOnDeath = true;
      }

      const spawnedProjectiles = tower.update(dt, this.enemies, combinedModifiers, this.upgradeManager, this.projectiles.length);
      if (spawnedProjectiles && spawnedProjectiles.length > 0) {
        this.projectiles.push(...spawnedProjectiles);
      }
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.update(dt);
      if (!p.active) {
        projectilePool.release(p);
        this.projectiles.splice(i, 1);
      }
    }

    // Update enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.update(dt);
      
      // Remove inactive enemies (e.g., reached the end or died)
      if (!enemy.active) {
        if (enemy.reachedEnd) {
          this.lives--;
        }

        if (enemy.health <= 0) {
          ArtifactEventBus.emit("onKill", {
            killer: enemy.lastHitBy,
            enemy
          });

          let reward = Math.floor(
            enemy.goldReward *
            this.runSystem.modifiers.goldMultiplier
          );

          if (enemy.lastHitBy && enemy.lastHitBy.corruptionType === 1) { // CorruptionType.BloodPact
            reward = Math.floor(reward * 0.5);
          }

          reward = applyArtifactGold(reward, this);

          const relicBonuses = this.getRelicBonuses() || {};
          if (relicBonuses.goldBonus) {
            reward *= (1 + relicBonuses.goldBonus);
          }

          this.gold += Math.floor(reward);
          this.totalGoldEarned += Math.floor(reward);

          applyArtifactOnKill(enemy, this, (pos, dmg) => {
            const nearby = getNearbyEnemies(pos.x, pos.y, 150);
            for (const n of nearby) {
              n.health -= dmg;
            }
          });

          const shards = MutationRewardSystem.getShardDrop(enemy.type);
          if (shards > 0) {
            metaSaveManager.addShards(shards);
          }

          if (enemy.hasMutated) {
            let shardDrop = 1 + Math.floor(Math.random() * 4); // 1–4

            if (enemy.lastHitBy?.corruptionType === 4) { // CorruptionType.Firework
              shardDrop = 1 + Math.floor(Math.random() * 2); // 1–2 only
            }

            CorruptedShardManager.instance.addShards(shardDrop);
          }

          this.goldPopups.push({
            x: enemy.position.x,
            y: enemy.position.y,
            value: reward,
            timer: 0.6
          });

          if (enemy.deathSpawnMini > 0) {
            for (let j = 0; j < enemy.deathSpawnMini; j++) {
              this.waveManager.spawnMini(enemy.position, enemy.targetIndex);
            }
          }
          
          // Frost synergy: Frozen enemies explode on death
          if (enemy.explodeOnDeath && enemy.isFrozen) {
            for (const other of this.enemies) {
              if (other !== enemy && other.active && other.position.dist(enemy.position) <= 80) {
                other.health -= 50; // Arbitrary safe explosion damage
                if (other.health <= 0) other.active = false;
              }
            }
          }
        }
        
        if (this.lives <= 0) {
          this.triggerGameOver();
        }

        this.enemyPool.push(enemy);
        this.enemies.splice(i, 1);
      }
    }
  }

  private drawTeslaTooltip(tower: Tower): void {
    const lines: string[] = ['Tesla Buffs'];

    // Read generic buffs from BuffSystem
    const teslaBuffs = tower.buffs?.filter((b: any) => b.source === 'tesla') || [];
    
    // Aggregate buffs by stat
    const aggregatedBuffs: { [stat: string]: number } = {};
    for (const buff of teslaBuffs) {
      if (!aggregatedBuffs[buff.stat]) aggregatedBuffs[buff.stat] = 0;
      aggregatedBuffs[buff.stat] += buff.value;
    }

    // Format generic buffs
    for (const [stat, value] of Object.entries(aggregatedBuffs)) {
      const formattedStat = stat.replace(/([A-Z])/g, ' $1').toLowerCase();
      const formattedValue = `+${Math.round(value * 100)}%`;
      lines.push(`${formattedValue} ${formattedStat}`);
    }

    // Add specific hooks from TeslaSystem
    const typeName = tower.constructor.name === 'LegendaryTower' ? (tower as any).legendaryType : tower.constructor.name;
    
    if (typeName === 'Archer' || typeName === 'CursedArcher') {
      lines.push('Electrified Arrows');
    } else if (typeName === 'Bomber') {
      lines.push('Magnetic Detonation');
    } else if (typeName === 'Frost') {
      lines.push('Superconductor');
    } else if (typeName === 'Tesla') {
      const selfBuffs = TeslaSystem.getTeslaSelfBuffs(tower);
      if (selfBuffs.shockChance > 0) {
        lines.push(`+${Math.round(selfBuffs.shockChance * 100)}% shock chance`);
      }
      if (selfBuffs.chainRange > 0) {
        lines.push(`+${Math.round(selfBuffs.chainRange)} chain range`);
      }
    }

    // Draw Tooltip
    this.ctx.save();
    this.ctx.font = '12px monospace';
    
    let maxWidth = 0;
    for (const line of lines) {
      const width = this.ctx.measureText(line).width;
      if (width > maxWidth) maxWidth = width;
    }
    
    const padding = 8;
    const width = maxWidth + padding * 2;
    const height = lines.length * 16 + padding * 2;
    
    // Position near cursor
    let x = this.screenMouseX + 15;
    let y = this.screenMouseY + 15;
    
    // Keep on screen
    if (x + width > this.canvas.width) x = this.screenMouseX - width - 15;
    if (y + height > this.canvas.height) y = this.screenMouseY - height - 15;

    // Background
    this.ctx.fillStyle = 'rgba(15, 23, 42, 0.9)'; // Slate-900
    this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)'; // Blue border
    this.ctx.lineWidth = 1;
    this.ctx.fillRect(x, y, width, height);
    this.ctx.strokeRect(x, y, width, height);

    // Text
    for (let i = 0; i < lines.length; i++) {
      if (i === 0) {
        this.ctx.fillStyle = '#38bdf8'; // Sky-400 for title
        this.ctx.font = 'bold 12px monospace';
      } else {
        this.ctx.fillStyle = '#e2e8f0'; // Slate-200 for content
        this.ctx.font = '12px monospace';
      }
      this.ctx.fillText(lines[i], x + padding, y + padding + i * 16 + 10);
    }
    
    this.ctx.restore();
  }

  private draw(): void {
    // Clear screen
    this.ctx.fillStyle = '#111';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    this.ctx.save();
    if (this.camera) {
      this.ctx.scale(this.camera.zoom, this.camera.zoom);
      this.ctx.translate(-this.camera.x, -this.camera.y);
    }

    // Draw Map
    this.map.draw(this.ctx);

    if (this.intermissionMode === IntermissionMode.Placement && this.selectedDraftType) {
      this.ctx.globalAlpha = 0.5;

      let ghostX = this.mouseX;
      let ghostY = this.mouseY;
      let ghostTower: Tower | null = null;

      if (this.hoveredSlotId !== null) {
        const slot = this.map.buildSlots.find(s => s.id === this.hoveredSlotId);
        if (slot) {
          ghostX = slot.position.x;
          ghostY = slot.position.y;
        }
      }

      // Create ghost tower for preview
      if (this.selectedDraftType) {
        const type = this.selectedDraftType === 'CursedArcher' ? 'Archer' : this.selectedDraftType;
        ghostTower = TowerFactory.create(type, ghostX, ghostY, this.enemies);
      }

      // STEP 4: Prevent null preview tower
      if (ghostTower) {
        ghostTower.draw(this.ctx);
        
        // Draw range circle
        this.ctx.beginPath();
        this.ctx.arc(ghostX, ghostY, ghostTower.range, 0, Math.PI * 2);
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        this.ctx.fill();
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        this.ctx.closePath();
      } else {
        // Fallback
        this.ctx.beginPath();
        this.ctx.arc(ghostX, ghostY, 20, 0, Math.PI * 2);
        this.ctx.fillStyle = '#aaa';
        this.ctx.fill();
        this.ctx.closePath();
      }

      // Highlight valid slots
      for (const slot of this.map.buildSlots) {
        this.ctx.beginPath();
        this.ctx.arc(slot.position.x, slot.position.y, 20, 0, Math.PI * 2);
        
        const isUnlocked = slot.unlocked !== undefined ? slot.unlocked : (slot.id < this.map.unlockedSlots);

        if (!slot.occupied && isUnlocked) {
          if (slot.id === this.hoveredSlotId) {
            this.ctx.fillStyle = 'rgba(0, 255, 0, 0.6)';
            this.ctx.fill();
            this.ctx.strokeStyle = 'rgba(0, 255, 0, 1)';
            this.ctx.lineWidth = 2;
            this.ctx.stroke();
          } else {
            this.ctx.fillStyle = 'rgba(0, 255, 0, 0.3)';
            this.ctx.fill();
          }
        } else {
          this.ctx.fillStyle = 'rgba(255, 0, 0, 0.1)';
          this.ctx.fill();
        }
        
        this.ctx.closePath();
      }

      this.ctx.globalAlpha = 1.0;

      // Draw cost preview
      const finalCost = this.getFinalTowerCost(this.selectedDraftType);

      this.ctx.font = '14px monospace';
      this.ctx.textAlign = 'center';
      if (this.gold >= finalCost) {
        this.ctx.fillStyle = '#fff';
      } else {
        this.ctx.fillStyle = '#ff4444';
      }
      this.ctx.fillText(`Cost: ${finalCost}g`, ghostX, ghostY - 30);
    }

    // Draw Towers
    for (const tower of this.towers) {
      if (!tower) continue;
      if (!tower.targetMode) tower.targetMode = "first";
      
      // Tesla Buff Glow
      if (tower.activeTeslaLinks > 0) {
        const baseRadius = tower.constructor.name === 'LegendaryTower' ? 25 : 15;
        this.ctx.beginPath();
        this.ctx.arc(tower.position.x, tower.position.y, baseRadius + 4, 0, Math.PI * 2);
        this.ctx.fillStyle = 'rgba(56, 189, 248, 0.3)'; // Blue glow
        this.ctx.fill();
        this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        this.ctx.closePath();
      }

      tower.draw(this.ctx);
      
      // Phase 4: Render Visual Border
      if (tower.isLegendary || tower.isCorrupted) {
        const borderColor = getTowerBorderColor(tower);
        this.ctx.beginPath();
        this.ctx.arc(tower.position.x, tower.position.y, 18, 0, Math.PI * 2); // 18 is slightly larger than base tower radius (usually 15)
        this.ctx.strokeStyle = borderColor;
        this.ctx.lineWidth = 3;
        this.ctx.stroke();
        this.ctx.closePath();
      }
    }

    // Highlight selected tower
    if (this.selectedTower && !this.isPlacingTower) {
      this.ctx.beginPath();
      this.ctx.arc(this.selectedTower.position.x, this.selectedTower.position.y, this.selectedTower.range, 0, Math.PI * 2);
      this.ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      this.ctx.fill();
      this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
      this.ctx.closePath();
    }

    // Draw build effects
    for (const effect of this.buildEffects) {
      const progress = 1 - (effect.timer / 0.3);
      const radius = progress * 40;
      const alpha = effect.timer / 0.3;
      
      this.ctx.globalAlpha = alpha;
      this.ctx.beginPath();
      this.ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);
      this.ctx.strokeStyle = '#fff';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
      this.ctx.closePath();
    }
    this.ctx.globalAlpha = 1.0;

    // Draw lightning effects
    for (const effect of this.lightningEffects) {
      this.ctx.beginPath();
      this.ctx.moveTo(effect.start.x, effect.start.y);
      this.ctx.lineTo(effect.end.x, effect.end.y);
      this.ctx.strokeStyle = effect.color || '#38bdf8';
      this.ctx.lineWidth = 3;
      this.ctx.stroke();
      this.ctx.closePath();
    }

    // Render Tower Buffs and Links
    BuffVisualizer.render(this.ctx, this.selectedTower);

    // Draw Enemies
    for (const enemy of this.enemies) {
      enemy.draw(this.ctx);
    }

    // Draw gold popups
    this.ctx.font = 'bold 14px monospace';
    this.ctx.textAlign = 'center';
    for (const popup of this.goldPopups) {
      const alpha = Math.max(0, popup.timer / 0.6);
      this.ctx.globalAlpha = alpha;
      this.ctx.fillStyle = '#fbbf24'; // amber-400
      this.ctx.fillText(`+${popup.value}g`, popup.x, popup.y);
    }
    this.ctx.globalAlpha = 1.0;

    // Draw Projectiles
    ProjectileRenderer.render(this.ctx, this.projectiles);

    this.ctx.restore();

    // Draw Tesla Buff Tooltip
    if (this.hoveredTower && this.hoveredTower.activeTeslaLinks > 0) {
      this.drawTeslaTooltip(this.hoveredTower);
    }

    if (this.mutationWarningActive && this.ctx) {
      const alpha = Math.min(1, this.mutationWarningTimer);
      this.ctx.save();
      this.ctx.globalAlpha = alpha;

      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      this.ctx.fillRect(0, 0, this.canvas.width, 80);

      this.ctx.fillStyle = '#ff4444';
      this.ctx.font = 'bold 28px Arial';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(
        '⚠ Mutation Detected',
        this.canvas.width / 2,
        35
      );

      this.ctx.fillStyle = '#ffffff';
      this.ctx.font = '16px Arial';
      this.ctx.fillText(
        'Red enemies may evolve upon death.',
        this.canvas.width / 2,
        60
      );

      this.ctx.restore();
    }

    this.ctx.fillStyle = '#bb44ff';
    this.ctx.font = '16px Arial';
    this.ctx.textAlign = 'left';
    
    const manager = CorruptedShardManager.instance;
    const shardText = `Shards: ${manager.currentRunShards}`;
    this.ctx.fillText(shardText, 20, 60);

    const textWidth = this.ctx.measureText(shardText).width;
    this.ctx.font = '12px Arial';
    this.ctx.fillStyle = '#9933cc';
    this.ctx.fillText(` (+${manager.metaShards} stored)`, 20 + textWidth, 60);
  }
}
