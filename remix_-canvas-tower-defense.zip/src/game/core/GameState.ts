import { RunUpgrade } from '../systems/RunSystem';
import { TowerDraftEntry } from '../systems/TowerDraftSystem';
import { Artifact } from '../systems/ArtifactSystem';

export interface GameState {
  gold: number;
  lives: number;
  wave: number;
  isWaveActive: boolean;
  waveDelayTimer: number;
  isPaused: boolean;
  speedMultiplier: number;
  pendingUpgrades: RunUpgrade[] | null;
  activeTags?: string[];
  pendingArtifacts?: Artifact[] | null;
  artifactShopRerollCount?: number;
  artifactShopRerollCost?: number;
  canRerollArtifact?: boolean;
  playerArtifacts?: string[];
  artifacts?: { id: string, stacks: number }[];
  artifactEffects?: Record<string, number>;
  upgradeTimer: number;
  pendingDraft: TowerDraftEntry[] | null;
  intermissionMode: string;
  selectedDraftType: string | null;
  costMultiplier: number;
  nextSlotPrice: number;
  unlockedSlots: number;
  maxSlots: number;
  rerollCost: number;
  draftRerollCount: number;
  isGameOver: boolean;
  isPlacingTower: boolean;
  starterTowerActive?: boolean;
  starterTowerChoices?: string[];
  pendingStarterTower?: string | null;
  enemyScaling?: {
    hp: number;
    speed: number;
    spawnRate: number;
  };
  selectedTower: {
    type: string;
    level: number;
    maxLevel: number;
    damage: number;
    nextDamage: number;
    attackSpeed: number;
    nextAttackSpeed: number;
    range: number;
    nextRange: number;
    upgradeCost: number;
    canUpgrade: boolean;
    targetMode: string;
    isLegendary: boolean;
    corruptionType: string | null;
  } | null;
}
