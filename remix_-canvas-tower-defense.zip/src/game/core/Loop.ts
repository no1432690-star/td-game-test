let gamePaused = false;

document.addEventListener("visibilitychange", () => {
  gamePaused = document.hidden;
});

export class Loop {
  private lastTime: number = 0;
  private animationFrameId: number | null = null;
  private readonly onUpdate: (dt: number) => void;
  private readonly onDraw: () => void;

  constructor(onUpdate: (dt: number) => void, onDraw: () => void) {
    this.onUpdate = onUpdate;
    this.onDraw = onDraw;
  }

  public start(): void {
    if (this.animationFrameId !== null) return;
    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public stop(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  private loop = (timestamp: number): void => {
    if (gamePaused) {
      this.lastTime = timestamp;
      this.animationFrameId = requestAnimationFrame(this.loop);
      return;
    }

    const rawDt = (timestamp - this.lastTime) / 1000; // Convert to seconds
    this.lastTime = timestamp;

    // Cap dt to prevent huge jumps if tab is inactive (max ~30 FPS step)
    const safeDt = Math.min(rawDt, 0.033);

    this.onUpdate(safeDt);
    this.onDraw();

    this.animationFrameId = requestAnimationFrame(this.loop);
  };
}
