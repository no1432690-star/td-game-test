export function calculateTowerStats(tower: any) {
  let stats = { ...tower.baseStats }

  stats = applyUpgrades(stats, tower)
  stats = applyRunModifiers(stats)
  stats = applySynergies(stats)
  stats = applyCorruption(stats)
  stats = applyBuffs(stats)
  stats = applyLegendary(stats)

  return stats
}

function applyUpgrades(stats:any,tower:any){ return stats }
function applyRunModifiers(stats:any){ return stats }
function applySynergies(stats:any){ return stats }
function applyCorruption(stats:any){ return stats }
function applyBuffs(stats:any){ return stats }
function applyLegendary(stats:any){ return stats }
