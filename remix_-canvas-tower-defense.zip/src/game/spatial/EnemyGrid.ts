export class EnemyGrid {

  cellSize = 120

  grid = new Map<string, any[]>()

  key(x:number,y:number){

    const gx = Math.floor(x / this.cellSize)
    const gy = Math.floor(y / this.cellSize)

    return gx + "," + gy
  }

  add(enemy:any){

    const k = this.key(enemy.x,enemy.y)

    if(!this.grid.has(k)) this.grid.set(k,[])

    this.grid.get(k)!.push(enemy)

    enemy._gridKey = k
  }

  clear() {
    this.grid.clear()
  }

  getEnemiesNear(x: number, y: number, radius: number): any[] {
    const minX = Math.floor((x - radius) / this.cellSize)
    const maxX = Math.floor((x + radius) / this.cellSize)
    const minY = Math.floor((y - radius) / this.cellSize)
    const maxY = Math.floor((y + radius) / this.cellSize)

    const result: any[] = []
    for (let gx = minX; gx <= maxX; gx++) {
      for (let gy = minY; gy <= maxY; gy++) {
        const k = gx + "," + gy
        const cell = this.grid.get(k)
        if (cell) {
          result.push(...cell)
        }
      }
    }
    return result
  }
}

export const enemyGrid = new EnemyGrid()
