import { ARTIFACT_POOL } from "./artifactPool";
import { rollRarity, getPoolByRarity } from "./artifactRandom";
import { filterDuplicates } from "./artifactAntiDuplicate";
import { buildStackMap } from "./artifactStackEngine";
import { rollRarityWithPity } from "./artifactPity";

export function generateArtifactChoices(playerArtifacts: any[], count = 3) {
  const results = [];

  const safeArtifacts = Array.isArray(playerArtifacts)
    ? playerArtifacts
    : [];

  const ownedMap = buildStackMap(safeArtifacts);

  for (let i = 0; i < count; i++) {
    const rarity = rollRarity();

    let pool = getPoolByRarity(ARTIFACT_POOL, rarity);

    pool = filterDuplicates(pool, ownedMap);

    if (!pool || pool.length === 0) continue;

    const pick = pool[Math.floor(Math.random() * pool.length)];

    if (pick) {
      results.push({
        id: pick.id,
        rarity: pick.rarity
      });
    }
  }

  return results;
}

export function generateChoicesWithPity(player: any, count = 3) {
  const results = [];

  if (!player) return results;

  const safeArtifacts = Array.isArray(player.artifacts)
    ? player.artifacts
    : [];

  const ownedMap = buildStackMap(safeArtifacts);

  for (let i = 0; i < count; i++) {
    const rarity = rollRarityWithPity(player);

    let pool = getPoolByRarity(ARTIFACT_POOL, rarity);

    pool = filterDuplicates(pool, ownedMap);

    if (!Array.isArray(pool) || pool.length === 0) continue;

    const pick = pool[Math.floor(Math.random() * pool.length)];

    if (pick) {
      results.push({
        id: pick.id,
        rarity: pick.rarity
      });
    }
  }

  return results;
}
