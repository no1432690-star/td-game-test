/**
 * AudioSystem — 3-tier audio:
 *   Tier 1: Programmatic synth (Web Audio API) — hoạt động ngay, zero file
 *   Tier 2: MP3 file loader — thêm file vào public/sounds/ là tự chạy
 *   Tier 3: CrazyGames SDK mute hook
 *
 * Thêm âm thanh mới: đặt file vào public/sounds/sfx/<name>.mp3
 * rồi gọi AudioSystem.instance.play('sfx/<name>')
 */

export class AudioSystem {
  private static _instance: AudioSystem | null = null;
  static get instance(): AudioSystem {
    if (!this._instance) this._instance = new AudioSystem();
    return this._instance;
  }

  private ctx: AudioContext | null = null;
  private unlocked = false;
  private sfxVolume = 0.6;
  private bgmVolume = 0.4;
  private muted = false;
  private bgmNode: AudioBufferSourceNode | null = null;
  private audioCache: Map<string, AudioBuffer> = new Map();

  constructor() {
    // Unlock on first user interaction (browser autoplay policy)
    const unlock = () => {
      if (!this.unlocked) {
        this.getCtx();
        this.unlocked = true;
      }
    };
    window.addEventListener('click',     unlock, { once: false });
    window.addEventListener('keydown',   unlock, { once: false });
    window.addEventListener('touchstart',unlock, { once: false });

    // CrazyGames SDK mute hook
    try {
      const sdk = (window as any).CrazyGames?.SDK;
      if (sdk?.game) {
        sdk.game.addEventCallback('happytime', () => {});
        sdk.game.addEventCallback('pause', () => this.setMuted(true));
        sdk.game.addEventCallback('resume', () => this.setMuted(false));
      }
    } catch (_) {}

    // Mute when tab hidden
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.setMuted(true);
      else this.setMuted(false);
    });
  }

  private getCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  }

  setMuted(v: boolean) { this.muted = v; }
  setSFXVolume(v: number) { this.sfxVolume = Math.max(0, Math.min(1, v)); }
  setBGMVolume(v: number) { this.bgmVolume = Math.max(0, Math.min(1, v)); }

  // ── Tier 2: MP3 file loader ──────────────────────────────────────────────
  async loadFile(path: string): Promise<AudioBuffer | null> {
    if (this.audioCache.has(path)) return this.audioCache.get(path)!;
    try {
      const res = await fetch(`/sounds/${path}.mp3`);
      if (!res.ok) return null;
      const buf = await res.arrayBuffer();
      const decoded = await this.getCtx().decodeAudioData(buf);
      this.audioCache.set(path, decoded);
      return decoded;
    } catch (_) {
      return null;
    }
  }

  async play(path: string, volume = 1): Promise<void> {
    if (this.muted) return;
    const buf = await this.loadFile(path);
    if (!buf) {
      // Fallback to synth if file not found
      const name = path.split('/').pop() || '';
      this.playSynth(name);
      return;
    }
    const ctx = this.getCtx();
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const gain = ctx.createGain();
    gain.gain.value = this.sfxVolume * volume;
    src.connect(gain);
    gain.connect(ctx.destination);
    src.start(0);
  }

  async playBGM(path: string, loop = true): Promise<void> {
    this.stopBGM();
    if (this.muted) return;
    const buf = await this.loadFile(path);
    if (!buf) return;
    const ctx = this.getCtx();
    this.bgmNode = ctx.createBufferSource();
    this.bgmNode.buffer = buf;
    this.bgmNode.loop = loop;
    const gain = ctx.createGain();
    gain.gain.value = this.bgmVolume;
    this.bgmNode.connect(gain);
    gain.connect(ctx.destination);
    this.bgmNode.start(0);
  }

  stopBGM(): void {
    try { this.bgmNode?.stop(); } catch (_) {}
    this.bgmNode = null;
  }

  // ── Tier 1: Programmatic synth SFX ──────────────────────────────────────
  playSynth(name: string): void {
    if (this.muted) return;
    try {
      const ctx = this.getCtx();
      switch (name) {
        case 'pause_open':    this._synthPauseOpen(ctx);    break;
        case 'pause_close':   this._synthPauseClose(ctx);   break;
        case 'game_over':     this._synthGameOver(ctx);     break;
        case 'wave_start':    this._synthWaveStart(ctx);    break;
        case 'upgrade_pick':  this._synthUpgradePick(ctx);  break;
        case 'tower_place':   this._synthTowerPlace(ctx);   break;
        case 'tower_upgrade': this._synthTowerUpgrade(ctx); break;
        case 'legendary':     this._synthLegendary(ctx);    break;
        case 'artifact_pick': this._synthArtifactPick(ctx); break;
        default: break;
      }
    } catch (_) {}
  }

  // Shorthand methods — gọi từ bất kỳ đâu
  sfx(name: string): void {
    // Try file first, fallback to synth automatically via play()
    this.play(`sfx/${name}`);
  }

  // ── Synth implementations ────────────────────────────────────────────────
  private _osc(ctx: AudioContext, freq: number, type: OscillatorType, startTime: number, duration: number, gainVal: number, gainEnd = 0) {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);
    g.gain.setValueAtTime(gainVal * this.sfxVolume, startTime);
    g.gain.linearRampToValueAtTime(gainEnd, startTime + duration);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(startTime); osc.stop(startTime + duration);
  }

  private _synthPauseOpen(ctx: AudioContext) {
    const t = ctx.currentTime;
    // Descending sweep — "time slowing down"
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(200, t + 0.8);
    g.gain.setValueAtTime(0.3 * this.sfxVolume, t);
    g.gain.linearRampToValueAtTime(0, t + 0.8);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(t); osc.stop(t + 0.8);
  }

  private _synthPauseClose(ctx: AudioContext) {
    const t = ctx.currentTime;
    // Ascending sweep — "time resuming"
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.exponentialRampToValueAtTime(800, t + 0.6);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.3 * this.sfxVolume, t + 0.2);
    g.gain.linearRampToValueAtTime(0, t + 0.6);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(t); osc.stop(t + 0.6);
  }

  private _synthGameOver(ctx: AudioContext) {
    const t = ctx.currentTime;
    // Deep descending tones + noise burst
    [0, 0.15, 0.35].forEach((offset, i) => {
      this._osc(ctx, 300 - i * 60, 'sawtooth', t + offset, 0.5, 0.25);
    });
    // Noise burst (glass break feel)
    const bufSize = ctx.sampleRate * 0.4;
    const noiseBuffer = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufSize; i++) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.value = 2000;
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.15 * this.sfxVolume, t);
    noiseGain.gain.linearRampToValueAtTime(0, t + 0.4);
    noise.buffer = noiseBuffer;
    noise.connect(noiseFilter); noiseFilter.connect(noiseGain); noiseGain.connect(ctx.destination);
    noise.start(t); noise.stop(t + 0.4);
  }

  private _synthWaveStart(ctx: AudioContext) {
    const t = ctx.currentTime;
    this._osc(ctx, 440, 'square', t,      0.08, 0.2);
    this._osc(ctx, 550, 'square', t+0.1,  0.08, 0.2);
    this._osc(ctx, 660, 'square', t+0.2,  0.12, 0.25);
  }

  private _synthUpgradePick(ctx: AudioContext) {
    const t = ctx.currentTime;
    this._osc(ctx, 523, 'sine', t,     0.1, 0.15);
    this._osc(ctx, 659, 'sine', t+0.1, 0.1, 0.15);
    this._osc(ctx, 784, 'sine', t+0.2, 0.15, 0.2);
  }

  private _synthTowerPlace(ctx: AudioContext) {
    const t = ctx.currentTime;
    this._osc(ctx, 300, 'square', t, 0.05, 0.3);
    this._osc(ctx, 450, 'sine',   t + 0.05, 0.12, 0.2);
  }

  private _synthTowerUpgrade(ctx: AudioContext) {
    const t = ctx.currentTime;
    [0, 0.08, 0.16, 0.24].forEach((offset, i) => {
      this._osc(ctx, 400 + i * 80, 'sine', t + offset, 0.12, 0.2);
    });
  }

  private _synthLegendary(ctx: AudioContext) {
    const t = ctx.currentTime;
    [0, 0.1, 0.2, 0.35].forEach((offset, i) => {
      this._osc(ctx, 523 + i * 130, 'sine', t + offset, 0.3, 0.3);
    });
  }

  private _synthArtifactPick(ctx: AudioContext) {
    const t = ctx.currentTime;
    this._osc(ctx, 600, 'sine', t,     0.15, 0.25);
    this._osc(ctx, 800, 'sine', t+0.15, 0.1, 0.2);
  }
}

// Export singleton shorthand
export const audio = AudioSystem.instance;
