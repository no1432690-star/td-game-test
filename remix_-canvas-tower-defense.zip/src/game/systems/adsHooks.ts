import { grantShardReward } from "./metaRewards";

export function showRewardedAd(type: string, onReward: Function) {
  try {
    console.log("[Ads] request:", type);

    // simulate success
    const success = true;

    if (success && typeof onReward === "function") {
      onReward();
    }
  } catch (e) {}
}

export function rewardDoubleShards(player: any, baseAmount: number) {
  showRewardedAd("double_reward", () => {
    grantShardReward(player, baseAmount);
  });
}
