// PrestigeSystem.ts

export interface RunStats {
  highestWave: number;
  totalTimeSeconds: number;
  livesRemaining: number;
  startingLives: number;
  totalGoldEarned: number;
  previousHighest: number;
  prestigeStreak: number;
}

export interface PrestigeReward {
  total: number;
  voidEssenceGain?: number;
  breakdown: {
    base: number;
    wave: number;
    performance: number;
    milestone: number;
    streak: number;
  };
}

export class PrestigeSystem {
  constructor(private saveManager: any) {}

  // =========================
  // VOID ESSENCE CALC
  // =========================
  calculateVoidEssenceGain(stats: RunStats, baseReward: number): number {
    let multiplier = 1.0;
    const wave = Math.max(1, stats.highestWave);

    // SPEED
    const minutes = Math.max(0.1, stats.totalTimeSeconds / 60);
    const wpm = wave / minutes;
    if (wpm >= 2.5) multiplier += 0.3;
    else if (wpm >= 2.0) multiplier += 0.2;
    else if (wpm >= 1.5) multiplier += 0.1;

    // SURVIVAL
    const lifePct = Math.max(0, stats.livesRemaining) / Math.max(1, stats.startingLives);
    if (lifePct >= 0.7) multiplier += 0.2;
    else if (lifePct >= 0.4) multiplier += 0.1;

    // ECONOMY
    const goldPerWave = Math.max(0, stats.totalGoldEarned) / wave;
    if (goldPerWave >= 600) multiplier += 0.2;
    else if (goldPerWave >= 400) multiplier += 0.1;

    // CAP MULTIPLIER
    multiplier = Math.min(multiplier, 1.7);

    return Math.max(0, Math.floor((baseReward || 0) * multiplier));
  }

  // =========================
  // MAIN CALC
  // =========================
  calculateReward(stats: RunStats): PrestigeReward {
    const wave = stats.highestWave;

    // BASE
    const base = Math.floor(Math.sqrt(wave) * 1.5);

    // TIER MULTIPLIER
    let mult = 1;
    if (wave >= 300) mult = 2.0;
    else if (wave >= 150) mult = 1.7;
    else if (wave >= 75) mult = 1.4;
    else if (wave >= 30) mult = 1.2;

    const waveBonus = Math.floor(base * mult);

    // =========================
    // PERFORMANCE (3 ONLY)
    // =========================
    let performance = 0;

    // SPEED
    const minutes = stats.totalTimeSeconds / 60;
    const wpm = wave / Math.max(minutes, 1);

    if (wpm >= 2.5) performance += Math.floor(wave * 0.12);
    else if (wpm >= 2.0) performance += Math.floor(wave * 0.08);

    // SURVIVAL
    const lifePct = stats.livesRemaining / stats.startingLives;

    if (lifePct >= 0.7) performance += Math.floor(wave * 0.1);
    else if (lifePct >= 0.4) performance += Math.floor(wave * 0.05);

    // ECONOMY
    const goldPerWave = stats.totalGoldEarned / Math.max(wave, 1);

    if (goldPerWave >= 600) performance += Math.floor(wave * 0.06);
    else if (goldPerWave >= 400) performance += Math.floor(wave * 0.03);

    // =========================
    // MILESTONE
    // =========================
    const milestones = [25, 50, 75, 100, 150, 200, 300];
    const newMilestones = milestones.filter(
      m => wave >= m && stats.previousHighest < m
    );

    const milestone = newMilestones.length * 20;

    // =========================
    // STREAK
    // =========================
    let streak = 0;
    if (stats.prestigeStreak >= 3) {
      streak = Math.floor(base * 0.2 * stats.prestigeStreak);
    }

    const total = waveBonus + performance + milestone + streak;

    return {
      total,
      breakdown: {
        base,
        wave: waveBonus,
        performance,
        milestone,
        streak,
      },
    };
  }

  // =========================
  // APPLY PRESTIGE
  // =========================
  performPrestige(stats: RunStats) {
    const save = this.saveManager.getSave();
    const reward = this.calculateReward(stats);

    const voidEssenceGain = this.calculateVoidEssenceGain(stats, reward.total);
    reward.voidEssenceGain = voidEssenceGain;

    // Ensure safe initialization
    if (save.voidEssence === undefined) save.voidEssence = 0;
    if (!save.voidEssenceHistory) {
      save.voidEssenceHistory = { gained: 0, spent: 0, netBalance: 0 };
    }

    save.voidEssence += voidEssenceGain;
    save.voidEssenceHistory.gained += voidEssenceGain;
    save.voidEssenceHistory.netBalance = save.voidEssenceHistory.gained - save.voidEssenceHistory.spent;

    save.prestigeLevel++;

    save.statistics.totalPrestiges =
      (save.statistics.totalPrestiges || 0) + 1;

    save.statistics.prestigeStreak =
      (save.statistics.prestigeStreak || 0) + 1;

    save.statistics.highestWave = Math.max(
      save.statistics.highestWave || 0,
      stats.highestWave
    );

    save.statistics.totalRuns =
      (save.statistics.totalRuns || 0) + 1;

    this.saveManager.saveGame();

    return reward;
  }

  // =========================
  // RESET RUN (SAFE)
  // =========================
  resetRun(game: any) {
    localStorage.removeItem('td_run_save');

    game.gold = 100;
    game.totalGoldEarned = 0;
    game.timeElapsed = 0;
    game.lives = 20;
    game.towers = [];
    game.enemies = [];
    game.projectiles = [];

    if (game.waveManager) {
      game.waveManager.wave = 1;
      game.waveManager.isWaveActive = false;
    }

    game.artifacts = [];
    game.artifactEffects = {};

    game.intermissionMode = 0; // IntermissionMode.None
  }
}
