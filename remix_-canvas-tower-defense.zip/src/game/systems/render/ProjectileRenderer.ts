import { Projectile } from '../../entities/Projectile';

export class ProjectileRenderer {
  static render(ctx: CanvasRenderingContext2D, projectiles: Projectile[]) {
    const isSimplified = projectiles.length > 150;

    // Group projectiles by type to minimize context state changes
    const normalProjectiles: Projectile[] = [];
    const bombProjectiles: Projectile[] = [];
    const frostProjectiles: Projectile[] = [];

    for (const p of projectiles) {
      if (!p.active) continue;
      if (p.type === 'bomb') {
        bombProjectiles.push(p);
      } else if (p.type === 'frost') {
        frostProjectiles.push(p);
      } else {
        normalProjectiles.push(p);
      }
    }

    // Render normal projectiles
    if (normalProjectiles.length > 0) {
      ctx.beginPath();
      const radius = isSimplified ? 2 : 4;
      for (const p of normalProjectiles) {
        ctx.moveTo(p.position.x + radius, p.position.y);
        ctx.arc(p.position.x, p.position.y, radius, 0, Math.PI * 2);
      }
      ctx.fillStyle = isSimplified ? 'rgba(251, 191, 36, 0.5)' : '#fbbf24'; // Amber-400
      ctx.fill();
    }

    // Render bomb projectiles
    if (bombProjectiles.length > 0) {
      ctx.beginPath();
      const radius = isSimplified ? 3 : 6;
      for (const p of bombProjectiles) {
        ctx.moveTo(p.position.x + radius, p.position.y);
        ctx.arc(p.position.x, p.position.y, radius, 0, Math.PI * 2);
      }
      ctx.fillStyle = isSimplified ? 'rgba(17, 24, 39, 0.5)' : '#111827'; // Gray-900
      ctx.fill();
      
      if (!isSimplified) {
        ctx.strokeStyle = '#ef4444'; // Red-500
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }

    // Render frost projectiles
    if (frostProjectiles.length > 0) {
      ctx.beginPath();
      const radius = isSimplified ? 2 : 4;
      for (const p of frostProjectiles) {
        ctx.moveTo(p.position.x + radius, p.position.y);
        ctx.arc(p.position.x, p.position.y, radius, 0, Math.PI * 2);
      }
      ctx.fillStyle = isSimplified ? 'rgba(96, 165, 250, 0.5)' : '#60a5fa'; // Blue-400
      ctx.fill();
    }
  }
}
