export function initAnalytics(player: any) {
  if (!player) return;

  if (!player.analytics) {
    player.analytics = {
      runs: 0,
      totalDeaths: 0,
      kills: 0,
      rerolls: 0,
      artifactPicks: {}
    };
  }
}
