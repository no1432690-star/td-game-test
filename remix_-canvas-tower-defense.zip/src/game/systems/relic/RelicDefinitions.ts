export enum RelicTier {
  COMMON = 0,
  UNCOMMON = 1,
  RARE = 2,
  EPIC = 3,
  LEGENDARY = 4
}

export interface RelicEffect {
  atkPercent?: number;
  atkSpeedPercent?: number;
  rangePercent?: number;
  goldBonus?: number;
  slowDuration?: number;
  critChance?: number;
  allStatPercent?: number;
  artifactPowerPercent?: number;
}

export interface RelicDefinition {
  id: string;
  name: string;
  tier: RelicTier;
  description: string;
  effect: RelicEffect;
  maxLevel: number;
  baseCost: number;
  unlockedAtWave: number;
}

export const RELIC_DEFINITIONS: RelicDefinition[] = [
  // TIER 0 - COMMON
  { id: 'bronzeGear', name: 'Bronze Gear', tier: RelicTier.COMMON, description: 'damage +1%/lvl', effect: { atkPercent: 0.01 }, maxLevel: 100, baseCost: 10, unlockedAtWave: 1 },
  { id: 'chronoCore', name: 'Chrono Core', tier: RelicTier.COMMON, description: 'attackSpeed +1%/lvl', effect: { atkSpeedPercent: 0.01 }, maxLevel: 100, baseCost: 10, unlockedAtWave: 1 },
  { id: 'arcaneLens', name: 'Arcane Lens', tier: RelicTier.COMMON, description: 'range +1%/lvl', effect: { rangePercent: 0.01 }, maxLevel: 100, baseCost: 10, unlockedAtWave: 1 },
  
  // TIER 1 - UNCOMMON
  { id: 'goldMagnet', name: 'Gold Magnet', tier: RelicTier.UNCOMMON, description: 'gold +1.5%/lvl', effect: { goldBonus: 0.015 }, maxLevel: 80, baseCost: 25, unlockedAtWave: 30 },
  { id: 'frostCrystal', name: 'Frost Crystal', tier: RelicTier.UNCOMMON, description: 'slowDuration +1.5%/lvl', effect: { slowDuration: 0.015 }, maxLevel: 80, baseCost: 25, unlockedAtWave: 30 },

  // TIER 2 - RARE
  { id: 'criticalStrike', name: 'Critical Strike', tier: RelicTier.RARE, description: 'critChance +2%/lvl', effect: { critChance: 0.02 }, maxLevel: 60, baseCost: 50, unlockedAtWave: 50 },
  { id: 'temporalAce', name: 'Temporal Ace', tier: RelicTier.RARE, description: 'attackSpeed +2%/lvl', effect: { atkSpeedPercent: 0.02 }, maxLevel: 60, baseCost: 50, unlockedAtWave: 50 },

  // TIER 3 - EPIC
  { id: 'arcaneMastery', name: 'Arcane Mastery', tier: RelicTier.EPIC, description: 'damage +3%/lvl', effect: { atkPercent: 0.03 }, maxLevel: 50, baseCost: 100, unlockedAtWave: 75 },
  { id: 'voidShell', name: 'Void Shell', tier: RelicTier.EPIC, description: 'allStats +2%/lvl', effect: { allStatPercent: 0.02 }, maxLevel: 50, baseCost: 150, unlockedAtWave: 75 },

  // TIER 4 - LEGENDARY
  { id: 'voidShard', name: 'Void Shard', tier: RelicTier.LEGENDARY, description: 'allStats +3%/lvl, artifactPower +3%/lvl', effect: { allStatPercent: 0.03, artifactPowerPercent: 0.03 }, maxLevel: 30, baseCost: 200, unlockedAtWave: 100 },
  { id: 'eternityStone', name: 'Eternity Stone', tier: RelicTier.LEGENDARY, description: 'damage +4%/lvl, gold +4%/lvl', effect: { atkPercent: 0.04, goldBonus: 0.04 }, maxLevel: 30, baseCost: 250, unlockedAtWave: 100 }
];

export function getTierMultiplier(tier: RelicTier): number {
  const multipliers = [1.0, 1.5, 2.0, 3.0, 5.0];
  return multipliers[tier] || 1.0;
}

export function getMaxLevelForTier(tier: RelicTier): number {
  const maxLevels = [100, 80, 60, 50, 30];
  return maxLevels[tier] || 100;
}

export function getAllRelics(): RelicDefinition[] {
  return RELIC_DEFINITIONS;
}

export function getRelicDefinition(id: string): RelicDefinition | undefined {
  return RELIC_DEFINITIONS.find(r => r.id === id);
}
