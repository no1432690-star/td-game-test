import { RelicDefinition, getTierMultiplier, getAllRelics, getRelicDefinition } from './RelicDefinitions';

export class RelicShopSystem {
  
  getRelicLevelCost(relic: RelicDefinition, nextLevel: number): number {
    if (nextLevel < 1 || nextLevel > relic.maxLevel) return 0;
    const tierMult = getTierMultiplier(relic.tier);
    const cost = Math.floor(relic.baseCost * tierMult * Math.pow(1.15, nextLevel - 1));
    return Math.min(cost, 1000000);
  }

  getTotalCostToLevel(relic: RelicDefinition, targetLevel: number): number {
    let total = 0;
    for (let i = 1; i <= targetLevel; i++) {
      total += this.getRelicLevelCost(relic, i);
    }
    return total;
  }

  purchaseRelic(relicId: string, save?: any): { success: boolean; reason?: string; newLevel?: number; costPaid?: number } {
    const relic = getRelicDefinition(relicId);
    if (!relic) return { success: false, reason: "Relic not found" };

    // Use provided save or get from manager
    const activeSave = save || (window as any).metaSaveManager?.getSave();
    if (!activeSave) return { success: false, reason: "No save data found" };

    if (!activeSave.relicShop) {
      activeSave.relicShop = { ownedRelics: {} };
    }
    if (!activeSave.relicShop.ownedRelics) {
      activeSave.relicShop.ownedRelics = {};
    }

    const highestWave = activeSave.statistics?.highestWave || 0;
    if (highestWave < relic.unlockedAtWave) {
      return { success: false, reason: "Unlock wave not reached" };
    }

    const currentLevel = activeSave.relicShop.ownedRelics[relicId] || 0;
    const nextLevel = currentLevel + 1;

    if (nextLevel > relic.maxLevel) {
      return { success: false, reason: "Max level reached" };
    }

    const cost = this.getRelicLevelCost(relic, nextLevel);
    if ((activeSave.voidEssence || 0) < cost) {
      return { success: false, reason: "Insufficient funds" };
    }

    activeSave.voidEssence -= cost;
    activeSave.relicShop.ownedRelics[relicId] = nextLevel;

    if (!activeSave.voidEssenceHistory) {
      activeSave.voidEssenceHistory = { gained: 0, spent: 0, netBalance: 0 };
    }
    activeSave.voidEssenceHistory.spent += cost;
    activeSave.voidEssenceHistory.netBalance = activeSave.voidEssenceHistory.gained - activeSave.voidEssenceHistory.spent;

    // Save changes if we used the global manager
    if (!save && (window as any).metaSaveManager) {
      (window as any).metaSaveManager.saveGame();
    }

    return { success: true, newLevel: nextLevel, costPaid: cost };
  }

  resetRelic(relicId: string, save?: any): { success: boolean; refunded: number; reason?: string } {
    const relic = getRelicDefinition(relicId);
    if (!relic) return { success: false, refunded: 0, reason: "Relic not found" };

    const activeSave = save || (window as any).metaSaveManager?.getSave();
    if (!activeSave) return { success: false, refunded: 0, reason: "No save data found" };

    if (!activeSave.relicShop || !activeSave.relicShop.ownedRelics || !activeSave.relicShop.ownedRelics[relicId]) {
      return { success: false, refunded: 0, reason: "Relic not owned" };
    }

    const currentLevel = activeSave.relicShop.ownedRelics[relicId];
    if (currentLevel <= 0) {
      return { success: false, refunded: 0, reason: "Relic level is 0" };
    }

    const refund = this.getTotalCostToLevel(relic, currentLevel);
    
    activeSave.relicShop.ownedRelics[relicId] = 0;
    activeSave.voidEssence = (activeSave.voidEssence || 0) + refund;

    if (activeSave.voidEssenceHistory) {
      activeSave.voidEssenceHistory.spent -= refund;
      activeSave.voidEssenceHistory.netBalance = activeSave.voidEssenceHistory.gained - activeSave.voidEssenceHistory.spent;
    }

    if (!save && (window as any).metaSaveManager) {
      (window as any).metaSaveManager.saveGame();
    }

    return { success: true, refunded: refund };
  }

  getNextUpgradeCost(relicId: string, save?: any): number {
    const relic = getRelicDefinition(relicId);
    if (!relic) return 0;

    const activeSave = save || (window as any).metaSaveManager?.getSave();
    const currentLevel = activeSave?.relicShop?.ownedRelics?.[relicId] || 0;
    if (currentLevel >= relic.maxLevel) return 0;

    return this.getRelicLevelCost(relic, currentLevel + 1);
  }

  calculateAllBonuses(save: any): {
    atkPercent: number;
    atkSpeedPercent: number;
    rangePercent: number;
    goldBonus: number;
    slowDuration: number;
    critChance: number;
    allStatPercent: number;
    artifactPowerPercent: number;
  } {
    const bonuses = {
      atkPercent: 0,
      atkSpeedPercent: 0,
      rangePercent: 0,
      goldBonus: 0,
      slowDuration: 0,
      critChance: 0,
      allStatPercent: 0,
      artifactPowerPercent: 0
    };

    if (!save.relicShop || !save.relicShop.ownedRelics) return bonuses;

    for (const [relicId, level] of Object.entries(save.relicShop.ownedRelics)) {
      const lvl = level as number;
      if (lvl <= 0) continue;

      const relic = getRelicDefinition(relicId);
      if (!relic) continue;

      for (const [effectKey, effectValue] of Object.entries(relic.effect)) {
        if (effectValue !== undefined) {
          const key = effectKey as keyof typeof bonuses;
          bonuses[key] += effectValue * lvl;
        }
      }
    }

    // Cap each bonus at 5.0
    for (const key of Object.keys(bonuses)) {
      const k = key as keyof typeof bonuses;
      bonuses[k] = Math.min(bonuses[k], 5.0);
    }

    return bonuses;
  }

  validateVoidEssenceBalance(save: any): boolean {
    if (!save.voidEssenceHistory) return true;
    
    let calculatedSpent = 0;
    if (save.relicShop && save.relicShop.ownedRelics) {
      for (const [relicId, level] of Object.entries(save.relicShop.ownedRelics)) {
        const relic = getRelicDefinition(relicId);
        if (relic) {
          calculatedSpent += this.getTotalCostToLevel(relic, level as number);
        }
      }
    }

    const difference = Math.abs(calculatedSpent - save.voidEssenceHistory.spent);
    return difference <= 100;
  }
}
