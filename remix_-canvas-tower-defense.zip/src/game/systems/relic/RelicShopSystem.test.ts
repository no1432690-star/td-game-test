import { describe, test, expect, beforeEach } from 'vitest';
import { RelicShopSystem } from './RelicShopSystem';
import { getRelicDefinition, RelicTier } from './RelicDefinitions';

describe('RelicShopSystem Tests', () => {
  let shop: RelicShopSystem;
  let save: any;

  beforeEach(() => {
    shop = new RelicShopSystem();
    save = {
      voidEssence: 0,
      voidEssenceHistory: { gained: 0, spent: 0, netBalance: 0 },
      statistics: { highestWave: 100 },
      relicShop: { ownedRelics: {} }
    };
  });

  test('Test 1 - Cost calculation', () => {
    const bronzeGear = getRelicDefinition('bronzeGear')!;
    expect(shop.getRelicLevelCost(bronzeGear, 1)).toBe(10);
    expect(shop.getRelicLevelCost(bronzeGear, 5)).toBe(17);
    expect(shop.getRelicLevelCost(bronzeGear, 10)).toBe(35); // Approx 40
  });

  test('Test 2 - Cost scaling by tier', () => {
    const bronzeGear = getRelicDefinition('bronzeGear')!; // Common
    const voidShard = getRelicDefinition('voidShard')!; // Legendary

    expect(shop.getRelicLevelCost(bronzeGear, 1)).toBe(10);
    expect(shop.getRelicLevelCost(voidShard, 1)).toBe(1000);
  });

  test('Test 3 - Max level enforcement', () => {
    save.voidEssence = 1000000;
    save.relicShop.ownedRelics['bronzeGear'] = 100; // Max is 100

    const result = shop.purchaseRelic('bronzeGear', save);
    expect(result.success).toBe(false);
    expect(result.reason).toBe('Max level reached');
  });

  test('Test 4 - Insufficient resources', () => {
    save.voidEssence = 5;
    const result = shop.purchaseRelic('voidShard', save);
    expect(result.success).toBe(false);
    expect(result.reason).toBe('Insufficient funds');
  });

  test('Test 5 - Successful purchase', () => {
    save.voidEssence = 50;
    const result = shop.purchaseRelic('bronzeGear', save);
    
    expect(result.success).toBe(true);
    expect(result.newLevel).toBe(1);
    expect(result.costPaid).toBe(10);
    expect(save.voidEssence).toBe(40);
    expect(save.relicShop.ownedRelics['bronzeGear']).toBe(1);
    expect(save.voidEssenceHistory.spent).toBe(10);
  });

  test('Test 6 - Reset with refund', () => {
    save.voidEssence = 100;
    
    // Buy to level 10
    for (let i = 0; i < 10; i++) {
      shop.purchaseRelic('bronzeGear', save);
    }

    const spent = save.voidEssenceHistory.spent;
    expect(spent).toBeGreaterThan(0);

    const currentEssence = save.voidEssence;

    const resetResult = shop.resetRelic('bronzeGear', save);
    expect(resetResult.success).toBe(true);
    expect(resetResult.refunded).toBe(spent);
    expect(save.relicShop.ownedRelics['bronzeGear']).toBe(0);
    expect(save.voidEssence).toBe(currentEssence + spent);
    expect(save.voidEssenceHistory.spent).toBe(0);
  });

  test('Test 7 - Bonus calculation', () => {
    save.relicShop.ownedRelics['bronzeGear'] = 50; // +50% damage
    save.relicShop.ownedRelics['goldMagnet'] = 30; // +45% gold

    const bonuses = shop.calculateAllBonuses(save);
    expect(bonuses.atkPercent).toBeCloseTo(0.50);
    expect(bonuses.goldBonus).toBeCloseTo(0.45);
    expect(bonuses.atkSpeedPercent).toBe(0);
  });

  test('Test 8 - Overflow prevention', () => {
    const bronzeGear = getRelicDefinition('bronzeGear')!;
    const cost = shop.getRelicLevelCost(bronzeGear, 100); // 1.15^99 * 10 > 1,000,000
    expect(cost).toBe(1000000);
  });
});
