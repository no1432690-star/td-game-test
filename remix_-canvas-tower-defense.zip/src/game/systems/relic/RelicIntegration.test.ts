/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { Game } from '../../core/Game';
import { RelicShopSystem } from './RelicShopSystem';
import { metaSaveManager, gameStateManager } from '../../../core/MenuSystem';
import { GameState as MenuGameState } from '../../../core/GameState';
import { Tower } from '../../entities/Tower';
import { Enemy } from '../../entities/Enemy';
import { Frost } from '../../entities/Frost';
import { applyDamage } from '../BuffSystem';
import { computeAllArtifacts } from '../artifactEngine';
import { ARTIFACT_DEFS } from '../artifactDefinitions';

// Mock window.gameInstance
beforeEach(() => {
  localStorage.clear();
  // Reset the save object in the singleton
  const save = metaSaveManager.getSave();
  Object.assign(save, {
    corruptedShards: 0,
    prestigeLevel: 0,
    voidEssence: 0,
    voidEssenceHistory: { gained: 0, spent: 0, netBalance: 0 },
    relicShop: { ownedRelics: {} },
    statistics: {
      highestWave: 100,
      totalRuns: 0,
      totalEnemiesKilled: 0,
      totalPrestiges: 0,
      prestigeStreak: 0
    },
    upgrades: {
      damage: 0,
      gold: 0,
      life: 0,
      crit: 0
    },
    ink: 0
  });
  
  const mockCanvas = document.createElement('canvas');
  mockCanvas.width = 800;
  mockCanvas.height = 600;
  mockCanvas.getContext = () => ({
    save: vi.fn(),
    restore: vi.fn(),
    translate: vi.fn(),
    scale: vi.fn(),
    clearRect: vi.fn(),
    fillRect: vi.fn(),
    strokeRect: vi.fn(),
    beginPath: vi.fn(),
    moveTo: vi.fn(),
    lineTo: vi.fn(),
    stroke: vi.fn(),
    fill: vi.fn(),
    arc: vi.fn(),
    fillText: vi.fn(),
    measureText: () => ({ width: 10 }),
    drawImage: vi.fn(),
    createLinearGradient: () => ({ addColorStop: vi.fn() }),
    createRadialGradient: () => ({ addColorStop: vi.fn() }),
    setTransform: vi.fn(),
  } as any);

  gameStateManager.setState(MenuGameState.PLAYING);
  (window as any).gameInstance = new Game(mockCanvas);
});

describe('Relic Integration', () => {
  it('1. Individual relic bonuses applied', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 1000;
    
    // Buy atkPercent relic
    game.relicShopSystem.purchaseRelic('bronzeGear', save);
    
    // Force recalculate
    game.isPaused = false;
    (game as any).update(1/60);
    const bonuses = game.getRelicBonuses();
    expect(bonuses.atkPercent).toBeGreaterThan(0);
  });

  it('2. Multiplicative stacking of multiple relics', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 10000;
    
    // Buy multiple relics
    game.relicShopSystem.purchaseRelic('bronzeGear', save);
    game.relicShopSystem.purchaseRelic('voidShard', save);
    
    game.isPaused = false;
    (game as any).update(1/60);
    const bonuses = game.getRelicBonuses();
    
    // bronzeGear gives atkPercent, voidShard gives allStatPercent
    expect(bonuses.atkPercent).toBeGreaterThan(0);
    expect(bonuses.allStatPercent).toBeGreaterThan(0);
  });

  it('3. Gold bonus application', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 10000;
    
    // Buy gold bonus relic
    game.relicShopSystem.purchaseRelic('goldMagnet', save);
    game.isPaused = false;
    (game as any).update(1/60);
    
    const initialGold = game.gold;
    const enemy = new Enemy([{x: 100, y: 100}] as any);
    enemy.health = 0;
    enemy.active = false;
    enemy.goldReward = 100;
    
    // Simulate enemy death in game
    game.enemies.push(enemy);
    game.isPaused = false;
    (game as any).update(1/60); // This will process the dead enemy
    
    const bonuses = game.getRelicBonuses();
    const expectedReward = Math.floor(100 * (1 + (bonuses.goldBonus || 0)));
    
    expect(game.gold - initialGold).toBe(expectedReward);
  });

  it('4. Slow duration increase', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 10000;
    
    game.relicShopSystem.purchaseRelic('frostCrystal', save);
    game.isPaused = false;
    (game as any).update(1/60);
    
    const frost = new Frost(0, 0);
    const enemy = new Enemy([{x: 100, y: 100}] as any);
    
    // Mock the attack method to see the slow effect applied
    const applyEffectSpy = vi.spyOn(enemy, 'applyEffect');
    
    // Force attack
    (frost as any).attack(enemy);
    
    expect(applyEffectSpy).toHaveBeenCalled();
    const effectArg = applyEffectSpy.mock.calls[0][0];
    expect(effectArg.type).toBe('slow');
    
    const bonuses = game.getRelicBonuses();
    const expectedDuration = 2.0 * (1 + (bonuses.slowDuration || 0));
    expect(effectArg.duration).toBeCloseTo(expectedDuration);
  });

  it('5. Performance optimization (bonuses recalculated infrequently)', () => {
    const game = (window as any).gameInstance as Game;
    
    const calculateSpy = vi.spyOn(game.relicShopSystem, 'calculateAllBonuses');
    
    // Update 59 times, shouldn't recalculate
    for (let i = 0; i < 59; i++) {
      game.isPaused = false;
      (game as any).update(1/60);
    }
    expect(calculateSpy).toHaveBeenCalledTimes(1); // Once on first frame (frameCount = 0)
    
    // Update 1 more time (frameCount = 59 -> 60)
    game.isPaused = false;
    (game as any).update(1/60);
    
    // Update 1 more time (frameCount = 60), should recalculate
    game.isPaused = false;
    (game as any).update(1/60);
    expect(calculateSpy).toHaveBeenCalledTimes(2);
  });

  it('6. Persistence across save/load', () => {
    const save = metaSaveManager.getSave();
    save.voidEssence = 1000;
    const relicSystem = new RelicShopSystem();
    relicSystem.purchaseRelic('bronzeGear', save);
    
    metaSaveManager.saveGame();
    
    // Reset and load
    const newSaveManager = new (metaSaveManager.constructor as any)();
    
    const loadedSave = newSaveManager.getSave();
    expect(loadedSave.relicShop.ownedRelics['bronzeGear']).toBe(1);
  });

  it('7. Application in new runs post-prestige', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 1000;
    
    game.relicShopSystem.purchaseRelic('bronzeGear', save);
    game.update(1/60);
    
    const bonusesBefore = game.getRelicBonuses();
    
    // Simulate prestige (which resets run state but keeps meta save)
    game.prestigeSystem.performPrestige(game);
    
    // Create new game instance (like starting a new run)
    const mockCanvas = document.createElement('canvas');
    mockCanvas.width = 800;
    mockCanvas.height = 600;
    mockCanvas.getContext = () => ({
      save: vi.fn(),
      restore: vi.fn(),
      translate: vi.fn(),
      scale: vi.fn(),
      clearRect: vi.fn(),
      fillRect: vi.fn(),
      strokeRect: vi.fn(),
      beginPath: vi.fn(),
      moveTo: vi.fn(),
      lineTo: vi.fn(),
      stroke: vi.fn(),
      fill: vi.fn(),
      arc: vi.fn(),
      fillText: vi.fn(),
      measureText: () => ({ width: 10 }),
      drawImage: vi.fn(),
      createLinearGradient: () => ({ addColorStop: vi.fn() }),
      createRadialGradient: () => ({ addColorStop: vi.fn() }),
      setTransform: vi.fn(),
    } as any);
    const newGame = new Game(mockCanvas);
    (window as any).gameInstance = newGame;
    newGame.update(1/60);
    
    const bonusesAfter = newGame.getRelicBonuses();
    expect(bonusesAfter.atkPercent).toBe(bonusesBefore.atkPercent);
  });

  it('8. Combination of relic and artifact bonuses', () => {
    const game = (window as any).gameInstance as Game;
    const save = metaSaveManager.getSave();
    save.voidEssence = 10000;
    
    game.relicShopSystem.purchaseRelic('voidShard', save); // gives artifactPowerPercent
    game.update(1/60);
    
    const state = {
      artifacts: [{ id: 'endless_pressure', stacks: 1 }],
      wave: 1,
      gold: 0
    };
    
    // Compute without relic bonus (mocking no relic bonus)
    (window as any).gameInstance.getRelicBonuses = () => ({});
    const resultWithoutRelic = computeAllArtifacts(state, ARTIFACT_DEFS, { wave: 1, gold: 0 });
    
    // Compute with relic bonus
    (window as any).gameInstance.getRelicBonuses = () => game.relicBonuses;
    const resultWithRelic = computeAllArtifacts(state, ARTIFACT_DEFS, { wave: 1, gold: 0 });
    
    const powerMultiplier = 1 + (game.relicBonuses.artifactPowerPercent || 0);
    expect(resultWithRelic['endless_pressure']).toBeCloseTo(resultWithoutRelic['endless_pressure'] * powerMultiplier);
  });
});
