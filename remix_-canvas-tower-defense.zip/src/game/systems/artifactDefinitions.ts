import { ArtifactDefinition } from "./artifactEngine";

export const ARTIFACT_DEFS: Record<string, ArtifactDefinition> = {
  // 💰 ECONOMY
  golden_momentum: {
    id: "golden_momentum",
    name: "Golden Momentum",
    description: "+5% Gold per wave (up to +50%)",
    basePrice: 5000000,
    rarity: "Rare",
    stackType: "linear",
    baseValue: 0.05,
    softCap: 10
  },

  blood_investment: {
    id: "blood_investment",
    name: "Blood Investment",
    description: "Huge gold bonus, but lowers damage initially",
    basePrice: 8000000,
    rarity: "Gold",
    stackType: "special",
    compute: ({ stacks }) => ({
      goldBonus: 0.3 * Math.log(1 + stacks),
      damagePenalty: 0.15 / (1 + stacks * 0.6)
    })
  },

  merchants_insight: {
    id: "merchants_insight",
    name: "Merchant's Insight",
    description: "Increases upgrade choices by 1",
    basePrice: 12000000,
    rarity: "Legendary",
    stackType: "special",
    hardCap: 3,
    compute: ({ stacks }: { stacks: number }) => stacks
  },

  overflow_vault: {
    id: "overflow_vault",
    name: "Overflow Vault",
    description: "Gain damage based on your unspent gold",
    basePrice: 15000000,
    rarity: "Quality",
    stackType: "special",
    compute: ({ gold, stacks }) =>
      Math.log(1 + gold / 1e6) * stacks * 0.02
  },

  // 📈 SCALING
  endless_pressure: {
    id: "endless_pressure",
    name: "Endless Pressure",
    description: "Gain damage based on the current wave",
    basePrice: 8000000,
    rarity: "Gold",
    stackType: "special",
    compute: ({ wave, stacks }) =>
      wave * stacks * 0.01
  },

  compound_growth: {
    id: "compound_growth",
    name: "Compound Growth",
    description: "Gain damage based on total artifacts owned",
    basePrice: 12000000,
    rarity: "Legendary",
    stackType: "special",
    compute: ({ totalArtifacts, stacks }) =>
      totalArtifacts * stacks * 0.02
  },

  // ⚡ COMBAT
  chain_reaction: {
    id: "chain_reaction",
    name: "Chain Reaction",
    description: "Attacks have a chance to chain to another enemy",
    basePrice: 5000000,
    rarity: "Rare",
    stackType: "diminishing",
    baseValue: 0.2,
    k: 0.4,
    softCap: 6
  },

  static_field: {
    id: "static_field",
    name: "Static Field",
    description: "Attacks have a chance to shock enemies",
    basePrice: 5000000,
    rarity: "Rare",
    stackType: "diminishing",
    baseValue: 0.05,
    k: 0.5,
    softCap: 6
  },

  overkill_conversion: {
    id: "overkill_conversion",
    name: "Overkill Conversion",
    description: "Excess damage splashes to nearby enemies",
    basePrice: 8000000,
    rarity: "Gold",
    stackType: "diminishing",
    baseValue: 0.3,
    k: 0.4,
    softCap: 5
  },

  critical_cascade: {
    id: "critical_cascade",
    name: "Critical Cascade",
    description: "Critical hits have a chance to chain to nearby enemies",
    basePrice: 12000000,
    rarity: "Legendary",
    stackType: "diminishing",
    baseValue: 0.25,
    k: 0.4,
    softCap: 5
  },

  // 🎲 RNG
  tactical_reserve: {
    id: "tactical_reserve",
    name: "Tactical Reserve",
    description: "Gain free rerolls in the shop",
    basePrice: 15000000,
    rarity: "Quality",
    stackType: "special",
    hardCap: 2,
    compute: ({ stacks }) => stacks
  },

  second_chance: {
    id: "second_chance",
    name: "Second Chance",
    description: "Chance to survive a fatal hit",
    basePrice: 12000000,
    rarity: "Legendary",
    stackType: "special",
    compute: ({ stacks }) =>
      Math.min(0.2 * stacks, 0.6)
  },

  // ⚪ QUALITY
  temporal_surge: {
    id: "temporal_surge",
    name: "Temporal Surge",
    description: "Gain a massive speed boost at the start of each wave",
    basePrice: 15000000,
    rarity: "Quality",
    stackType: "special",
    compute: ({ stacks }) => ({
      duration: 2 + stacks * 0.5,
      bonusAS: 1.0
    })
  },

  time_fracture: {
    id: "time_fracture",
    name: "Time Fracture",
    description: "Every Nth attack deals massive bonus damage",
    basePrice: 15000000,
    rarity: "Quality",
    stackType: "special",
    compute: ({ stacks }) =>
      Math.max(50 - stacks * 5, 20)
  },

  time_echo: {
    id: "time_echo",
    name: "Time Echo",
    description: "Attacks have a chance to hit twice",
    basePrice: 15000000,
    rarity: "Quality",
    stackType: "special",
    compute: ({ stacks }) =>
      Math.min(0.15 + stacks * 0.05, 0.5)
  }
};
