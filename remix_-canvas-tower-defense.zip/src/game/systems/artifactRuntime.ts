import { ArtifactEventBus } from "./artifactEventBus";
import { getScaledValue } from "./artifactScaling";

export function bindArtifact(artifact: any, context: any) {
  if (!artifact || !Array.isArray(artifact.effects)) return;

  for (const effect of artifact.effects) {
    if (!effect || !effect.type) continue;

    const stacks = artifact.stacks || 1;
    const scaledValue = getScaledValue(effect, stacks, artifact.rarity);

    switch (effect.type) {

      case "onKill_heal":
        ArtifactEventBus.on("onKill", ({ killer }: any) => {
          if (killer !== context.player) return;
          context.player.hp += scaledValue || 0;
        });
        break;

      case "onAttack_bonusDamage":
        ArtifactEventBus.on("onAttack", ({ attacker, target }: any) => {
          if (attacker !== context.player) return;
          if (!target) return;
          target.hp -= scaledValue || 0;
        });
        break;

      case "onTick_regen":
        ArtifactEventBus.on("onTick", ({ deltaTime }: any) => {
          context.player.hp += (scaledValue || 0) * deltaTime;
        });
        break;

      default:
        console.warn("Unknown artifact effect:", effect.type);
        break;
    }
  }
}
