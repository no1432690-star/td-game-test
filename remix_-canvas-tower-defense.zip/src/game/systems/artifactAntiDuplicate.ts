export function filterDuplicates(pool: any[], ownedMap: Record<string, any>) {
  if (!Array.isArray(pool)) return [];

  const result = [];

  for (let i = 0; i < pool.length; i++) {
    const item = pool[i];
    if (!item || !item.id) continue;

    if (!ownedMap || !ownedMap[item.id]) {
      result.push(item);
      continue;
    }

    // reduce duplicate chance (70% filtered out)
    if (Math.random() > 0.7) {
      result.push(item);
    }
  }

  return result;
}
