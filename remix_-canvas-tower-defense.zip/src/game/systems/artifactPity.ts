import { rollRarity } from "./artifactRandom";

export function initPityState(player: any) {
  if (!player) return;

  if (!player.pity) {
    player.pity = {
      epicCounter: 0,
      legendaryCounter: 0
    };
  }
}

export function rollRarityWithPity(player: any) {
  if (!player || !player.pity) {
    return rollRarity();
  }

  const pity = player.pity;

  // guarantee epic
  if (pity.epicCounter >= 10) {
    pity.epicCounter = 0;
    return "epic";
  }

  // guarantee legendary
  if (pity.legendaryCounter >= 25) {
    pity.legendaryCounter = 0;
    return "legendary";
  }

  const result = rollRarity();

  if (result === "epic" || result === "legendary") {
    pity.epicCounter = 0;
  } else {
    pity.epicCounter++;
  }

  if (result === "legendary") {
    pity.legendaryCounter = 0;
  } else {
    pity.legendaryCounter++;
  }

  return result;
}
