import {
  SAVE_KEY,
  SAVE_BACKUP_KEY
} from "./saveConfig";
import { safeStringify, safeParse } from "./saveUtils";
import { buildSaveData } from "./saveBuilder";

export function saveGame(player: any) {
  try {
    const data = buildSaveData(player);
    if (!data) return;

    const str = safeStringify(data);
    if (!str) return;

    // backup first
    localStorage.setItem(SAVE_BACKUP_KEY, str);

    // main save
    localStorage.setItem(SAVE_KEY, str);
  } catch (e) {
    console.warn("[Save] failed", e);
  }
}

export function loadGame() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);

    let data = safeParse(raw);

    if (!data) {
      // fallback to backup
      const backup = localStorage.getItem(SAVE_BACKUP_KEY);
      data = safeParse(backup);
    }

    return data;
  } catch (e) {
    console.warn("[Load] failed", e);
    return null;
  }
}
