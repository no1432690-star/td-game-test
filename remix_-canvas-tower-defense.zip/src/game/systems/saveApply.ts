export function applySaveToPlayer(player: any, save: any) {
  if (!player || !save) return;

  // === [PATCH] Prevent artifact load from save ===
  if (save.artifacts) {
    console.warn("[ArtifactPatch] Ignored saved artifacts (in-run only system)");
  }

  try {
    if (save.meta) {
      player.meta = {
        corruptedShards:
          save.meta.corruptedShards || 0,
        upgrades: save.meta.upgrades || {}
      };
    }

    if (save.stats) {
      player.totalRuns = save.stats.totalRuns || 0;
    }

    if (save.analytics) {
      player.analytics = save.analytics;
    }
  } catch (e) {
    console.warn("[ApplySave] error", e);
  }
}
