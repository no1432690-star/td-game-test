import { ARTIFACT_RARITY } from "./artifactRarity";

export function getScaledValue(effect: any, stacks: number, rarity?: string) {
  if (!effect) return 0;

  const base = effect.value || 0;
  const s = stacks || 1;

  let scaled;

  switch (effect.scaling) {
    case "linear":
      scaled = base * s;
      break;

    case "exponential":
      scaled = base * Math.pow(1.5, s - 1);
      break;

    case "diminishing":
      scaled = base * (1 + 0.5 * (s - 1));
      break;

    default:
      scaled = base;
  }

  const mult =
    (rarity && ARTIFACT_RARITY[rarity]?.multiplier) || 1;

  return scaled * mult;
}
