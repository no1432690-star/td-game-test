export function safeStringify(data: any) {
  try {
    return JSON.stringify(data);
  } catch (e) {
    console.warn("[Save] stringify error", e);
    return null;
  }
}

export function safeParse(str: string | null) {
  if (!str) return null;
  try {
    return JSON.parse(str);
  } catch (e) {
    console.warn("[Save] parse error", e);
    return null;
  }
}
