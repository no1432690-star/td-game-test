export const ARTIFACT_RARITY: Record<string, { weight: number, multiplier: number }> = {
  common: { weight: 60, multiplier: 1 },
  rare: { weight: 25, multiplier: 1.5 },
  epic: { weight: 10, multiplier: 2.2 },
  legendary: { weight: 5, multiplier: 3 }
};
