import { bindArtifact } from "./artifactRuntime";
import { ArtifactEventBus } from "./artifactEventBus";
import { buildStackMap } from "./artifactStackEngine";
import { resolveSynergies, bindSynergy } from "./artifactSynergy";

export function applyArtifactsForRun(player: any, artifacts: any[]) {
  ArtifactEventBus.clear();

  if (!player) return;

  const safeArtifacts = Array.isArray(artifacts) ? artifacts : [];

  const stackMap = buildStackMap(safeArtifacts);
  const context = { player };

  // bind stacked artifacts
  for (const key in stackMap) {
    if (!stackMap[key]) continue;
    bindArtifact(stackMap[key], context);
  }

  // resolve + bind synergies
  const synergies = resolveSynergies(stackMap);

  for (let i = 0; i < synergies.length; i++) {
    bindSynergy(synergies[i], context);
  }
}
