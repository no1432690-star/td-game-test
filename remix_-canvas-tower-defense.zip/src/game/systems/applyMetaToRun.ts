import { getUpgradeValue } from "./metaUpgrades";

export function applyMetaToPlayer(player: any) {
  if (!player) return;

  try {
    const hpBonus = getUpgradeValue(player, "hp_boost");

    if (typeof player.hp === "number") {
      player.hp += hpBonus;
    }
  } catch (e) {}
}
