import { showArtifactChoiceUI, playRevealAnimation } from "./artifactUI";
import { playArtifactSound } from "./artifactFeedback";

export function openArtifactChoice(player: any, createSession: Function, callbacks: any = {}) {
  if (!player || typeof createSession !== "function") {
    return null;
  }

  const session = createSession(player);

  try {
    playRevealAnimation();
    playArtifactSound("select");
  } catch (e) {}

  const ui = showArtifactChoiceUI(session, callbacks);

  return {
    session,
    ui
  };
}

export function pauseGame(game: any) {
  try {
    if (game && typeof game === "object") {
      game.paused = true;
    }
  } catch (e) {}
}

export function resumeGame(game: any) {
  try {
    if (game && typeof game === "object") {
      game.paused = false;
    }
  } catch (e) {}
}
