export const RARITY_VISUAL: Record<string, { color: string, glow: boolean }> = {
  common: { color: "#aaaaaa", glow: false },
  rare: { color: "#4da6ff", glow: true },
  epic: { color: "#b84dff", glow: true },
  legendary: { color: "#ffcc00", glow: true }
};

export function showArtifactChoiceUI(session: any, callbacks: any = {}) {
  if (!session || !Array.isArray(session.choices)) return null;

  const safeCallbacks = {
    onSelect:
      typeof callbacks.onSelect === "function"
        ? callbacks.onSelect
        : () => {},
    onReroll:
      typeof callbacks.onReroll === "function"
        ? callbacks.onReroll
        : () => {}
  };

  // Engine-agnostic UI descriptor
  return {
    visible: true,
    choices: session.choices,
    rerollCost: session.rerollCost || 0,
    callbacks: safeCallbacks
  };
}

export function getArtifactVisual(artifact: any) {
  if (!artifact || !artifact.rarity) {
    return RARITY_VISUAL.common;
  }

  return (
    RARITY_VISUAL[artifact.rarity] ||
    RARITY_VISUAL.common
  );
}

export function playRevealAnimation() {
  try {
    console.log("[ArtifactUI] reveal");
  } catch (e) {}
}

export function playSelectAnimation() {
  try {
    console.log("[ArtifactUI] select");
  } catch (e) {}
}

export function playRerollAnimation() {
  try {
    console.log("[ArtifactUI] reroll");
  } catch (e) {}
}
