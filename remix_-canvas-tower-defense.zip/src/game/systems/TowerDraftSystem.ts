import { TOWER_TYPES } from '../constants';
import towerPoolData from '../../data/towerPool.json';

export type TowerRarity = "common" | "rare" | "epic";

export interface TowerDraftEntry {
    type: string;
    rarity: TowerRarity;
    weight: number;
}

export class TowerDraftSystem {
    public pendingDraft: TowerDraftEntry[] | null = null;

    private towerPool: TowerDraftEntry[] = [
        { type: "Archer", rarity: "common", weight: (towerPoolData as any).archer || 60 },
        { type: "Bomber", rarity: "rare", weight: (towerPoolData as any).bomber || 30 },
        { type: "Frost", rarity: "epic", weight: (towerPoolData as any).frost || 10 },
        { type: "Tesla", rarity: "rare", weight: (towerPoolData as any).tesla || 20 }
    ];

    generateDraft(wave: number, corruptionLevel: number = 0): void {
        this.pendingDraft = [];

        // Calculate dynamic weights based on wave
        const waveBonus = Math.floor(wave / 5);
        
        const currentPool = this.towerPool.map(entry => {
            let newWeight = entry.weight;
            if (entry.rarity === "common") {
                newWeight = Math.max(10, newWeight - waveBonus * 2); // Reduce common slightly
            } else if (entry.rarity === "rare") {
                newWeight += waveBonus * 1.5; // Increase rare
            } else if (entry.rarity === "epic") {
                newWeight += waveBonus * 0.5; // Increase epic slightly
            }
            return { ...entry, weight: newWeight };
        });

        if (corruptionLevel > 0) {
            for (const entry of currentPool) {
                if (entry.rarity === "common") {
                    entry.weight = Math.max(5, entry.weight - corruptionLevel * 5);
                } else if (entry.rarity === "rare") {
                    entry.weight += corruptionLevel * 5;
                } else if (entry.rarity === "epic") {
                    entry.weight += corruptionLevel * 2;
                }
            }
            currentPool.push({ type: "CursedArcher", rarity: "epic", weight: 5 * corruptionLevel });
        }

        // Filter out non-rewardable towers
        let rewardPool = currentPool.filter(t => {
            const def = TOWER_TYPES[t.type as keyof typeof TOWER_TYPES];
            if (!def) return true; // Fallback if not defined
            if (def.rewardable === false) return false;
            if ((def as any).mutationOnly) return false;
            if ((def as any).enemyOnly) return false;
            if ((def as any).hidden) return false;
            return true;
        });

        // Safe fallback
        if (rewardPool.length === 0) {
            rewardPool = this.towerPool;
        }

        // Generate 3 choices using weighted random selection
        while (this.pendingDraft.length < 3) {
            const totalWeight = rewardPool.reduce((sum, item) => sum + item.weight, 0);
            let random = Math.random() * totalWeight;
            
            let selected: TowerDraftEntry | null = null;
            for (const item of rewardPool) {
                random -= item.weight;
                if (random <= 0) {
                    selected = item;
                    break;
                }
            }
            
            if (selected) {
                this.pendingDraft.push(selected);
            }
        }
    }

    clearDraft(): void {
        this.pendingDraft = null;
    }
}
