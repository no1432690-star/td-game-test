export function createOnboardingHint(step: any) {
  if (!step) return null;

  return {
    text: step.text,
    highlight: step.id
  };
}

export function getHighlightTarget(stepId: string) {
  switch (stepId) {
    case "artifact_choice":
      return "artifact_ui";

    case "reroll_hint":
      return "reroll_button";

    default:
      return null;
  }
}
