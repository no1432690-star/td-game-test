import { ARTIFACT_RARITY } from "./artifactRarity";

export function rollRarity() {
  const entries = Object.entries(ARTIFACT_RARITY);
  if (entries.length === 0) return "common";

  let total = 0;
  for (let i = 0; i < entries.length; i++) {
    total += entries[i][1].weight || 0;
  }

  if (total <= 0) return "common";

  let roll = Math.random() * total;

  for (let i = 0; i < entries.length; i++) {
    const [key, data] = entries[i];
    roll -= data.weight || 0;
    if (roll <= 0) return key;
  }

  return "common";
}

export function getPoolByRarity(pool: any[], rarity: string) {
  if (!Array.isArray(pool)) return [];

  const result = [];

  for (let i = 0; i < pool.length; i++) {
    const item = pool[i];
    if (!item || !item.id) continue;
    if (item.rarity === rarity) result.push(item);
  }

  return result;
}
