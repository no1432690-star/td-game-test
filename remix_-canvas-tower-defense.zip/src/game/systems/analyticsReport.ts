export function generateAnalyticsReport(player: any) {
  if (!player || !player.analytics) return null;

  const data = player.analytics;

  const topArtifacts = Object.entries(data.artifactPicks || {})
    .sort((a: any, b: any) => b[1] - a[1])
    .slice(0, 5);

  return {
    runs: data.runs || 0,
    deaths: data.totalDeaths || 0,
    kills: data.kills || 0,
    rerolls: data.rerolls || 0,
    topArtifacts
  };
}

export function exportAnalytics(player: any) {
  if (!player || !player.analytics) return null;

  try {
    return JSON.stringify(player.analytics);
  } catch (e) {
    return null;
  }
}

export function resetAnalytics(player: any) {
  if (!player) return;

  player.analytics = {
    runs: 0,
    totalDeaths: 0,
    kills: 0,
    rerolls: 0,
    artifactPicks: {}
  };
}
