export function buildStackMap(artifacts: any[]) {
  const map: Record<string, any> = {};

  if (!Array.isArray(artifacts)) return map;

  for (let i = 0; i < artifacts.length; i++) {
    const art = artifacts[i];
    if (!art || !art.id) continue;

    if (!map[art.id]) {
      map[art.id] = {
        ...art,
        stacks: 1
      };
    } else {
      map[art.id].stacks += 1;
    }
  }

  return map;
}
