import { generateArtifactChoices, generateChoicesWithPity } from "./artifactDropSystem";
import { addArtifact } from "./artifactEngine";

export function createArtifactChoiceSession(player: any, options: any = {}) {
  const count = options.count || 3;
  const rerollCost = options.rerollCost || 50;

  const safeArtifacts = Array.isArray(player?.artifacts)
    ? player.artifacts
    : [];

  // safe override
  const generator =
    options.usePity === true
      ? (artifacts: any, c: number) => generateChoicesWithPity(player, c)
      : generateArtifactChoices;

  return {
    choices: generator(safeArtifacts, count) || [],
    rerollCost,
    selected: null
  };
}

export function selectArtifact(player: any, session: any, artifactId: string) {
  if (!player || !session) return null;

  const choices = Array.isArray(session.choices)
    ? session.choices
    : [];

  const found = choices.find((a: any) => a && a.id === artifactId);
  if (!found) return null;

  // === [PATCH] Ensure shop adds artifact correctly ===
  if ((window as any).ArtifactRuntime) {
    (window as any).ArtifactRuntime.ensure(player);
  }
  
  addArtifact(player, found.id, 1);

  session.selected = found;

  return found;
}

export function rerollChoices(player: any, session: any) {
  if (!player || !session) return;

  if (typeof player.gold !== "number") return;

  if (player.gold < (session.rerollCost || 0)) return;

  player.gold -= session.rerollCost || 0;

  const count = Array.isArray(session.choices)
    ? session.choices.length
    : 3;

  session.choices = generateArtifactChoices(
    player.artifacts,
    count
  ) || [];
}
