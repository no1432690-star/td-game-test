export const ONBOARDING_STEPS = [
  {
    id: "welcome",
    text: "Defeat enemies to survive."
  },
  {
    id: "artifact_choice",
    text: "Choose an artifact to gain power."
  },
  {
    id: "reroll_hint",
    text: "You can reroll if you don't like the choices."
  },
  {
    id: "goal",
    text: "Survive as long as possible."
  }
];

export function getCurrentStep(player: any) {
  if (!player?.onboarding) return null;

  return ONBOARDING_STEPS[player.onboarding.step] || null;
}

export function nextOnboardingStep(player: any) {
  if (!player?.onboarding) return;

  player.onboarding.step++;

  if (player.onboarding.step >= ONBOARDING_STEPS.length) {
    player.onboarding.completed = true;
  }
}

export function shouldShowOnboarding(player: any, trigger: string) {
  if (!player?.onboarding) return false;

  if (player.onboarding.completed) return false;

  const step = player.onboarding.step;

  switch (trigger) {
    case "game_start":
      return step === 0;

    case "artifact_open":
      return step === 1;

    case "reroll_used":
      return step === 2;

    default:
      return false;
  }
}

export function skipOnboarding(player: any) {
  if (!player?.onboarding) return;

  player.onboarding.completed = true;
}

export function applyFirstRunBoost(player: any) {
  if (!player?.onboarding) return;

  if (player.onboarding.completed) return;

  if (!Array.isArray(player.artifacts)) {
    player.artifacts = [];
  }

  // safe: do not inject strong items, just ensure non-empty start
}
