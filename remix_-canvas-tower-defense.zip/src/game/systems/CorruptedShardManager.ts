export class CorruptedShardManager {
  private static _instance: CorruptedShardManager;

  public currentRunShards: number = 0;
  public totalCorruptionsThisRun: number = 0;
  public metaShards: number = 0;
  public totalShardsSpentEver: number = 0;

  static get instance(): CorruptedShardManager {
    if (!this._instance) {
      this._instance = new CorruptedShardManager();
    }
    return this._instance;
  }

  addShards(amount: number) {
    if (!amount || amount <= 0) return;
    this.currentRunShards += Math.floor(amount);
  }

  spendShards(amount: number): boolean {
    if (this.currentRunShards < amount) return false;
    this.currentRunShards -= amount;
    return true;
  }

  getCorruptionCost(): number {
    return Math.floor(
      100 * Math.pow(1.15, this.totalCorruptionsThisRun)
    );
  }

  getRetentionRate(): number {
    return this.totalShardsSpentEver >= 20000 ? 0.30 : 0.10;
  }

  registerCorruption(cost: number) {
    this.totalCorruptionsThisRun++;
    this.totalShardsSpentEver += cost;
  }

  resetRun() {
    this.currentRunShards = 0;
    this.totalCorruptionsThisRun = 0;
  }
}
