import teslaCorruptions from '../../../data/corruptions/tesla_corruptions.json';

export class CorruptionManager {
  static definitions: Record<string, any> = {};

  static init() {
    this.definitions[teslaCorruptions.id] = teslaCorruptions;
  }

  static getCorruption(id: string) {
    return this.definitions[id];
  }
}
