import { Tower } from '../../entities/Tower';
import { TowerSpatialGrid } from './TowerSpatialGrid';

export class TowerRegistry {
  private static towers: Tower[] = [];

  static addTower(tower: Tower) {
    if (!this.towers.includes(tower)) {
      this.towers.push(tower);
      TowerSpatialGrid.addTower(tower);
    }
  }

  static removeTower(tower: Tower) {
    this.towers = this.towers.filter(t => t !== tower);
    TowerSpatialGrid.removeTower(tower);
  }

  static getTowers(): Tower[] {
    return this.towers;
  }

  static getTowersByType(type: string): Tower[] {
    return this.towers.filter(t => t.constructor.name === type);
  }

  static clear() {
    this.towers = [];
    TowerSpatialGrid.clear();
  }
}
