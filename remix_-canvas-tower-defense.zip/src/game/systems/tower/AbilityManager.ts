export class AbilityManager {
  private static handlers: Record<string, Function> = {};

  static register(abilityId: string, handler: Function) {
    this.handlers[abilityId] = handler;
  }

  static execute(abilityId: string, tower: any, target: any, ...args: any[]) {
    const handler = this.handlers[abilityId];
    if (handler) {
      handler(tower, target, ...args);
    } else {
      console.warn(`Ability handler for ${abilityId} not found.`);
    }
  }
}
