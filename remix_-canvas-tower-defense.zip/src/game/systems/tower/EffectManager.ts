import { Tower } from '../../entities/Tower';
import { Enemy } from '../../entities/Enemy';

export interface Effect {
  id: string;
  source: Tower | null;
  target: Tower | Enemy;
  duration: number;
  apply: () => void;
  remove: () => void;
  update?: (dt: number) => void;
}

export class EffectManager {
  private static effects: Effect[] = [];

  static addEffect(effect: Effect) {
    this.effects.push(effect);
    effect.apply();
  }

  static removeEffect(id: string) {
    const index = this.effects.findIndex(e => e.id === id);
    if (index !== -1) {
      this.effects[index].remove();
      this.effects.splice(index, 1);
    }
  }

  static update(dt: number) {
    const currentEffects = [...this.effects];
    for (const effect of currentEffects) {
      if (!this.effects.includes(effect)) continue;

      if (effect.duration > 0) {
        effect.duration -= dt;
        if (effect.update) effect.update(dt);
        if (effect.duration <= 0) {
          this.removeEffect(effect.id);
        }
      }
    }
  }

  static clear() {
    for (const effect of this.effects) {
      effect.remove();
    }
    this.effects = [];
  }
}
