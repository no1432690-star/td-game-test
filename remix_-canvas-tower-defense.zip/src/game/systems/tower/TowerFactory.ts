import { Tower } from '../../entities/Tower';
import { Archer } from '../../entities/Archer';
import { Bomber } from '../../entities/Bomber';
import { Frost } from '../../entities/Frost';
import { Tesla } from '../../entities/Tesla';
import { Vector2 } from '../../utils/Vector2';
import archerConfig from '../../../data/towers/archer.json';
import bomberConfig from '../../../data/towers/bomber.json';
import frostConfig from '../../../data/towers/frost.json';
import teslaConfig from '../../../data/towers/tesla.json';

export class TowerFactory {
  static configs: Record<string, any> = {
    archer: archerConfig,
    bomber: bomberConfig,
    frost: frostConfig,
    tesla: teslaConfig
  };

  static create(id: string, x: number, y: number, enemies?: any[]): Tower {
    const config = this.configs[id.toLowerCase()];
    
    // Fallback to hardcoded classes if no config or if we want to maintain backward compatibility
    // For now, we instantiate the specific classes so existing logic works,
    // but we can inject config data into them if needed.
    let tower: Tower;
    switch (id.toLowerCase()) {
      case 'archer':
        tower = new Archer(x, y);
        break;
      case 'bomber':
        tower = new Bomber(x, y, enemies || []);
        break;
      case 'frost':
        tower = new Frost(x, y);
        break;
      case 'tesla':
        tower = new Tesla(x, y);
        break;
      default:
        // Generic tower fallback if we create a new one via config
        tower = new Tower(id.toLowerCase(), x, y);
        if (config) {
          tower.baseDamage = config.baseStats.damage;
          tower.baseRange = config.baseStats.range;
          tower.baseCooldown = config.baseStats.cooldown;
          tower.baseCost = config.baseStats.cost;
          (tower as any).configId = id;
        }
        break;
    }

    if (config) {
      (tower as any).config = config;
    }

    return tower;
  }
}
