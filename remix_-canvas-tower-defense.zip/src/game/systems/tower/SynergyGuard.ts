export class SynergyGuard {
  private static isSynergyGenerated = false;

  static execute(fn: () => void) {
    if (this.isSynergyGenerated) return;
    this.isSynergyGenerated = true;
    try {
      fn();
    } finally {
      this.isSynergyGenerated = false;
    }
  }

  static isGenerated(): boolean {
    return this.isSynergyGenerated;
  }
}
