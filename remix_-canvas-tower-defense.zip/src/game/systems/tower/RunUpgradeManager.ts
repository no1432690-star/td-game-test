import { UpgradeDefinition } from '../UpgradeManager';
import teslaUpgrades from '../../../data/runUpgrades/teslaUpgrades.json';

export class RunUpgradeManager {
  static definitions: any[] = [];

  static init() {
    // Load dynamic definitions
    this.definitions.push(teslaUpgrades);
  }

  static getUpgrades() {
    return this.definitions;
  }
}
