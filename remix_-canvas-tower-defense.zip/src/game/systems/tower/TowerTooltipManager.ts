import { TowerFactory } from './TowerFactory';

export class TowerTooltipManager {
  static getTooltipContent(towerId: string) {
    const config = TowerFactory.configs[towerId.toLowerCase()];
    if (!config) {
      return {
        title: towerId,
        stats: {},
        abilities: [],
        synergies: []
      };
    }

    return {
      title: config.id,
      stats: config.baseStats,
      abilities: config.abilities || [],
      tags: config.tags || []
    };
  }
}
