import { TowerEventSystem, TowerEventData } from './TowerEventSystem';
import { AbilityManager } from './AbilityManager';
import teslaArcherSynergy from '../../../data/synergies/tesla_archer.json';

type SynergyHandler = (data: TowerEventData) => void;

export class SynergyManager {
  private static synergies: Record<string, SynergyHandler[]> = {};
  private static initialized: boolean = false;

  static init() {
    if (!this.initialized) {
      this.initialized = true;
      TowerEventSystem.on('onHitEnemy', (data) => this.handleEvent('onHitEnemy', data));
      TowerEventSystem.on('onExplosion', (data) => this.handleEvent('onExplosion', data));
      TowerEventSystem.on('onAttack', (data) => this.handleEvent('onAttack', data));
      this.loadConfigs();
    }
  }

  static loadConfigs() {
    const configs = [teslaArcherSynergy];
    for (const config of configs) {
      // Assuming the config specifies the event, but our JSON doesn't have it.
      // Let's assume it's onHitEnemy by default or we can map it.
      // For now, we just register it to onHitEnemy if not specified.
      const event = (config as any).event || 'onHitEnemy';
      this.register(config.source, config.target, event, (data) => {
        AbilityManager.execute(config.effect, data.sourceTower, data.targetEnemy, data);
      });
    }
  }

  static register(sourceTowerType: string, targetTowerType: string, event: string, handler: SynergyHandler) {
    const key = `${sourceTowerType}_${targetTowerType}_${event}`;
    if (!this.synergies[key]) {
      this.synergies[key] = [];
    }
    this.synergies[key].push(handler);
  }

  static handleEvent(event: string, data: TowerEventData) {
    if (!data.towerType) return;
    
    // We don't know the sourceTowerType here, so we iterate over all possible source towers
    // that have a synergy with this target tower type for this event.
    // A better way is to let the specific synergy logic check if the source tower is present/linked.
    // For now, we just trigger all handlers registered for this targetTowerType and event.
    
    for (const key in this.synergies) {
      const parts = key.split('_');
      const targetType = parts[1];
      const ev = parts[2];
      
      if (targetType === data.towerType && ev === event) {
        for (const handler of this.synergies[key]) {
          handler(data);
        }
      }
    }
  }

  static checkSynergy(sourceTowerType: string, targetTowerType: string, event: string, data: TowerEventData) {
    const key = `${sourceTowerType}_${targetTowerType}_${event}`;
    if (this.synergies[key]) {
      for (const handler of this.synergies[key]) {
        handler(data);
      }
    }
  }

  static clear() {
    this.synergies = {};
  }
}
