import { AbilityManager } from './AbilityManager';

export class MilestoneManager {
  static checkMilestones(tower: any) {
    if (!tower.config || !tower.config.milestones) return;

    const milestones = tower.config.milestones;
    const currentLevel = tower.level.toString();

    if (milestones[currentLevel]) {
      const abilityId = milestones[currentLevel];
      // We can execute or register the ability to the tower
      // For now, we just attach it to the tower's active milestone abilities
      if (!tower.activeMilestones) {
        tower.activeMilestones = [];
      }
      if (!tower.activeMilestones.includes(abilityId)) {
        tower.activeMilestones.push(abilityId);
        // Optionally trigger an immediate effect
        AbilityManager.execute(abilityId, tower, null);
      }
    }
  }
}
