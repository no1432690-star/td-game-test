import { TowerFactory } from './TowerFactory';
import { AbilityManager } from './AbilityManager';
import { SynergyManager } from './SynergyManager';
import teslaArcherSynergy from '../../../data/synergies/tesla_archer.json';

export class ContentValidator {
  static validate() {
    console.log('[ContentValidator] Validating game data...');

    // Validate Towers
    for (const [id, config] of Object.entries(TowerFactory.configs)) {
      if (!config) continue;
      
      if (!config.baseStats) {
        console.warn(`[ContentValidator] Tower ${id} is missing baseStats.`);
      } else {
        if (config.baseStats.damage === undefined) console.warn(`[ContentValidator] Tower ${id} is missing damage stat.`);
        if (config.baseStats.range === undefined) console.warn(`[ContentValidator] Tower ${id} is missing range stat.`);
        if (config.baseStats.cooldown === undefined) console.warn(`[ContentValidator] Tower ${id} is missing cooldown stat.`);
      }

      if (config.abilities) {
        for (const ability of config.abilities) {
          // We can't strictly check AbilityManager handlers here if they are registered later,
          // but we can check if they are expected.
          // For now, we just log that we are checking.
        }
      }
    }

    // Validate Synergies
    const synergies = [teslaArcherSynergy];
    for (const syn of synergies) {
      if (!syn.source || !syn.target || !syn.effect) {
        console.warn(`[ContentValidator] Invalid synergy definition:`, syn);
      }
    }

    console.log('[ContentValidator] Validation complete.');
  }
}
