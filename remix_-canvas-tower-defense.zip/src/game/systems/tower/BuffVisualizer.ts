import { Tower } from '../../entities/Tower';
import { TowerLinkManager } from './TowerLinkManager';
import { TowerNetworkManager } from './TowerNetworkManager';
import { TowerRegistry } from './TowerRegistry';

export class BuffVisualizer {
  static render(ctx: CanvasRenderingContext2D, selectedTower: Tower | null) {
    const teslas = TowerRegistry.getTowersByType('Tesla');

    for (const tesla of teslas) {
      const isSelected = selectedTower === tesla;

      if (isSelected) {
        // We'll get the radius from the tower or a system
        const radius = (tesla as any).electricFieldRadius || 150;
        ctx.beginPath();
        ctx.arc(tesla.position.x, tesla.position.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(14, 165, 233, 0.2)'; // Blue circle, 20% opacity
        ctx.fill();
        ctx.strokeStyle = 'rgba(14, 165, 233, 0.5)';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.closePath();
      }

      // Draw links
      // We no longer use TowerLinkManager. We draw links from towers to teslas.
    }

    const allTowers = TowerRegistry.getTowers();
    for (const tower of allTowers) {
      if (tower.teslaLinks && tower.teslaLinks.length > 0) {
        for (const tesla of tower.teslaLinks) {
          const targetType = tower.constructor.name;
          if (targetType === 'Archer') ctx.strokeStyle = 'rgba(234, 179, 8, 0.6)'; // Yellow
          else if (targetType === 'Bomber') ctx.strokeStyle = 'rgba(249, 115, 22, 0.6)'; // Orange
          else if (targetType === 'Frost') ctx.strokeStyle = 'rgba(6, 182, 212, 0.6)'; // Cyan
          else if (targetType === 'Tesla') ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)'; // Blue
          else ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';

          ctx.beginPath();
          ctx.moveTo(tesla.position.x, tesla.position.y);
          ctx.lineTo(tower.position.x, tower.position.y);
          
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.closePath();
        }
      }
    }
  }
}
