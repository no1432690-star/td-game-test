import { Tower } from '../../entities/Tower';
import { Enemy } from '../../entities/Enemy';

export interface TowerEventData {
  sourceTower: Tower;
  targetEnemy?: Enemy;
  damage?: number;
  towerType?: string;
  [key: string]: any;
}

type EventHandler = (data: TowerEventData) => void;

export class TowerEventSystem {
  private static listeners: Record<string, EventHandler[]> = {};

  static on(event: string, handler: EventHandler) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(handler);
  }

  static off(event: string, handler: EventHandler) {
    if (!this.listeners[event]) return;
    this.listeners[event] = this.listeners[event].filter(h => h !== handler);
  }

  static emit(event: string, data: TowerEventData) {
    if (!this.listeners[event]) return;
    const currentListeners = [...this.listeners[event]];
    for (const handler of currentListeners) {
      if (!this.listeners[event].includes(handler)) continue;
      handler(data);
    }
  }

  static clear() {
    this.listeners = {};
  }
}
