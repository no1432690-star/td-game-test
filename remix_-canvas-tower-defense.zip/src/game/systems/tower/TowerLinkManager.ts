import { Tower } from '../../entities/Tower';
import { TowerSpatialGrid } from './TowerSpatialGrid';
import { TowerRegistry } from './TowerRegistry';

export interface TowerLink {
  source: Tower;
  target: Tower;
  distance: number;
}

export class TowerLinkManager {
  private static links: Map<Tower, TowerLink[]> = new Map();

  static updateLinks(tower: Tower, maxLinks: number, maxDistance: number) {
    const nearbyTowers = TowerSpatialGrid.getTowersInRange(tower.position, maxDistance);
    const validTargets = nearbyTowers
      .filter(t => t !== tower)
      .map(t => ({ target: t, distance: tower.position.dist(t.position) }))
      .sort((a, b) => a.distance - b.distance)
      .slice(0, maxLinks);

    const newLinks = validTargets.map(t => ({ source: tower, target: t.target, distance: t.distance }));
    this.links.set(tower, newLinks);
    this.recalculateAllTeslaLinks();
  }

  static getLinks(tower: Tower): TowerLink[] {
    return this.links.get(tower) || [];
  }

  static removeTower(tower: Tower) {
    this.links.delete(tower);
    // Remove links targeting this tower
    for (const [source, sourceLinks] of this.links.entries()) {
      this.links.set(source, sourceLinks.filter(link => link.target !== tower));
    }
    this.recalculateAllTeslaLinks();
  }

  static clear() {
    this.links.clear();
  }

  private static recalculateAllTeslaLinks() {
    // Logic moved to BuffSystem.ts
  }
}
