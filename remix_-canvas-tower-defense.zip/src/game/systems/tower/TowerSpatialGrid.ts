import { Tower } from '../../entities/Tower';
import { Vector2 } from '../../utils/Vector2';

export class TowerSpatialGrid {
  private static cellSize = 200;
  private static grid: Map<string, Tower[]> = new Map();

  static getCellKey(pos: Vector2): string {
    const x = Math.floor(pos.x / this.cellSize);
    const y = Math.floor(pos.y / this.cellSize);
    return `${x},${y}`;
  }

  static addTower(tower: Tower) {
    const key = this.getCellKey(tower.position);
    if (!this.grid.has(key)) {
      this.grid.set(key, []);
    }
    this.grid.get(key)!.push(tower);
  }

  static removeTower(tower: Tower) {
    const key = this.getCellKey(tower.position);
    const cell = this.grid.get(key);
    if (cell) {
      this.grid.set(key, cell.filter(t => t !== tower));
    }
  }

  static updateTower(tower: Tower, oldPos: Vector2) {
    const oldKey = this.getCellKey(oldPos);
    const newKey = this.getCellKey(tower.position);
    if (oldKey !== newKey) {
      const oldCell = this.grid.get(oldKey);
      if (oldCell) {
        this.grid.set(oldKey, oldCell.filter(t => t !== tower));
      }
      this.addTower(tower);
    }
  }

  static getTowersInRange(pos: Vector2, range: number): Tower[] {
    const towers: Tower[] = [];
    const minX = Math.floor((pos.x - range) / this.cellSize);
    const maxX = Math.floor((pos.x + range) / this.cellSize);
    const minY = Math.floor((pos.y - range) / this.cellSize);
    const maxY = Math.floor((pos.y + range) / this.cellSize);

    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        const key = `${x},${y}`;
        const cell = this.grid.get(key);
        if (cell) {
          for (const tower of cell) {
            if (tower.position.dist(pos) <= range) {
              towers.push(tower);
            }
          }
        }
      }
    }
    return towers;
  }

  static clear() {
    this.grid.clear();
  }
}
