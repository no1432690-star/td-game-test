interface GameTimer {
  id: string;
  interval: number;
  timeRemaining: number;
  callback: () => void;
  loop: boolean;
}

export class GameTimerManager {
  private static timers: GameTimer[] = [];

  static registerTimer(id: string, interval: number, callback: () => void, loop: boolean = false) {
    this.timers.push({ id, interval, timeRemaining: interval, callback, loop });
  }

  static removeTimer(id: string) {
    this.timers = this.timers.filter(t => t.id !== id);
  }

  static update(dt: number) {
    // Copy array to avoid issues if callback adds/removes timers
    const currentTimers = [...this.timers];
    for (const timer of currentTimers) {
      // If it was removed by another callback, skip it
      if (!this.timers.includes(timer)) continue;

      timer.timeRemaining -= dt;
      if (timer.timeRemaining <= 0) {
        timer.callback();
        if (timer.loop) {
          timer.timeRemaining += timer.interval;
        } else {
          this.removeTimer(timer.id);
        }
      }
    }
  }

  static clear() {
    this.timers = [];
  }
}
