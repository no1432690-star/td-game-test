import teslaLegendary from '../../../data/legendary/tesla_legendary.json';

export class LegendaryManager {
  static definitions: Record<string, any> = {};

  static init() {
    this.definitions[teslaLegendary.id] = teslaLegendary;
  }

  static getLegendary(id: string) {
    return this.definitions[id];
  }

  static applyLegendary(tower: any) {
    if (tower.level >= 25 && tower.isLegendary) {
      // Apply effects based on tower type
      const config = Object.values(this.definitions).find(def => def.tower === tower.constructor.name.toLowerCase());
      if (config) {
        // Apply config effects
        if (config.effects) {
          Object.assign(tower, config.effects);
        }
      }
    }
  }
}
