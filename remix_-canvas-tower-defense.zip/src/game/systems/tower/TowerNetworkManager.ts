import { Tower } from '../../entities/Tower';
import { TowerLinkManager } from './TowerLinkManager';
import { GameTimerManager } from './GameTimerManager';
import { TowerRegistry } from './TowerRegistry';

export class TowerNetworkManager {
  private static networks: Set<Tower>[] = [];

  static init() {
    GameTimerManager.registerTimer('network_check', 2.0, () => this.detectNetworks(), true);
  }

  static detectNetworks() {
    this.networks = [];
    const visited = new Set<Tower>();
    const teslas = TowerRegistry.getTowersByType('Tesla');

    for (const tesla of teslas) {
      if (!visited.has(tesla)) {
        const network = this.buildNetwork(tesla, visited);
        if (network.size >= 5) {
          this.networks.push(network);
        }
      }
    }
  }

  static buildNetwork(startTower: Tower, visited: Set<Tower>): Set<Tower> {
    const network = new Set<Tower>();
    const queue: Tower[] = [startTower];
    const teslas = TowerRegistry.getTowersByType('Tesla');
    
    visited.add(startTower);

    while (queue.length > 0) {
      const current = queue.shift()!;
      network.add(current);

      const currentRadius = (current as any).electricFieldRadius || 150;

      for (const other of teslas) {
        if (!visited.has(other)) {
          const dist = current.position.dist(other.position);
          if (dist <= currentRadius) {
            visited.add(other);
            queue.push(other);
          }
        }
      }
    }

    return network;
  }

  static getNetworks(): Set<Tower>[] {
    return this.networks;
  }

  static clear() {
    this.networks = [];
  }
}
