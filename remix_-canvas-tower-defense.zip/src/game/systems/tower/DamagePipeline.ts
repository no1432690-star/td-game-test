import { Tower } from '../../entities/Tower';
import { Enemy } from '../../entities/Enemy';

export interface DamageData {
  sourceTower: Tower;
  targetEnemy: Enemy;
  baseDamage: number;
  finalDamage: number;
  isCrit: boolean;
  damageType: string;
}

type DamageModifier = (data: DamageData) => void;

export class DamagePipeline {
  private static modifiers: DamageModifier[] = [];

  static registerModifier(modifier: DamageModifier) {
    this.modifiers.push(modifier);
  }

  static unregisterModifier(modifier: DamageModifier) {
    this.modifiers = this.modifiers.filter(m => m !== modifier);
  }

  static applyModifiers(data: DamageData): DamageData {
    const currentModifiers = [...this.modifiers];
    for (const modifier of currentModifiers) {
      if (!this.modifiers.includes(modifier)) continue;
      modifier(data);
    }
    return data;
  }

  static clear() {
    this.modifiers = [];
  }
}
