export const ArtifactEventBus = {
  listeners: {} as Record<string, Function[]>,

  on(event: string, fn: Function) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(fn);
  },

  emit(event: string, payload: any) {
    const list = this.listeners[event];
    if (!list) return;

    for (let i = 0; i < list.length; i++) {
      try {
        list[i](payload);
      } catch (e) {
        console.warn("[ArtifactEventBus error]", event, e);
      }
    }
  },

  clear() {
    this.listeners = {};
  }
};
