export function getSlotUnlockCost(index: number) {
  if (index < 30) return 0;
  const tierIndex = index - 30;
  return Math.floor(10000 * Math.pow(1.35, tierIndex));
}

export function initializeSlots(slots: any[]) {
  return slots.map((slot, index) => {
    slot.tier = index < 30 ? 1 : 2;
    slot.unlocked = index < 30;
    slot.unlockCost = getSlotUnlockCost(index);
    return slot;
  });
}
