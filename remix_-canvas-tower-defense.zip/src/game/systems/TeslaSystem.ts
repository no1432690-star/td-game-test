import { Tower } from '../entities/Tower';
import { Enemy } from '../entities/Enemy';
import { applyDamage } from './BuffSystem';
import { RunModifiers } from './RunSystem';
import { UpgradeManager } from './UpgradeManager';
import { Vector2 } from '../utils/Vector2';
import { TowerEventSystem, TowerEventData } from './tower/TowerEventSystem';
import { SynergyManager } from './tower/SynergyManager';
import { TowerLinkManager } from './tower/TowerLinkManager';
import { TowerNetworkManager } from './tower/TowerNetworkManager';
import { TowerRegistry } from './tower/TowerRegistry';
import { GameTimerManager } from './tower/GameTimerManager';
import { SynergyGuard } from './tower/SynergyGuard';
import { DamagePipeline } from './tower/DamagePipeline';

export class TeslaSystem {
    private static pulseTimer: number = 0;

    public static init(towers: Tower[]) {
        TowerEventSystem.on('onTowerPlaced', (data) => this.handleTowerPlaced(data.sourceTower));
        TowerEventSystem.on('onTowerRemoved', (data) => this.handleTowerRemoved(data.sourceTower));
        
        DamagePipeline.registerModifier((data) => this.applyFrostModifier(data));
        
        SynergyManager.register('Tesla', 'Archer', 'onHitEnemy', (data) => {
            if (data.towerType === 'Archer' && data.targetEnemy) {
                SynergyGuard.execute(() => {
                    this.onArcherHit(data.sourceTower, data.targetEnemy!, data.damage || 0, (window as any).gameInstance?.enemies || []);
                });
            }
        });

        SynergyManager.register('Tesla', 'Bomber', 'onExplosion', (data) => {
            if (data.towerType === 'Bomber' && data.position && data.enemies) {
                SynergyGuard.execute(() => {
                    this.onBombExplode(data.sourceTower, data.position!, data.enemies!);
                });
            }
        });
        
        GameTimerManager.registerTimer('tesla_pulse_fast', 2.5, () => this.triggerGridPulse(true), true);
        GameTimerManager.registerTimer('tesla_pulse_base', 5.0, () => this.triggerGridPulse(false), true);
        GameTimerManager.registerTimer('tesla_storm_nexus', 4.0, () => this.triggerStormNexus(), true);
        
        for (const tower of towers) {
            if (tower) {
                TowerRegistry.addTower(tower);
            }
        }
        
        TowerNetworkManager.detectNetworks();
    }

    private static handleTowerPlaced(tower: Tower) {
        TowerNetworkManager.detectNetworks();
    }

    private static handleTowerRemoved(tower: Tower) {
        TowerNetworkManager.detectNetworks();
    }

    public static onTowerPlaced(tower: Tower, allTowers: Tower[]) {
        // Handled by EventSystem now, but kept for backward compatibility if called directly
    }

    public static onTowerRemoved(tower: Tower, allTowers: Tower[]) {
        // Handled by EventSystem now
    }

    public static onTeslaUpgraded(tesla: Tower, allTowers: Tower[]) {
        TowerNetworkManager.detectNetworks();
    }

    private static updateAllLinks() {
        // Obsolete
    }

    public static getElectricFieldRadius(tesla: Tower, upgradeManager?: UpgradeManager): number {
        let radius = 150;
        if (upgradeManager) {
            // New upgrades give 'range' stat, which is a flat value for field extension or percentage for planetary grid.
            // Wait, planetary grid gives +50% range.
            const flatRange = upgradeManager.getRawClassStat('Tesla', 'range');
            // But wait, planetary grid value is 0.50. So if value < 1, it's a multiplier?
            // Let's just calculate it.
            let flat = 0;
            let mult = 1.0;
            for (const def of upgradeManager.definitions) {
                if (def.classType === 'Tesla' && def.stat === 'range') {
                    const stack = upgradeManager.stacks[def.id] || 0;
                    if (def.value >= 1) flat += stack * def.value;
                    else mult += stack * def.value;
                }
            }
            radius = (radius + flat) * mult;
        }
        if (tesla.isLegendary) {
            const leg = tesla as any;
            if (leg.legendaryType === 'Tesla' && leg.legendaryEffect === 'Quantum Conductor') {
                radius += 40;
            }
        }
        if (tesla.isCorrupted) {
            const leg = tesla as any;
            if (leg.corruptionType === 0) { // Overloaded Core
                radius *= 0.85; // -15% range
            }
        }
        // Save to tower for visualizer
        (tesla as any).electricFieldRadius = radius;
        return radius;
    }

    public static getMaxLinks(tesla: Tower, upgradeManager?: UpgradeManager): number {
        let links = 3;
        if (upgradeManager) {
            links += upgradeManager.getRawClassStat('Tesla', 'max_links');
        }
        if (tesla.isLegendary) {
            const leg = tesla as any;
            if (leg.legendaryType === 'Tesla' && leg.legendaryEffect === 'Grid Master') {
                links += 2;
            }
        }
        return Math.min(links, 9);
    }

    public static getBuffStrength(tesla: Tower, upgradeManager?: UpgradeManager, inGrid: boolean = false, gridType: string = ''): number {
        let strength = 1.0;
        if (upgradeManager) {
            strength += upgradeManager.getRawClassStat('Tesla', 'buff_strength');
        }
        if (tesla.isLegendary) {
            const leg = tesla as any;
            if (leg.legendaryType === 'Tesla' && leg.legendaryEffect === 'Quantum Conductor') {
                strength += 0.40;
            }
        }
        if (tesla.isCorrupted) {
            const leg = tesla as any;
            if (leg.corruptionType === 2) { // Wild Current
                strength -= 0.10;
            }
        }
        if (inGrid) {
            strength += 0.20;
            if (gridType === 'Heavenly') strength += 0.50;
            if (gridType === 'Hybrid') strength += 0.30;
            if (gridType === 'Chaos') strength -= 0.20;
        }
        return Math.max(0, strength);
    }



    private static triggerGridPulse(onlyFastGrids: boolean = false) {
        const enemies = (window as any).gameInstance?.enemies || [];
        const upgradeManager = (window as any).gameInstance?.upgradeManager;
        const networks = TowerNetworkManager.getNetworks();

        for (const groupSet of networks) {
            const group = Array.from(groupSet);
            let corruptedCount = 0;
            let legendaryCount = 0;
            for (const t of group) {
                if (t.isCorrupted) corruptedCount++;
                if (t.isLegendary) legendaryCount++;
            }

            let gridType = 'Normal';
            if (corruptedCount >= 5) gridType = 'Chaos';
            else if (legendaryCount >= 5) gridType = 'Heavenly';
            else if (corruptedCount >= 3 && legendaryCount >= 2) gridType = 'Hybrid';

            if (onlyFastGrids && gridType !== 'Chaos' && gridType !== 'Heavenly') {
                continue; // Only Chaos and Heavenly pulse faster
            }

            let targets = 6;
            let damage = 40;
            let chains = 2;
            let chainDamage = 0.5;

            if (gridType === 'Heavenly') {
                damage = 70;
            } else if (gridType === 'Hybrid') {
                targets = 8;
                damage = 60;
                chains += 2;
            } else if (gridType === 'Chaos') {
                chains += 2;
            }

            this.strikeEnemies(enemies, targets, damage, chains, chainDamage, group[0]);
        }
    }

    private static triggerStormNexus() {
        const enemies = (window as any).gameInstance?.enemies || [];
        const teslas = TowerRegistry.getTowersByType('Tesla');
        for (const tesla of teslas) {
            if (tesla.isLegendary) {
                const leg = tesla as any;
                if (leg.legendaryType === 'Tesla' && leg.legendaryEffect === 'Storm Nexus') {
                    this.strikeEnemies(enemies, 3, 35, 0, 0, tesla);
                }
            }
        }
    }

    private static strikeEnemies(enemies: Enemy[], count: number, damage: number, chains: number, chainDamage: number, source: Tower) {
        const activeEnemies = enemies.filter(e => e.active);
        if (activeEnemies.length === 0) return;

        // Shuffle and pick
        const shuffled = [...activeEnemies].sort(() => 0.5 - Math.random());
        const targets = shuffled.slice(0, count);

        for (const target of targets) {
            this.applyLightningStrike(target, damage, chains, chainDamage, enemies, source);
        }
    }

    public static applyLightningStrike(target: Enemy, damage: number, chains: number, chainDamageMultiplier: number, allEnemies: Enemy[], source: Tower) {
        if (!target || !target.active) return;
        
        target.lastHitBy = source;
        applyDamage(target, { amount: damage, type: 'magic', sourceTower: source, crit: false });
        
        // Draw lightning effect
        if ((window as any).gameInstance) {
            (window as any).gameInstance.lightningEffects = (window as any).gameInstance.lightningEffects || [];
            (window as any).gameInstance.lightningEffects.push({
                start: source.position.clone(),
                end: target.position.clone(),
                timer: 0.2
            });
        }

        let currentTarget = target;
        let currentDamage = damage * chainDamageMultiplier;
        const hitEnemies = new Set<Enemy>([target]);

        for (let i = 0; i < chains; i++) {
            let nextTarget: Enemy | null = null;
            let minDist = Infinity;

            for (const e of allEnemies) {
                if (e.active && !hitEnemies.has(e)) {
                    const dist = currentTarget.position.dist(e.position);
                    if (dist < 120 && dist < minDist) {
                        minDist = dist;
                        nextTarget = e;
                    }
                }
            }

            if (nextTarget) {
                nextTarget.lastHitBy = source;
                applyDamage(nextTarget, { amount: currentDamage, type: 'magic', sourceTower: source, crit: false });
                
                if ((window as any).gameInstance) {
                    (window as any).gameInstance.lightningEffects.push({
                        start: currentTarget.position.clone(),
                        end: nextTarget.position.clone(),
                        timer: 0.2
                    });
                }

                hitEnemies.add(nextTarget);
                currentTarget = nextTarget;
                currentDamage *= chainDamageMultiplier;
            } else {
                break;
            }
        }
    }

    private static applyFrostModifier(data: any) {
        if (data.sourceTower && data.sourceTower.constructor.name === 'Frost') {
            const mult = this.getFrostDamageMultiplier(data.sourceTower, data.targetEnemy);
            data.finalDamage *= mult;
        }
    }

    // Hook for Archer
    public static onArcherHit(archer: Tower, target: Enemy, arrowDamage: number, allEnemies: Enemy[]) {
        if (!archer.teslaLinks || archer.teslaLinks.length === 0) return;
        
        let totalStrength = 0;
        for (let tesla of archer.teslaLinks) {
            totalStrength += this.getBuffStrength(tesla, (window as any).gameInstance?.upgradeManager, this.isTeslaInGrid(tesla), this.getGridType(tesla));
        }
        
        // Find nearby enemy within 90 range
        let nextTarget: Enemy | null = null;
        let minDist = Infinity;
        for (const e of allEnemies) {
            if (e.active && e !== target) {
                const dist = target.position.dist(e.position);
                if (dist <= 90 && dist < minDist) {
                    minDist = dist;
                    nextTarget = e;
                }
            }
        }

        if (nextTarget) {
            const chainDamage = arrowDamage * 0.40 * totalStrength;
            nextTarget.lastHitBy = archer.teslaLinks[0];
            applyDamage(nextTarget, { amount: chainDamage, type: 'magic', sourceTower: archer.teslaLinks[0], crit: false });
            
            if ((window as any).gameInstance) {
                (window as any).gameInstance.lightningEffects = (window as any).gameInstance.lightningEffects || [];
                (window as any).gameInstance.lightningEffects.push({
                    start: target.position.clone(),
                    end: nextTarget.position.clone(),
                    timer: 0.2
                });
            }
        }
    }

    // Hook for Bomber
    public static onBombExplode(bomber: Tower, bombPos: Vector2, allEnemies: Enemy[]) {
        if (!bomber.teslaLinks || bomber.teslaLinks.length === 0) return;
        
        let totalStrength = 0;
        for (let tesla of bomber.teslaLinks) {
            totalStrength += this.getBuffStrength(tesla, (window as any).gameInstance?.upgradeManager, this.isTeslaInGrid(tesla), this.getGridType(tesla));
        }
        
        for (const e of allEnemies) {
            if (e.active) {
                const dist = e.position.dist(bombPos);
                if (dist <= 80) { // explosion radius roughly
                    // Pull towards center
                    const pullForce = 30 * totalStrength;
                    const dir = bombPos.sub(e.position).normalize();
                    e.position = e.position.add(dir.mult(pullForce));
                }
            }
        }
    }

    // Hook for Frost
    public static getFrostDamageMultiplier(frost: Tower, target: Enemy): number {
        if (!target.effects.some(e => e.type === 'slow')) return 1.0;
        if (!frost.teslaLinks || frost.teslaLinks.length === 0) return 1.0;
        
        let totalStrength = 0;
        for (let tesla of frost.teslaLinks) {
            totalStrength += this.getBuffStrength(tesla, (window as any).gameInstance?.upgradeManager, this.isTeslaInGrid(tesla), this.getGridType(tesla));
        }
        return 1.0 + (0.15 * totalStrength);
    }

    // Hook for Tesla + Tesla
    public static getTeslaSelfBuffs(tesla: Tower): { shockChance: number, chainRange: number, attackSpeed: number } {
        let count = tesla.teslaLinks ? tesla.teslaLinks.length : 0;
        count = Math.min(count, 4);
        
        const strength = this.getBuffStrength(tesla, (window as any).gameInstance?.upgradeManager, this.isTeslaInGrid(tesla), this.getGridType(tesla));
        
        return {
            shockChance: 0.04 * count * strength,
            chainRange: 10 * count * strength,
            attackSpeed: 0.05 * count * strength
        };
    }

    public static isTeslaInGrid(tesla: Tower): boolean {
        const networks = TowerNetworkManager.getNetworks();
        for (const group of networks) {
            if (group.has(tesla)) return true;
        }
        return false;
    }

    public static getGridType(tesla: Tower): string {
        const networks = TowerNetworkManager.getNetworks();
        for (const group of networks) {
            if (group.has(tesla)) {
                let corruptedCount = 0;
                let legendaryCount = 0;
                for (const t of group) {
                    if (t.isCorrupted) corruptedCount++;
                    if (t.isLegendary) legendaryCount++;
                }
                if (corruptedCount >= 5) return 'Chaos';
                if (legendaryCount >= 5) return 'Heavenly';
                if (corruptedCount >= 3 && legendaryCount >= 2) return 'Hybrid';
                return 'Normal';
            }
        }
        return '';
    }
}
