export function initMetaState(player: any) {
  if (!player) return;

  if (!player.meta) {
    player.meta = {};
  }

  if (typeof player.meta.corruptedShards !== "number") {
    player.meta.corruptedShards = 0;
  }

  if (!player.meta.upgrades) {
    player.meta.upgrades = {};
  }
}
