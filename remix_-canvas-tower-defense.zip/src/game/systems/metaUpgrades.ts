export const META_UPGRADES: Record<string, { base: number, perLevel: number, cap: number }> = {
  shard_gain: {
    base: 0,
    perLevel: 0.05,
    cap: 0.5
  },

  hp_boost: {
    base: 0,
    perLevel: 10,
    cap: 200
  },

  reroll_discount: {
    base: 0,
    perLevel: 2,
    cap: 30
  },

  rare_chance: {
    base: 0,
    perLevel: 0.01,
    cap: 0.2
  }
};

export function getUpgradeValue(player: any, key: string) {
  if (!player || !player.meta || !player.meta.upgrades) {
    return 0;
  }

  const def = META_UPGRADES[key];
  if (!def) return 0;

  const level = player.meta.upgrades[key] || 0;

  let value = def.base + def.perLevel * level;

  if (typeof def.cap === "number") {
    value = Math.min(value, def.cap);
  }

  return value;
}
