import { loadGame, saveGame } from "./saveSystem";
import { migrateSave } from "./saveMigration";
import { applySaveToPlayer } from "./saveApply";

export function initSaveSystem(player: any) {
  if (!player) return;

  try {
    const save = loadGame();

    if (!save) return;

    const migrated = migrateSave(save);

    if (migrated) {
      applySaveToPlayer(player, migrated);
    }
  } catch (e) {
    console.warn("[InitSave] error", e);
  }
}

export function autoSave(player: any) {
  try {
    saveGame(player);
  } catch (e) {}
}
