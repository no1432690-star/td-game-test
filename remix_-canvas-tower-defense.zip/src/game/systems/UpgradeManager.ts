import { RunUpgrade } from './RunSystem';
import { Rarity, RARITY_WEIGHT } from '../constants/rarity';

export const ENABLE_TESLA_UPGRADES = true;

export interface UpgradeDefinition {
    id: string;
    name: string;
    description: string;
    category: "Global" | "Class";
    classType?: "Archer" | "Frost" | "Bomber" | "Tesla";
    maxStack?: number;
    rarity: Rarity;
    stat: string;
    value: number;
    tags?: string[];
    excludeTags?: string[];
    requireTags?: string[];
}

export class UpgradeManager {
    public definitions: UpgradeDefinition[] = [
        // ARCHER
        {
            id: "archer_crit_chance",
            name: "Archer Crit Chance",
            description: "+5% crit chance per stack",
            category: "Class",
            classType: "Archer",
            maxStack: 6,
            rarity: "Common",
            stat: "crit_chance",
            value: 0.05,
            tags: ["archer", "crit"]
        },
        {
            id: "archer_crit_damage",
            name: "Archer Crit Damage",
            description: "+20% crit damage per stack",
            category: "Class",
            classType: "Archer",
            maxStack: 6,
            rarity: "Common",
            stat: "crit_damage",
            value: 0.20,
            tags: ["archer", "crit", "damage"]
        },
        {
            id: "archer_attack_speed",
            name: "Archer Attack Speed",
            description: "+8% attack speed per stack",
            category: "Class",
            classType: "Archer",
            maxStack: 6,
            rarity: "Common",
            stat: "attack_speed",
            value: 0.08,
            tags: ["archer", "speed"]
        },
        // FROST
        {
            id: "frost_slow_power",
            name: "Frost Slow Power",
            description: "+8% slow per stack",
            category: "Class",
            classType: "Frost",
            maxStack: 6,
            rarity: "Common",
            stat: "slow_power",
            value: 0.08,
            tags: ["frost", "slow", "control"]
        },
        {
            id: "frost_slow_duration",
            name: "Frost Slow Duration",
            description: "+1 second per stack",
            category: "Class",
            classType: "Frost",
            maxStack: 6,
            rarity: "Common",
            stat: "slow_duration",
            value: 1.0,
            tags: ["frost", "slow", "control"]
        },
        {
            id: "frost_bonus_vs_slowed",
            name: "Frost Bonus vs Slowed",
            description: "+10% damage vs slowed per stack",
            category: "Class",
            classType: "Frost",
            maxStack: 6,
            rarity: "Common",
            stat: "bonus_vs_slowed",
            value: 0.10,
            tags: ["frost", "damage", "synergy"]
        },
        // BOMBER
        {
            id: "bomber_splash_damage",
            name: "Bomber Splash Damage",
            description: "+15% splash per stack",
            category: "Class",
            classType: "Bomber",
            maxStack: 6,
            rarity: "Common",
            stat: "splash_damage",
            value: 0.15,
            tags: ["bomber", "aoe", "damage"]
        },
        {
            id: "bomber_radius",
            name: "Bomber Radius",
            description: "+15% radius per stack",
            category: "Class",
            classType: "Bomber",
            maxStack: 6,
            rarity: "Common",
            stat: "radius",
            value: 0.15,
            tags: ["bomber", "aoe", "range"]
        },
        {
            id: "bomber_bonus_damage",
            name: "Bomber Bonus Damage",
            description: "+10% damage per stack",
            category: "Class",
            classType: "Bomber",
            maxStack: 6,
            rarity: "Common",
            stat: "bonus_damage",
            value: 0.10,
            tags: ["bomber", "damage"]
        },
        // TESLA COMMON
        { id: "tesla_capacitive_link", name: "Capacitive Link", description: "+5% Tesla buff", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "buff_strength", value: 0.05, tags: ["tesla", "buff"] },
        { id: "tesla_field_extension", name: "Field Extension", description: "+10 electric field radius", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "range", value: 10, tags: ["tesla", "range"] },
        { id: "tesla_conductive_relay", name: "Conductive Relay", description: "+5% attack speed", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "attack_speed", value: 0.05, tags: ["tesla", "speed"] },
        { id: "tesla_static_charge", name: "Static Charge", description: "+5% shock chance", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "shock_chance", value: 0.05, tags: ["tesla", "shock"] },
        { id: "tesla_grounded_circuit", name: "Grounded Circuit", description: "+5% damage", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "damage", value: 0.05, tags: ["tesla", "damage"] },
        { id: "tesla_micro_grid", name: "Micro Grid", description: "+1 max link", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Common", stat: "max_links", value: 1, tags: ["tesla", "chain"] },
        // TESLA UNCOMMON
        { id: "tesla_power_conduit", name: "Power Conduit", description: "+10% damage", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Quality", stat: "damage", value: 0.10, tags: ["tesla", "damage"] },
        { id: "tesla_resonant_circuit", name: "Resonant Circuit", description: "+10% attack speed", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Quality", stat: "attack_speed", value: 0.10, tags: ["tesla", "speed"] },
        { id: "tesla_energy_overflow", name: "Energy Overflow", description: "+10% shock chance", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Quality", stat: "shock_chance", value: 0.10, tags: ["tesla", "shock"] },
        { id: "tesla_conductive_field", name: "Conductive Field", description: "+15 electric field radius", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Quality", stat: "range", value: 15, tags: ["tesla", "range"] },
        { id: "tesla_chain_conductor", name: "Chain Conductor", description: "+1 chain target", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Quality", stat: "chain_targets", value: 1, tags: ["tesla", "chain"] },
        // TESLA RARE
        { id: "tesla_lightning_resonance", name: "Lightning Resonance", description: "Each Tesla link grants +5% damage", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Rare", stat: "lightning_resonance", value: 1, tags: ["tesla", "damage", "chain"] },
        { id: "tesla_supercharged_network", name: "Supercharged Network", description: "+15% Tesla buff", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Rare", stat: "buff_strength", value: 0.15, tags: ["tesla", "buff"] },
        { id: "tesla_energy_loop", name: "Energy Loop", description: "+15% attack speed", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Rare", stat: "attack_speed", value: 0.15, tags: ["tesla", "speed"] },
        // TESLA EPIC
        { id: "tesla_grid_amplifier", name: "Grid Amplifier", description: "+20% damage", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Rare", stat: "damage", value: 0.20, tags: ["tesla", "damage"] },
        { id: "tesla_quantum_conductor", name: "Quantum Conductor", description: "+2 chain targets", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Rare", stat: "chain_targets", value: 2, tags: ["tesla", "chain"] },
        // TESLA LEGENDARY
        { id: "tesla_planetary_grid", name: "Planetary Grid", description: "+50% range", category: "Class", classType: "Tesla", maxStack: 6, rarity: "Rare", stat: "range", value: 0.50, tags: ["tesla", "range"] },
        // TESLA RUN UPGRADES
        { id: "tesla_amp_current", name: "⚡ Amplified Current", description: "+15% Tesla buff strength", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Rare", stat: "tesla_buff_global", value: 0.15, tags: ["tesla", "run"] },
        { id: "tesla_chain_expansion", name: "⚡ Chain Expansion", description: "+1 max Tesla links per tower", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Rare", stat: "tesla_max_links", value: 1, tags: ["tesla", "chain", "run"] },
        { id: "tesla_energy_surge", name: "⚡ Energy Surge", description: "+25 Tesla starting energy", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Rare", stat: "tesla_energy_bonus", value: 25, tags: ["tesla", "run"] },
        { id: "tesla_resonant_grid", name: "⚡ Resonant Grid", description: "+20% topology bonus", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Gold", stat: "tesla_topology_bonus", value: 0.20, tags: ["tesla", "run", "mechanic"] },
        { id: "tesla_focused_conduction", name: "⚡ Focused Conduction", description: "FOCUSED mode stronger (+30%)", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Legendary", stat: "tesla_focused_bonus", value: 0.30, tags: ["tesla", "run", "mechanic"] },
        
        // TESLA SYNERGY UPGRADES
        { id: "tesla_overload_core", name: "⚡ Overload Core", description: "Towers gain +10% damage when energy is full", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Rare", stat: "tesla_overload_damage", value: 0.10, tags: ["tesla", "overload", "run"], requireTags: ["tesla"] },
        { id: "tesla_chain_mastery", name: "⚡ Chain Mastery", description: "Chain attacks deal +20% damage", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Gold", stat: "tesla_chain_damage", value: 0.20, tags: ["tesla", "chain"], requireTags: ["chain"] },
        { id: "tesla_chain_overload", name: "⚡ Chain Overload", description: "Chain attacks have a 10% chance to overload", category: "Class", classType: "Tesla", maxStack: 1, rarity: "Legendary", stat: "tesla_chain_overload", value: 0.10, tags: ["tesla", "chain", "overload"], requireTags: ["chain", "overload"] },
        
        // GLOBAL UPGRADES
        { id: "global_damage_small", name: "Sharpened Weapons", description: "+10% Damage", category: "Global", rarity: "Common", stat: "damage", value: 0.10 },
        { id: "global_damage_medium", name: "Sharpened Weapons", description: "+15% Damage", category: "Global", rarity: "Uncommon", stat: "damage", value: 0.15 },
        { id: "global_damage_large", name: "Sharpened Weapons", description: "+20% Damage", category: "Global", rarity: "Rare", stat: "damage", value: 0.20 },
        { id: "global_damage_huge", name: "Sharpened Weapons", description: "+30% Damage", category: "Global", rarity: "Quality", stat: "damage", value: 0.30 },

        { id: "global_speed_small", name: "Haste", description: "+10% Attack Speed", category: "Global", rarity: "Common", stat: "speed", value: 0.10 },
        { id: "global_speed_medium", name: "Haste", description: "+15% Attack Speed", category: "Global", rarity: "Uncommon", stat: "speed", value: 0.15 },
        { id: "global_speed_large", name: "Haste", description: "+20% Attack Speed", category: "Global", rarity: "Rare", stat: "speed", value: 0.20 },
        { id: "global_speed_huge", name: "Haste", description: "+30% Attack Speed", category: "Global", rarity: "Quality", stat: "speed", value: 0.30 },

        { id: "global_gold_small", name: "Bounty", description: "+10% Gold Gain", category: "Global", rarity: "Common", stat: "gold", value: 0.10 },
        { id: "global_gold_medium", name: "Bounty", description: "+15% Gold Gain", category: "Global", rarity: "Uncommon", stat: "gold", value: 0.15 },
        { id: "global_gold_large", name: "Bounty", description: "+20% Gold Gain", category: "Global", rarity: "Rare", stat: "gold", value: 0.20 },
        { id: "global_gold_huge", name: "Bounty", description: "+30% Gold Gain", category: "Global", rarity: "Quality", stat: "gold", value: 0.30 },

        { id: "global_range_small", name: "Eagle Eye", description: "+10% Range", category: "Global", rarity: "Common", stat: "range", value: 0.10 },
        { id: "global_range_medium", name: "Eagle Eye", description: "+15% Range", category: "Global", rarity: "Uncommon", stat: "range", value: 0.15 },
        { id: "global_range_large", name: "Eagle Eye", description: "+20% Range", category: "Global", rarity: "Rare", stat: "range", value: 0.20 },
        { id: "global_range_huge", name: "Eagle Eye", description: "+30% Range", category: "Global", rarity: "Quality", stat: "range", value: 0.30 },

        // CROSS SYNERGY UPGRADES
        { 
            id: "synergy_archer_frost", 
            name: "❄️ Frostbite Arrows", 
            description: "Archers deal +50% damage to frozen enemies", 
            category: "Global", 
            rarity: "Gold", 
            stat: "cross_archer_frost", 
            value: 1, 
            tags: ["synergy", "archer", "frost"], 
            requireTags: ["archer", "frost"] 
        },
        { 
            id: "synergy_bomber_frost", 
            name: "❄️ Shatter Bombs", 
            description: "Bombs instantly shatter slowed enemies (<20% HP)", 
            category: "Global", 
            rarity: "Gold", 
            stat: "cross_bomber_frost", 
            value: 1, 
            tags: ["synergy", "bomber", "frost"], 
            requireTags: ["bomber", "frost"] 
        },
        { 
            id: "synergy_archer_bomber", 
            name: "🔥 Explosive Tips", 
            description: "Archer crits mark enemies. Bombs deal +50% damage to marked enemies.", 
            category: "Global", 
            rarity: "Gold", 
            stat: "cross_archer_bomber", 
            value: 1, 
            tags: ["synergy", "archer", "bomber", "crit"], 
            requireTags: ["archer", "bomber"] 
        }
    ];

    public stacks: Record<string, number> = {};
    public activeClasses: Set<string> = new Set();
    public activeTags: Set<string> = new Set();

    public registerBuiltTower(classType: string): void {
        this.activeClasses.add(classType);
    }

    private getUpgradeWeight(def: UpgradeDefinition): number {
        let weight = RARITY_WEIGHT[def.rarity] || 1;

        // ⚡ Tesla run upgrade nerf nhẹ để không spam
        if (def.tags?.includes("run")) {
            weight *= 0.4;
        }

        // 🔥 SYNERGY BOOST
        if (def.tags) {
            const synergyHits = def.tags.filter(tag => this.activeTags.has(tag)).length;
            if (synergyHits > 0) {
                weight *= 1 + synergyHits * 0.5;
            }
        }

        return weight;
    }

    private weightedRandom<T>(items: T[], getWeight: (item: T) => number): T {
        const totalWeight = items.reduce((sum, item) => sum + getWeight(item), 0);
        let roll = Math.random() * totalWeight;

        for (const item of items) {
            roll -= getWeight(item);
            if (roll <= 0) {
                return item;
            }
        }

        return items[items.length - 1];
    }

    private filterByTags(pool: UpgradeDefinition[]): UpgradeDefinition[] {
        return pool.filter(def => {
            // requireTags
            if (def.requireTags) {
                const ok = def.requireTags.some(tag => this.activeTags.has(tag));
                if (!ok) return false;
            }

            // excludeTags
            if (def.excludeTags) {
                const blocked = def.excludeTags.some(tag => this.activeTags.has(tag));
                if (blocked) return false;
            }

            return true;
        });
    }

    public rollUpgrades(count: number, wave: number): RunUpgrade[] {
        const options: RunUpgrade[] = [];
        const usedIds = new Set<string>();
        let hasRunUpgrade = false;

        for (let i = 0; i < count; i++) {
            let isGlobal = Math.random() < 0.6;
            if (this.activeClasses.size === 0) {
                isGlobal = true;
            }

            let pool: UpgradeDefinition[];

            if (isGlobal) {
                pool = this.definitions.filter(u => u.category === "Global" && !usedIds.has(u.id));
            } else {
                pool = this.definitions.filter(u => {
                    if (u.category !== "Class") return false;
                    if (!u.classType || !this.activeClasses.has(u.classType)) return false;
                    if (usedIds.has(u.id)) return false;
                    if (!ENABLE_TESLA_UPGRADES && u.id.startsWith("tesla_") && u.name.startsWith("⚡")) return false;
                    const currentStack = this.stacks[u.id] || 0;
                    if (u.maxStack && currentStack >= u.maxStack) return false;
                    return true;
                });
            }

            // Apply tag filters
            pool = this.filterByTags(pool);

            // Fallback if pool is empty
            if (pool.length === 0) {
                pool = this.definitions.filter(u => u.category === "Global" && !usedIds.has(u.id));
                pool = this.filterByTags(pool);
            }

            if (pool.length > 0) {
                const selected = this.weightedRandom(pool, this.getUpgradeWeight.bind(this));
                usedIds.add(selected.id);
                
                if (selected.tags?.includes("run")) {
                    hasRunUpgrade = true;
                }

                options.push({
                    id: selected.id,
                    name: selected.name,
                    description: `${selected.description} (${selected.rarity})`,
                    type: selected.stat as any,
                    value: selected.value,
                    rarity: selected.rarity as any,
                    tags: selected.tags
                });
            }
        }

        // Guarantee a run upgrade if none was selected and we have teslas
        if (!hasRunUpgrade && this.activeClasses.has("Tesla") && ENABLE_TESLA_UPGRADES) {
            let runPool = this.definitions.filter(u => {
                if (!u.tags?.includes("run")) return false;
                if (usedIds.has(u.id)) return false;
                const currentStack = this.stacks[u.id] || 0;
                if (u.maxStack && currentStack >= u.maxStack) return false;
                return true;
            });
            
            runPool = this.filterByTags(runPool);

            if (runPool.length > 0 && options.length > 0) {
                const selected = this.weightedRandom(runPool, this.getUpgradeWeight.bind(this));
                
                options[0] = {
                    id: selected.id,
                    name: selected.name,
                    description: `${selected.description} (${selected.rarity})`,
                    type: selected.stat as any,
                    value: selected.value,
                    rarity: selected.rarity as any,
                    tags: selected.tags
                };
            }
        }

        return options;
    }

    public applyUpgrade(id: string): void {
        this.stacks[id] = (this.stacks[id] || 0) + 1;
        
        const def = this.definitions.find(d => d.id === id);
        if (def && def.tags) {
            def.tags.forEach(tag => this.activeTags.add(tag));
        }
    }

    public getGlobalMultiplier(stat: string): number {
        // Global multipliers are handled by RunSystem for backward compatibility
        return 1.0;
    }

    public getClassMultiplier(classType: string, stat: string): number {
        let multiplier = 1.0;
        for (const def of this.definitions) {
            if (def.classType === classType && def.stat === stat) {
                const stack = this.stacks[def.id] || 0;
                multiplier += stack * def.value;
            }
        }
        return multiplier;
    }

    public getRawClassStat(classType: string, stat: string): number {
        let total = 0;
        for (const def of this.definitions) {
            if (def.classType === classType && def.stat === stat) {
                const stack = this.stacks[def.id] || 0;
                total += stack * def.value;
            }
        }
        return total;
    }

    public resetRun(): void {
        this.stacks = {};
        this.activeClasses.clear();
        this.activeTags.clear();
    }
}
