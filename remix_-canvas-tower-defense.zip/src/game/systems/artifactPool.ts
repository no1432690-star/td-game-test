export const ARTIFACT_POOL = [
  { id: "time_echo", rarity: "common" },
  { id: "time_fracture", rarity: "rare" },
  { id: "temporal_surge", rarity: "epic" }
];
