import { computeAllArtifacts } from './artifactEngine';
import { ARTIFACT_DEFS } from './artifactDefinitions';

export function updateArtifactEffects(state: any) {
  if (!state) return;
  if (!state.artifacts) return;

  state.artifactEffects = computeAllArtifacts(
    state,
    ARTIFACT_DEFS,
    {
      wave: state.waveManager?.wave || state.wave || 0,
      gold: state.gold || 0
    }
  );
}

export function applyArtifactDamage(baseDamage: number, state: any) {
  if (!state?.artifactEffects) return baseDamage;

  const fx = state.artifactEffects;
  let damage = baseDamage;

  if (fx.endless_pressure) {
    damage *= 1 + fx.endless_pressure;
  }
  if (fx.compound_growth) {
    damage *= 1 + fx.compound_growth;
  }
  if (fx.overflow_vault) {
    damage *= 1 + fx.overflow_vault;
  }
  if (fx.blood_investment?.damagePenalty) {
    damage *= 1 - fx.blood_investment.damagePenalty;
  }

  return damage;
}

export function applyArtifactGold(baseGold: number, state: any) {
  if (!state?.artifactEffects) return baseGold;

  const fx = state.artifactEffects;
  let gold = baseGold;

  if (fx.golden_momentum) {
    gold *= 1 + fx.golden_momentum;
  }
  if (fx.blood_investment?.goldBonus) {
    gold *= 1 + fx.blood_investment.goldBonus;
  }

  return gold;
}

export function applyArtifactOnHit(enemy: any, state: any) {
  if (!enemy || !state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (fx.static_field) {
    enemy.slow = (enemy.slow || 0) + fx.static_field;
    enemy.damageTakenBonus = (enemy.damageTakenBonus || 0) + fx.static_field;
  }
}

export function applyArtifactOnKill(enemy: any, state: any, explode: (pos: any, dmg: number) => void) {
  if (!enemy || !state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (fx.chain_reaction) {
    if (Math.random() < fx.chain_reaction) {
      if (typeof explode === "function") {
        explode(enemy.position, enemy.maxHp * 0.2);
      }
    }
  }
}

export function applyArtifactOverkill(enemy: any, damage: number, state: any, splashNearby: (enemy: any, dmg: number) => void) {
  if (!enemy || !state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (!fx.overkill_conversion) return;

  const overkill = damage - enemy.hp;

  if (overkill > 0) {
    if (typeof splashNearby === "function") {
      splashNearby(enemy, overkill * fx.overkill_conversion);
    }
  }
}

export function applyArtifactCritCascade(target: any, damage: number, state: any, findNearbyEnemy: (t: any) => any, dealDamage: (t: any, d: number) => void) {
  if (!state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (!fx.critical_cascade) return;

  if (Math.random() < fx.critical_cascade) {
    if (typeof findNearbyEnemy === "function") {
      const next = findNearbyEnemy(target);
      if (next && typeof dealDamage === "function") {
        dealDamage(next, damage * 0.7);
      }
    }
  }
}

export function getArtifactBonusOptions(state: any) {
  if (!state?.artifactEffects) return 0;
  return Math.floor(state.artifactEffects.merchants_insight || 0);
}

export function shouldFreeReroll(state: any) {
  if (!state?.artifactEffects) return false;

  const chance = state.artifactEffects.second_chance;
  if (!chance) return false;

  return Math.random() < chance;
}

export function applyArtifactEcho(target: any, damage: number, state: any, dealDamage: (t: any, d: number) => void) {
  if (!state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (!fx.time_echo) return;

  if (Math.random() < fx.time_echo) {
    if (typeof dealDamage === "function") {
      dealDamage(target, damage * 0.5);
    }
  }
}

export function registerArtifactHit(state: any) {
  if (!state) return false;

  state._artifactHitCount = (state._artifactHitCount || 0) + 1;

  const fx = state.artifactEffects;

  if (!fx?.time_fracture) return false;

  if (state._artifactHitCount >= fx.time_fracture) {
    state._artifactHitCount = 0;
    return true;
  }

  return false;
}

export function checkArtifactTemporalSurge(state: any, applyGlobalBuff: (buff: any) => void) {
  if (!state?.artifactEffects) return;

  const fx = state.artifactEffects;

  if (!fx.temporal_surge) return;

  if ((state.waveManager?.wave || state.wave || 0) % 5 === 0) {
    if (typeof applyGlobalBuff === "function") {
      applyGlobalBuff({
        attackSpeed: 1 + fx.temporal_surge.bonusAS,
        duration: fx.temporal_surge.duration
      });
    }
  }
}
