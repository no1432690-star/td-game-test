import { UpgradeManager } from './UpgradeManager';

export interface RunUpgrade {
  id: string;
  name: string;
  description: string;
  type: 'damage' | 'speed' | 'gold' | 'range' | string;
  value: number;
  rarity?: 'Common' | 'Uncommon' | 'Rare' | 'Quality' | 'Gold' | 'Legendary';
  tags?: string[];
}

export interface RunModifiers {
  damageMultiplier: number;
  speedMultiplier: number;
  goldMultiplier: number;
  rangeMultiplier: number;
  
  // Advanced Synergy
  critChanceBonus?: number;
  critDamageBonus?: number;
  guaranteedCrit?: boolean;
  explosionRadiusBonus?: number;
  applyBurn?: boolean;
  miniExplosionChance?: number;
  doubleExplosionChance?: number;
  slowBonus?: number;
  damageToSlowedBonus?: number;
  freezeChance?: number;
  explodeOnDeath?: boolean;
  
  // Cross Synergy
  crossArcherFrost?: boolean;
  crossBomberFrost?: boolean;
  crossArcherBomber?: boolean;

  // Tesla
  extendedConduit?: number;
  overchargedLinks?: number;
  capacitor?: number;
  staticCharge?: number;
}

import { getArtifactBonusOptions } from './artifactHooks';

export class RunSystem {
  public modifiers: RunModifiers;
  public pendingChoices: RunUpgrade[] | null = null;
  public choiceTimer: number = 0;
  public readonly CHOICE_DURATION: number = 10.0;

  constructor() {
    this.modifiers = this.getDefaultModifiers();
  }

  private getDefaultModifiers(): RunModifiers {
    return {
      damageMultiplier: 1.0,
      speedMultiplier: 1.0,
      goldMultiplier: 1.0,
      rangeMultiplier: 1.0,
    };
  }

  public reset(): void {
    this.modifiers = this.getDefaultModifiers();
    this.pendingChoices = null;
    this.choiceTimer = 0;
  }

  public generateUpgradeChoices(wave: number, upgradeManager: UpgradeManager): void {
    const game = (window as any).gameInstance;
    const bonusOptions = getArtifactBonusOptions(game);
    this.pendingChoices = upgradeManager.rollUpgrades(3 + bonusOptions, wave);
    this.choiceTimer = this.CHOICE_DURATION;
  }

  public applyUpgrade(choiceId: string, upgradeManager: UpgradeManager): void {
    if (!this.pendingChoices) return;
    const choice = this.pendingChoices.find(c => c.id === choiceId);
    if (choice) {
      if (choice.id.startsWith('global_')) {
        if (choice.type === 'damage') this.modifiers.damageMultiplier += choice.value;
        if (choice.type === 'speed') this.modifiers.speedMultiplier += choice.value;
        if (choice.type === 'gold') this.modifiers.goldMultiplier += choice.value;
        if (choice.type === 'range') this.modifiers.rangeMultiplier += choice.value;
      } else {
        upgradeManager.applyUpgrade(choiceId);
      }
    }
    this.pendingChoices = null;
    this.choiceTimer = 0;
  }

  public update(dt: number, upgradeManager: UpgradeManager): boolean {
    if (this.pendingChoices) {
      this.choiceTimer -= dt;
      if (this.choiceTimer <= 0) {
        const randomChoice = this.pendingChoices[Math.floor(Math.random() * this.pendingChoices.length)];
        this.applyUpgrade(randomChoice.id, upgradeManager);
        return true; // Auto-picked
      }
    }
    return false;
  }
}
