export function trackEvent(player: any, type: string, payload: any = {}) {
  if (!player || !player.analytics) return;

  try {
    switch (type) {
      case "run_start":
        player.analytics.runs++;
        break;

      case "death":
        player.analytics.totalDeaths++;
        break;

      case "kill":
        player.analytics.kills++;
        break;

      case "reroll":
        player.analytics.rerolls++;
        break;

      case "artifact_pick":
        const id = payload.id;
        if (!id) break;

        if (!player.analytics.artifactPicks[id]) {
          player.analytics.artifactPicks[id] = 0;
        }

        player.analytics.artifactPicks[id]++;
        break;

      default:
        break;
    }
  } catch (e) {}
}
