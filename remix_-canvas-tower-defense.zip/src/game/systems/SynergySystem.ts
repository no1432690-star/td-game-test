import { Tower } from '../entities/Tower';

export interface SynergyResult {
  perType: Record<string, number>;
  cross: {
    archerFrost: boolean;
    bomberFrost: boolean;
    archerBomber: boolean;
  };
}

export class SynergySystem {
    static calculate(towers: Tower[]) {
        const counts: Record<string, number> = {};

        for (const t of towers) {
            if (!t) continue;
            counts[t.constructor.name] = (counts[t.constructor.name] || 0) + 1;
        }

        return counts;
    }

    static calculateAdvanced(towers: Tower[]): SynergyResult {
        const counts = this.calculate(towers);
        
        let archers = (counts['Archer'] || 0) + (counts['CursedArcher'] || 0);
        let bombers = counts['Bomber'] || 0;
        let frosts = counts['Frost'] || 0;

        for (const t of towers) {
            if (!t) continue;
            if (t.isLegendary) {
                const legTower = t as any;
                if (legTower.legendaryType === 'Archer' || legTower.legendaryType === 'CursedArcher') archers++;
                if (legTower.legendaryType === 'Bomber') bombers++;
                if (legTower.legendaryType === 'Frost') frosts++;
            }
        }

        return {
            perType: counts,
            cross: {
                archerFrost: archers > 0 && frosts > 0,
                bomberFrost: bombers > 0 && frosts > 0,
                archerBomber: archers > 0 && bombers > 0
            }
        };
    }

    static getDamageBonus(type: string, count: number): number {
        if (count >= 5) return 1.4;
        if (count >= 3) return 1.2;
        return 1;
    }
}
