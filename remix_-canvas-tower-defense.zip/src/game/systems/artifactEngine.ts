export type StackType = "linear" | "diminishing" | "log" | "special";

export type ArtifactContext = {
  wave: number;
  gold: number;
  totalArtifacts: number;
};

export type ArtifactDefinition = {
  id: string;
  name: string;
  description?: string;
  basePrice?: number;

  rarity: "Rare" | "Gold" | "Legendary" | "Quality" | "Uncommon" | "Common";

  stackType: StackType;

  baseValue?: number;
  k?: number;
  softCap?: number;
  hardCap?: number;

  compute?: (ctx: ArtifactContext & { stacks: number }) => any;
};

export function getArtifactState(state: any, id: string) {
  if (!state.artifacts) return undefined;
  return state.artifacts.find((a: any) => a.id === id);
}

export function addArtifact(state: any, id: string, amount = 1) {
  if (!state.artifacts) {
    state.artifacts = [];
  }

  let art = getArtifactState(state, id);

  if (!art) {
    art = { id, stacks: 0 };
    state.artifacts.push(art);
  }

  art.stacks += amount;
}

// === [PATCH] Disable starting artifacts ===
const __origInitArtifacts = initArtifacts;
export function initArtifacts(state: any) {
  console.warn("[ArtifactPatch] Blocked starting artifacts");
}

export function computeArtifactValue(def: ArtifactDefinition, stacks: number, ctx: ArtifactContext) {
  if (def.hardCap) {
    stacks = Math.min(stacks, def.hardCap);
  }

  if (def.compute) {
    return def.compute({ ...ctx, stacks });
  }

  const base = def.baseValue ?? 0;
  const k = def.k ?? 0.5;
  const softCap = def.softCap ?? 999;

  let effectiveStacks = stacks;

  if (stacks > softCap) {
    const extra = stacks - softCap;
    effectiveStacks = softCap + extra * 0.25;
  }

  switch (def.stackType) {
    case "linear":
      return base * effectiveStacks;

    case "diminishing":
      return base * (1 / (1 + effectiveStacks * k));

    case "log":
      return base * Math.log(1 + effectiveStacks);

    default:
      return base * effectiveStacks;
  }
}

export function computeAllArtifacts(state: any, defs: Record<string, ArtifactDefinition>, ctx: Omit<ArtifactContext, "totalArtifacts">) {
  const result: Record<string, any> = {};

  const totalArtifacts = state.artifacts ? state.artifacts.length : 0;

  if (!state.artifacts) return result;

  const relicBonuses = (window as any).gameInstance?.getRelicBonuses() || {};
  const artifactPowerMultiplier = 1 + (relicBonuses.artifactPowerPercent || 0);

  for (const art of state.artifacts) {
    const def = defs[art.id];
    if (!def) continue;

    const rawValue = computeArtifactValue(def, art.stacks, {
      ...ctx,
      totalArtifacts
    });

    if (typeof rawValue === 'number') {
      result[art.id] = rawValue * artifactPowerMultiplier;
    } else if (typeof rawValue === 'object' && rawValue !== null) {
      const scaledObj: any = {};
      for (const key in rawValue) {
        if (typeof rawValue[key] === 'number') {
          scaledObj[key] = rawValue[key] * artifactPowerMultiplier;
        } else {
          scaledObj[key] = rawValue[key];
        }
      }
      result[art.id] = scaledObj;
    } else {
      result[art.id] = rawValue;
    }
  }

  return result;
}
