import { ArtifactEventBus } from "./artifactEventBus";

export const ARTIFACT_SYNERGIES = [
  {
    id: "time_combo_1",
    requires: ["time_echo", "time_fracture"],
    effect: {
      type: "onKill_explosion",
      value: 20
    }
  }
];

export function resolveSynergies(stackMap: Record<string, any>) {
  const result = [];

  if (!stackMap) return result;

  for (let i = 0; i < ARTIFACT_SYNERGIES.length; i++) {
    const syn = ARTIFACT_SYNERGIES[i];
    if (!syn || !Array.isArray(syn.requires)) continue;

    let valid = true;

    for (let j = 0; j < syn.requires.length; j++) {
      if (!stackMap[syn.requires[j]]) {
        valid = false;
        break;
      }
    }

    if (valid) result.push(syn);
  }

  return result;
}

export function bindSynergy(synergy: any, context: any) {
  if (!synergy || !synergy.effect) return;

  const effect = synergy.effect;

  switch (effect.type) {

    case "onKill_explosion":
      ArtifactEventBus.on("onKill", ({ enemy }: any) => {
        if (!enemy || !enemy.nearby) return;

        for (let i = 0; i < enemy.nearby.length; i++) {
          const e = enemy.nearby[i];
          if (e && typeof e.hp === "number") {
            e.hp -= effect.value || 0;
          }
        }
      });
      break;

    default:
      console.warn("Unknown synergy effect:", effect.type);
      break;
  }
}
