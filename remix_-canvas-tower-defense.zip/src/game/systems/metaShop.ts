import { META_UPGRADES } from "./metaUpgrades";

export function getUpgradeCost(level: number) {
  return Math.floor(10 + level * 15);
}

export function buyMetaUpgrade(player: any, key: string) {
  if (!player || !player.meta) return false;

  const def = META_UPGRADES[key];
  if (!def) return false;

  const upgrades = player.meta.upgrades;
  const currentLevel = upgrades[key] || 0;

  const cost = getUpgradeCost(currentLevel);

  if (player.meta.corruptedShards < cost) return false;

  player.meta.corruptedShards -= cost;

  upgrades[key] = currentLevel + 1;

  return true;
}
