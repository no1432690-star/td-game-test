import { getUpgradeValue } from "./metaUpgrades";

export function calculateShardReward(player: any, baseReward: number) {
  if (!player) return 0;

  const gainBonus = getUpgradeValue(player, "shard_gain");

  let result = baseReward * (1 + gainBonus);

  return Math.floor(result);
}

export function grantShardReward(player: any, amount: number) {
  if (!player || !player.meta) return;

  if (typeof player.meta.corruptedShards !== "number") {
    player.meta.corruptedShards = 0;
  }

  player.meta.corruptedShards += amount;
}
