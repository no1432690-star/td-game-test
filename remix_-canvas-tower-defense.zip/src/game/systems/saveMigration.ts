import { SAVE_VERSION } from "./saveConfig";

export function migrateSave(save: any) {
  if (!save || typeof save !== "object") return null;

  let current = save;

  if (typeof current.version !== "number") {
    current.version = 1;
  }

  // future-proof structure
  switch (current.version) {
    case 1:
      // no changes yet
      break;

    default:
      break;
  }

  current.version = SAVE_VERSION;

  return current;
}
