import { describe, test, expect, beforeEach } from 'vitest';
import { PrestigeSystem, RunStats } from './PrestigeSystem';
import { MetaSaveManager } from '../../meta/MetaSaveManager';
import { MetaSave } from '../../meta/MetaSave';

// Mock MetaSaveManager
class MockMetaSaveManager {
  private save: MetaSave = {
    corruptedShards: 0,
    prestigeLevel: 0,
    voidEssence: 0,
    voidEssenceHistory: { gained: 0, spent: 0, netBalance: 0 },
    statistics: {
      highestWave: 0,
      totalRuns: 0,
      totalEnemiesKilled: 0,
      totalPrestiges: 0,
      prestigeStreak: 0
    }
  };

  getSave() {
    return this.save;
  }

  saveGame() {}
}

describe('PrestigeSystem Void Essence Tests', () => {
  let saveManager: MockMetaSaveManager;
  let prestigeSystem: PrestigeSystem;

  beforeEach(() => {
    saveManager = new MockMetaSaveManager();
    prestigeSystem = new PrestigeSystem(saveManager);
  });

  test('Test 1 - Basic gain', () => {
    const stats: RunStats = {
      highestWave: 50,
      totalTimeSeconds: 50 * 60, // 1 wpm
      livesRemaining: 5,
      startingLives: 20, // 25% survival
      totalGoldEarned: 50 * 200, // 200 gold/wave
      previousHighest: 0,
      prestigeStreak: 0
    };

    const reward = prestigeSystem.calculateReward(stats);
    const voidEssence = prestigeSystem.calculateVoidEssenceGain(stats, reward.total);

    // Base multiplier is 1.0 (no bonuses)
    expect(voidEssence).toBe(reward.total);
    expect(voidEssence).toBeGreaterThanOrEqual(10);
    expect(voidEssence).toBeLessThanOrEqual(100); // Just a sanity check
  });

  test('Test 2 - Performance multiplier', () => {
    const stats: RunStats = {
      highestWave: 100,
      totalTimeSeconds: 100 * 60 / 3, // 3 wpm => +0.3
      livesRemaining: 20,
      startingLives: 20, // 100% survival => +0.2
      totalGoldEarned: 100 * 700, // 700 gold/wave => +0.2
      previousHighest: 0,
      prestigeStreak: 0
    };

    const reward = prestigeSystem.calculateReward(stats);
    const voidEssence = prestigeSystem.calculateVoidEssenceGain(stats, reward.total);

    // Multiplier should be 1.0 + 0.3 + 0.2 + 0.2 = 1.7
    expect(voidEssence).toBe(Math.floor(reward.total * 1.7));
  });

  test('Test 3 - Poor performance', () => {
    const stats: RunStats = {
      highestWave: 30,
      totalTimeSeconds: 30 * 60 * 2, // 0.5 wpm => +0
      livesRemaining: 1,
      startingLives: 20, // 5% survival => +0
      totalGoldEarned: 30 * 100, // 100 gold/wave => +0
      previousHighest: 0,
      prestigeStreak: 0
    };

    const reward = prestigeSystem.calculateReward(stats);
    const voidEssence = prestigeSystem.calculateVoidEssenceGain(stats, reward.total);

    // Multiplier should be 1.0
    expect(voidEssence).toBe(reward.total);
  });

  test('Test 4 - History tracking', () => {
    const stats1: RunStats = { highestWave: 30, totalTimeSeconds: 30*60, livesRemaining: 20, startingLives: 20, totalGoldEarned: 30*500, previousHighest: 0, prestigeStreak: 0 };
    const stats2: RunStats = { highestWave: 40, totalTimeSeconds: 40*60, livesRemaining: 20, startingLives: 20, totalGoldEarned: 40*500, previousHighest: 30, prestigeStreak: 1 };
    const stats3: RunStats = { highestWave: 50, totalTimeSeconds: 50*60, livesRemaining: 20, startingLives: 20, totalGoldEarned: 50*500, previousHighest: 40, prestigeStreak: 2 };

    const r1 = prestigeSystem.performPrestige(stats1);
    const r2 = prestigeSystem.performPrestige(stats2);
    const r3 = prestigeSystem.performPrestige(stats3);

    const save = saveManager.getSave();
    const expectedTotal = (r1.voidEssenceGain || 0) + (r2.voidEssenceGain || 0) + (r3.voidEssenceGain || 0);

    expect(save.voidEssenceHistory.gained).toBe(expectedTotal);
    expect(save.voidEssence).toBe(expectedTotal);
    expect(save.voidEssenceHistory.netBalance).toBe(expectedTotal);
  });

  test('Test 5 - No negative void essence', () => {
    const stats: RunStats = {
      highestWave: -10,
      totalTimeSeconds: -50,
      livesRemaining: -5,
      startingLives: 20,
      totalGoldEarned: -1000,
      previousHighest: 0,
      prestigeStreak: 0
    };

    // Need to mock Math.max(1, wave) logic for negative waves to avoid NaN
    const reward = prestigeSystem.calculateReward(stats);
    const voidEssence = prestigeSystem.calculateVoidEssenceGain(stats, reward.total);

    expect(voidEssence || 0).toBeGreaterThanOrEqual(0);
  });
});
