export const SAVE_KEY = "game_save_v1";
export const SAVE_BACKUP_KEY = "game_save_backup_v1";
export const SAVE_VERSION = 1;

export const RUN_SAVE_KEY = "run_save_v1";
