import { SAVE_VERSION } from "./saveConfig";

export function buildSaveData(player: any) {
  if (!player) return null;

  return {
    version: SAVE_VERSION,

    meta: player.meta || {
      corruptedShards: 0,
      upgrades: {}
    },

    stats: {
      totalRuns: player.totalRuns || 0
    },

    analytics: player.analytics || {}
  };
}
