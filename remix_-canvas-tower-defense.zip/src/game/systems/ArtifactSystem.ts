import { ARTIFACT_DEFS } from './artifactDefinitions';
import { addArtifact } from './artifactEngine';

export interface Artifact {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  purchaseCount: number;
  effect: (tower: any) => void;
}

export class ArtifactSystem {
  public artifacts: Artifact[] = [];
  public playerArtifacts: string[] = [];
  public pendingChoices: Artifact[] | null = null;
  public rerollCount: number = 0;
  private readonly REROLL_BASE_COST = 500_000;
  private readonly REROLL_CAP = 2;

  constructor() {
    // Legacy Tesla Artifacts
    this.artifacts = [
      {
        id: "tesla_coil",
        name: "Tesla Coil",
        description: "+1 Max Tesla Link",
        basePrice: 100,
        purchaseCount: 0,
        effect: (tower) => {}
      },
      {
        id: "conductive_plating",
        name: "Conductive Plating",
        description: "+10% Tesla Buff Strength",
        basePrice: 150,
        purchaseCount: 0,
        effect: (tower) => {}
      },
      {
        id: "lightning_rod",
        name: "Lightning Rod",
        description: "+20% Tesla Range",
        basePrice: 200,
        purchaseCount: 0,
        effect: (tower) => {}
      }
    ];

    // Add new artifacts from ARTIFACT_DEFS
    if (typeof ARTIFACT_DEFS !== 'undefined') {
      for (const def of Object.values(ARTIFACT_DEFS)) {
        if (!this.artifacts.find(a => a.id === def.id)) {
          this.artifacts.push({
            id: def.id,
            name: def.name,
            description: def.description,
            basePrice: def.basePrice || 150,
            purchaseCount: 0,
            effect: (tower) => {}
          });
        }
      }
    }
  }

  public getArtifactPrice(artifact: Artifact): number {
    return artifact.basePrice * Math.pow(2, artifact.purchaseCount);
  }

  public generateChoices(): void {
    // Filter out artifacts that have reached their hardCap
    const availableArtifacts = this.artifacts.filter(a => {
      if (typeof ARTIFACT_DEFS !== 'undefined') {
        const def = ARTIFACT_DEFS[a.id];
        if (def) {
          const max = def.hardCap;
          if (max && a.purchaseCount >= max) {
            return false;
          }
        }
      }
      return true;
    });

    // Pick 3 random artifacts
    const shuffled = [...availableArtifacts].sort(() => 0.5 - Math.random());
    this.pendingChoices = shuffled.slice(0, 3);
  }

  public purchaseArtifact(id: string, gold: number, gameInstance?: any): number {
    if (!this.pendingChoices) return gold;
    const artifact = this.artifacts.find(a => a.id === id);
    if (!artifact) return gold;

    const price = this.getArtifactPrice(artifact);
    if (gold >= price) {
      artifact.purchaseCount++;
      this.playerArtifacts.push(id);
      this.pendingChoices = null;
      this.rerollCount = 0;
      
      // Sync with new artifact engine
      if (gameInstance) {
        // === [PATCH] Ensure shop adds artifact correctly ===
        if ((window as any).ArtifactRuntime) {
          (window as any).ArtifactRuntime.ensure(gameInstance);
        }
        addArtifact(gameInstance, id, 1);
      }
      
      return gold - price;
    }
    return gold;
  }

  public getRerollCost(): number {
    return this.REROLL_BASE_COST * Math.pow(2, this.rerollCount);
  }

  public canReroll(): boolean {
    return this.rerollCount < this.REROLL_CAP;
  }

  public rerollChoices(): void {
    if (!this.canReroll()) return;
    this.rerollCount++;
    this.generateChoices();
  }

  public resetReroll(): void {
    this.rerollCount = 0;
  }

  public skipArtifacts(): void {
    this.pendingChoices = null;
    this.rerollCount = 0;
  }

  public getArtifactCount(id: string): number {
    return this.playerArtifacts.filter(a => a === id).length;
  }
}
