export const ENABLE_TESLA_TOPOLOGY = true;
export const ENABLE_TESLA_FLOW = true;
export const ENABLE_TESLA_ADVANCED_FLOW = true;
export const ENABLE_TESLA_DEBUG_FORCE = true;

export const TESLA_FLOW_MODES = [
    "BALANCED",
    "FOCUSED",
    "OVERFLOW"
];

export function cycleTeslaFlowMode(tesla: any) {
    let i = TESLA_FLOW_MODES.indexOf(tesla.flowMode);
    i = (i + 1) % TESLA_FLOW_MODES.length;
    tesla.flowMode = TESLA_FLOW_MODES[i];
}

export function assignFlowTarget(tesla: any) {
    if (tesla.flowMode !== "FOCUSED") {
        tesla.flowTarget = null;
        return;
    }

    if (!tesla.connections || tesla.connections.length === 0) {
        tesla.flowTarget = null;
        return;
    }

    // chọn Tesla gần nhất
    tesla.flowTarget = tesla.connections[0];
}

export function computeEnergyTransfer(from: any, to: any, cluster: any) {
    let base = from.energy * 0.15;
    let distanceFactor = 1 / (1 + from.depth * 0.5);
    let transfer = base * distanceFactor;

    if (from.flowMode === "FOCUSED" && from.flowTarget === to) {
        transfer *= 1.5;
    } else if (from.flowMode === "OVERFLOW") {
        transfer *= 0.7;
    }

    if (cluster && cluster.transferBoost) {
        transfer *= (1 + cluster.transferBoost);
    }

    return transfer;
}

export function propagateEnergyAdvanced(cluster: any[]) {
    if (cluster.length < 3) return;

    for (let t of cluster) {
        t.visited = false;
        t.depth = 0;
        t.nextEnergy = t.energy;
    }

    let queue: any[] = [];

    for (let t of cluster) {
        if (t.flowMode === "FOCUSED") {
            queue.push(t);
            t.visited = true;
        }
    }

    while (queue.length > 0) {
        let current = queue.shift();

        for (let neighbor of current.connections) {
            if (neighbor.visited) continue;

            neighbor.visited = true;
            neighbor.depth = current.depth + 1;

            let transfer = computeEnergyTransfer(current, neighbor, current.cluster);

            if (current.nextEnergy < transfer) {
                transfer = current.nextEnergy * 0.5;
            }

            neighbor.nextEnergy += transfer;
            current.nextEnergy -= transfer;

            queue.push(neighbor);
        }
    }

    for (let t of cluster) {
        t.energy = Math.max(t.cluster?.minEnergy || 50, Math.min(200, t.nextEnergy));
    }
}

export function applyEnergyDecay(allTeslas: any[]) {
    for (let t of allTeslas) {
        let decay = 2; // per tick
        if (t.cluster && t.cluster.decayReduction) {
            decay *= (1 - t.cluster.decayReduction);
        }
        t.energy -= decay;
        let minE = t.cluster?.minEnergy || 50;
        if (t.energy < minE) t.energy = minE;
    }
}

export function applyTopologyEnergyBonus(cluster: any) {
    cluster.decayReduction = 0;
    cluster.transferBoost = 0;
    cluster.minEnergy = 50;

    switch (cluster.topologyType) {
        case "LINE":
            cluster.decayReduction = 0.3;
            break;
        case "TRIANGLE":
            cluster.transferBoost = 0.2;
            break;
        case "SQUARE":
            cluster.minEnergy = 80;
            break;
        case "STAR":
            let maxDeg = 0;
            let centerNode = null;
            for (let t of cluster) {
                if (t.connections.length > maxDeg) {
                    maxDeg = t.connections.length;
                    centerNode = t;
                }
            }
            if (centerNode) {
                centerNode.energy += 5;
            }
            break;
    }
}

export function propagateEnergy(allTeslas: any[]) {
    for (let t of allTeslas) {
        if (t.flowMode !== "FOCUSED") continue;
        if (!t.flowTarget) continue;

        let energyTransfer = t.energy * 0.2;

        t.energy -= energyTransfer;
        t.flowTarget.energy += energyTransfer;
    }
    
    for (let t of allTeslas) {
        t.energy = Math.max(30, Math.min(200, t.energy));
    }
}

export function getFlowMultiplier(tesla: any) {
    if (!ENABLE_TESLA_FLOW) return 1;

    switch (tesla.flowMode) {
        case "BALANCED":
            return 1.1;
        case "FOCUSED":
            let base = 1 + (tesla.energy / 200);
            let extra = 0;
            const upgradeManager = (window as any).gameInstance?.upgradeManager;
            if (upgradeManager) {
                extra = upgradeManager.getRawClassStat('Tesla', 'tesla_focused_bonus');
            }
            return base * (1 + extra);
        case "OVERFLOW":
            return 1.0;
        default:
            return 1;
    }
}

export function getEnergyMultiplier(tesla: any) {
    return 1 + (tesla.energy - 100) / 200;
}

export function distance(a: any, b: any) {
    return Math.sqrt(Math.pow(a.position.x - b.position.x, 2) + Math.pow(a.position.y - b.position.y, 2));
}

export function updateTeslaConnections(allTeslas: any[]) {
    for (let t of allTeslas) {
        t.connections = [];
        if (!t.connectionRadius) {
            t.connectionRadius = t.range || 120;
        }
    }

    for (let i = 0; i < allTeslas.length; i++) {
        for (let j = i + 1; j < allTeslas.length; j++) {
            let a = allTeslas[i];
            let b = allTeslas[j];

            let dist = distance(a, b);

            if (dist <= a.connectionRadius) {
                a.connections.push(b);
                b.connections.push(a);
            }
        }
    }
}

export function getTeslaClusters(allTeslas: any[]) {
    let visited = new Set();
    let clusters = [];

    for (let t of allTeslas) {
        if (visited.has(t)) continue;

        let stack = [t];
        let cluster = [];

        while (stack.length > 0) {
            let current = stack.pop();

            if (visited.has(current)) continue;

            visited.add(current);
            cluster.push(current);

            for (let neighbor of current.connections) {
                if (!visited.has(neighbor)) {
                    stack.push(neighbor);
                }
            }
        }

        clusters.push(cluster);
    }

    return clusters;
}

export function detectTopology(cluster: any[]) {
    let n = cluster.length;

    if (n < 3) return "NONE";

    let degrees = cluster.map(t => t.connections.length);

    // STAR
    if (degrees.some(d => d >= 3)) {
        return "STAR";
    }

    // TRIANGLE
    if (n === 3 && degrees.every(d => d === 2)) {
        return "TRIANGLE";
    }

    // SQUARE
    if (n === 4 && degrees.every(d => d === 2)) {
        return "SQUARE";
    }

    // LINE
    let maxDeg = Math.max(...degrees);
    if (maxDeg <= 2 && n >= 3) {
        return "LINE";
    }

    return "NONE";
}

export const TOPOLOGY_BUFFS: Record<string, any> = {
    LINE: {
        projectileSpeed: 0.2,
        range: 10
    },
    TRIANGLE: {
        damage: 0.15,
        critChance: 0.10
    },
    SQUARE: {
        teslaBuffMultiplier: 0.20
    },
    STAR: {
        attackSpeed: 0.30
    }
};

export function applyTopology(cluster: any[]) {
    let type = detectTopology(cluster);

    (cluster as any).topologyType = type;
    
    if (TOPOLOGY_BUFFS[type]) {
        (cluster as any).topologyBonus = { ...TOPOLOGY_BUFFS[type] };
        
        const upgradeManager = (window as any).gameInstance?.upgradeManager;
        if (upgradeManager) {
            let extra = upgradeManager.getRawClassStat('Tesla', 'tesla_topology_bonus');
            if (extra > 0) {
                for (let key in (cluster as any).topologyBonus) {
                    (cluster as any).topologyBonus[key] *= (1 + extra);
                }
            }
        }
    } else {
        (cluster as any).topologyBonus = null;
    }
}

let lastTopologyUpdate = 0;

export function processTeslaTopology(allTeslas: any[], currentTime: number) {
    if (!ENABLE_TESLA_TOPOLOGY) return;

    const updateInterval = ENABLE_TESLA_ADVANCED_FLOW ? 500 : 250;

    if (currentTime - lastTopologyUpdate >= updateInterval) {
        lastTopologyUpdate = currentTime;

        // Backward compatibility and initialization
        for (let t of allTeslas) {
            if (!t.flowMode) t.flowMode = "BALANCED";
            if (!t.energy) t.energy = 100;
            if (t.nextEnergy === undefined) t.nextEnergy = 100;
            if (t.depth === undefined) t.depth = 0;
            if (t.visited === undefined) t.visited = false;
        }

        updateTeslaConnections(allTeslas);
        const clusters = getTeslaClusters(allTeslas);

        for (let cluster of clusters) {
            applyTopology(cluster);
            for (let t of cluster) {
                t.cluster = cluster;
            }
            
            applyTopologyEnergyBonus(cluster);

            if (ENABLE_TESLA_FLOW) {
                for (let t of cluster) {
                    assignFlowTarget(t);
                }
                
                if (ENABLE_TESLA_ADVANCED_FLOW) {
                    try {
                        propagateEnergyAdvanced(cluster);
                    } catch (e) {
                        propagateEnergy(cluster);
                    }
                } else {
                    propagateEnergy(cluster);
                }
            }
        }

        if (ENABLE_TESLA_FLOW && ENABLE_TESLA_ADVANCED_FLOW) {
            applyEnergyDecay(allTeslas);
        }

        if (ENABLE_TESLA_DEBUG_FORCE && Math.random() < 0.02) {
            for (let t of allTeslas) {
                console.log(
                    "[TESLA]",
                    "E:", Math.round(t.energy),
                    "Mode:", t.flowMode,
                    "Conn:", t.connections?.length,
                    "Topo:", t.cluster?.topologyType
                );
            }
        }
    }
}
