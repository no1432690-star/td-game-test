export function initOnboarding(player: any) {
  if (!player) return;

  if (!player.onboarding) {
    player.onboarding = {
      step: 0,
      completed: false
    };
  }
}
