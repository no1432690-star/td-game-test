import { DamagePipeline } from './tower/DamagePipeline';
import { applyArtifactDamage, applyArtifactOnHit, applyArtifactOverkill, applyArtifactEcho, registerArtifactHit } from './artifactHooks';
import { ArtifactEventBus } from './artifactEventBus';
import { TeslaSystem } from './TeslaSystem';
import { ENABLE_TESLA_TOPOLOGY, ENABLE_TESLA_FLOW, ENABLE_TESLA_ADVANCED_FLOW, ENABLE_TESLA_DEBUG_FORCE, processTeslaTopology, getFlowMultiplier, getEnergyMultiplier } from './TeslaTopologySystem';

export function recalculateTowerStats(tower: any) {
  if (!tower.buffs) tower.buffs = [];
  
  // 1 reset finalStats to baseStats
  tower.finalStats = { ...tower.baseStats };

  // 2 apply buffs
  for (const buff of tower.buffs) {
    if (tower.finalStats[buff.stat] === undefined) {
      tower.finalStats[buff.stat] = tower.baseStats[buff.stat] || 0;
    }
    
    if (buff.type === "add") {
      tower.finalStats[buff.stat] += buff.value;
    } else if (buff.type === "multiply") {
      tower.finalStats[buff.stat] *= (1 + buff.value);
    }
  }
}

export function updateEnemyEffects(enemy: any, dt: number) {
  if (!enemy.effects) enemy.effects = [];
  
  // Reset finalStats to baseStats
  enemy.finalStats = { ...enemy.baseStats };
  
  let currentSpeedMultiplier = 1.0;
  let isStunned = false;

  for (let i = enemy.effects.length - 1; i >= 0; i--) {
    const effect = enemy.effects[i];
    effect.duration -= dt;
    
    if (effect.duration <= 0) {
      enemy.effects.splice(i, 1);
    } else {
      if (effect.type === 'slow') {
        currentSpeedMultiplier = Math.min(currentSpeedMultiplier, effect.multiplier ?? (1 - effect.value));
      } else if (effect.type === 'stun') {
        isStunned = true;
      } else if (effect.type === 'burn') {
        // Tick damage handled elsewhere or here? 
        // "burn: damage over time, tick every 1 second"
        // Let's implement tick logic. We can store a tick timer on the effect.
        if (effect.tickTimer === undefined) effect.tickTimer = 1;
        effect.tickTimer -= dt;
        if (effect.tickTimer <= 0) {
          effect.tickTimer += 1;
          applyDamage(enemy, { amount: effect.value, type: 'burn', sourceTower: effect.sourceTower, crit: false });
        }
      }
    }
  }

  enemy.finalStats.speed = isStunned ? 0 : enemy.baseStats.speed * currentSpeedMultiplier;
  enemy.speed = enemy.finalStats.speed;
}

export function applyDamage(enemy: any, damage: any) {
  ArtifactEventBus.emit("onDamage", {
    source: damage.sourceTower,
    target: enemy,
    amount: damage.amount
  });

  const data = {
    sourceTower: damage.sourceTower,
    targetEnemy: enemy,
    baseDamage: damage.amount,
    finalDamage: damage.amount,
    isCrit: damage.crit,
    damageType: damage.type
  };

  const relicBonuses = (window as any).gameInstance?.getRelicBonuses() || {};
  
  if (relicBonuses.atkPercent) {
    data.finalDamage *= (1 + relicBonuses.atkPercent);
  }
  
  if (damage.sourceTower?.tags?.includes('magic') && relicBonuses.allStatPercent) {
    data.finalDamage *= (1 + relicBonuses.allStatPercent);
  }

  DamagePipeline.applyModifiers(data);

  let amount = data.finalDamage;
  
  // 1 base damage
  // 2 crit check (already done in tower logic usually, but we receive `amount` which might include crit)
  
  // 3 tower buffs (already handled in tower stats)
  
  // 4 enemy resistance
  if (data.damageType === 'magic') {
    amount *= (1 - (enemy.finalStats.magicResist || 0));
  } else {
    amount *= (1 - (enemy.finalStats.armor || 0));
  }
  
  // 5 shock modifier
  const shockEffect = enemy.effects?.find((e: any) => e.type === 'shock');
  if (shockEffect) {
    amount *= (1 + shockEffect.value);
  }
  
  const game = (window as any).gameInstance;

  amount = applyArtifactDamage(amount, game);
  
  // 6 apply HP
  enemy.health -= amount;

  applyArtifactOnHit(enemy, game);

  applyArtifactOverkill(enemy, amount, game, (target, dmg) => {
    if (game && game.getNearbyEnemies) {
      const nearby = game.getNearbyEnemies(target.position.x, target.position.y, 100);
      for (const n of nearby) {
        if (n !== target) {
          applyDamage(n, { amount: dmg, type: 'magic', sourceTower: damage.sourceTower, crit: false, isArtifact: true });
        }
      }
    }
  });

  if (!damage.isArtifact && game) {
    applyArtifactEcho(enemy, amount, game, (t, d) => {
      applyDamage(t, { amount: d, type: 'magic', sourceTower: damage.sourceTower, crit: false, isArtifact: true });
    });
    
    if (registerArtifactHit(game)) {
      applyDamage(enemy, { amount: amount * 2, type: 'magic', sourceTower: damage.sourceTower, crit: false, isArtifact: true });
    }
  }
}

import { ArtifactSystem } from './ArtifactSystem';

let lastTeslaUpdate = 0;

export function updateTeslaNetwork(towers: any[], artifactSystem?: ArtifactSystem) {
  const now = Date.now();
  if (now - lastTeslaUpdate < 200) return;
  lastTeslaUpdate = now;

  // Safe Buff Cleanup: remove all buffs where source = "tesla"
  for (const tower of towers) {
    if (!tower) continue;
    if (!tower.buffs) tower.buffs = [];
    tower.buffs = tower.buffs.filter((b: any) => b.source !== 'tesla');
    if (!tower.teslaLinks) tower.teslaLinks = [];
    tower.teslaLinks = []; // Reset tesla links
  }

  const teslas = towers.filter(t => t && t.constructor.name === 'Tesla');
  if (teslas.length === 0) return;

  if (ENABLE_TESLA_TOPOLOGY) {
    processTeslaTopology(teslas, Date.now());
  }

  // Find connected clusters of Teslas (within 3 tiles = 150 range)
  const clusters: any[][] = [];
  const visited = new Set();

  for (const tesla of teslas) {
    if (!tesla) continue;
    if (visited.has(tesla)) continue;
    
    const cluster: any[] = [];
    const queue = [tesla];
    visited.add(tesla);

    while (queue.length > 0) {
      const current = queue.shift();
      cluster.push(current);

      for (const other of teslas) {
        if (!other) continue;
        if (!visited.has(other) && current.position.dist(other.position) <= 150) {
          visited.add(other);
          queue.push(other);
        }
      }
    }
    clusters.push(cluster);
  }

  const MAX_TESLA_LINKS = 6;
  let maxTeslaLinksPerTower = 6;
  let buffStrengthMultiplier = 1.0;
  let teslaRangeMultiplier = 1.0;

  const upgradeManager = (window as any).gameInstance?.upgradeManager;
  if (upgradeManager) {
    let extraLinks = upgradeManager.getRawClassStat('Tesla', 'tesla_max_links');
    let extraBuffStrength = upgradeManager.getRawClassStat('Tesla', 'tesla_buff_global');
    let extraEnergy = upgradeManager.getRawClassStat('Tesla', 'tesla_energy_bonus');
    let extraTopology = upgradeManager.getRawClassStat('Tesla', 'tesla_topology_bonus');
    let extraFocused = upgradeManager.getRawClassStat('Tesla', 'tesla_focused_bonus');

    if (ENABLE_TESLA_DEBUG_FORCE && Math.random() < 0.05) {
      console.log("Tesla upgrades active:", {
        buff: extraBuffStrength,
        links: extraLinks,
        energy: extraEnergy,
        topology: extraTopology,
        focused: extraFocused
      });
    }
    
    for (const tesla of teslas) {
      if (!tesla.energyInitialized) {
        tesla.energy = 100 + extraEnergy;
        tesla.energyInitialized = true;
        tesla.lastExtraEnergy = extraEnergy;
      } else if (tesla.lastExtraEnergy !== extraEnergy) {
        const diff = extraEnergy - (tesla.lastExtraEnergy || 0);
        tesla.energy += diff;
        tesla.lastExtraEnergy = extraEnergy;
      }
    }

    for (const def of upgradeManager.definitions) {
      if (def.classType === 'Tesla') {
        const stack = upgradeManager.stacks[def.id] || 0;
        if (stack > 0) {
          if (def.stat === 'max_links') extraLinks += stack * def.value;
          if (def.stat === 'buff_strength') extraBuffStrength += stack * def.value;
        }
      }
    }
    maxTeslaLinksPerTower += extraLinks;
    buffStrengthMultiplier += extraBuffStrength;
  }

  if (artifactSystem) {
    maxTeslaLinksPerTower += artifactSystem.getArtifactCount("tesla_coil");
    buffStrengthMultiplier += 0.10 * artifactSystem.getArtifactCount("conductive_plating");
    teslaRangeMultiplier += 0.20 * artifactSystem.getArtifactCount("lightning_rod");
  }

  maxTeslaLinksPerTower = Math.min(maxTeslaLinksPerTower, MAX_TESLA_LINKS);

  const teslaLinkScaling = [1.0, 0.8, 0.6];
  // If max links > 3, we need to extend the scaling array.
  // The prompt doesn't specify scaling beyond 3, so let's just use 0.4, 0.2, etc. or just 0.6 for all subsequent links.
  while (teslaLinkScaling.length < maxTeslaLinksPerTower) {
    const last = teslaLinkScaling[teslaLinkScaling.length - 1];
    teslaLinkScaling.push(Math.max(0.2, last - 0.2));
  }

  for (const tower of towers) {
    if (!tower) continue;

    // Find all Teslas in range (excluding self if it's a Tesla)
    const teslasInRange = teslas.filter(tesla => {
      if (tesla === tower) return false;
      const radius = TeslaSystem.getElectricFieldRadius(tesla, (window as any).gameInstance?.upgradeManager) * teslaRangeMultiplier;
      return tesla.position.dist(tower.position) <= radius;
    });
    
    // Sort by distance
    teslasInRange.sort((a, b) => a.position.dist(tower.position) - b.position.dist(tower.position));
    
    // Limit to max links
    tower.teslaLinks = teslasInRange.slice(0, maxTeslaLinksPerTower);
    tower.activeTeslaLinks = tower.teslaLinks.length;

    if (tower.constructor.name === 'Tesla') continue;

    if (tower.teslaLinks.length > 0) {
      let baseBuffValue = 0;
      let buffStat = '';
      
      if (tower.isLegendary) {
        buffStat = 'aoeRadius';
        baseBuffValue = 0.20;
      } else if (tower.isCorrupted) {
        buffStat = 'critChance';
        baseBuffValue = 0.10; // +10% crit chance (add)
      } else {
        buffStat = 'attackSpeed';
        baseBuffValue = 0.15; // +15% attack speed (multiply)
      }

      const buffType = buffStat === 'critChance' ? 'add' : 'multiply';

      let baseTotalBuffValue = 0;
      for (let i = 0; i < tower.teslaLinks.length; i++) {
        const tesla = tower.teslaLinks[i];
        
        // Check if this tesla is in a network >= 5
        let networkBonus = 1.0;
        for (const cluster of clusters) {
          if (cluster.includes(tesla) && cluster.length >= 5) {
            networkBonus = 1.2;
            break;
          }
        }

        baseTotalBuffValue += baseBuffValue * teslaLinkScaling[i] * networkBonus * buffStrengthMultiplier;
      }

      let totalBonus = 0;
      if (ENABLE_TESLA_TOPOLOGY) {
        for (let tesla of tower.teslaLinks || []) {
            let bonus = 0;

            if (ENABLE_TESLA_FLOW) {
                bonus += (getFlowMultiplier(tesla) - 1);
            }

            if (ENABLE_TESLA_ADVANCED_FLOW) {
                bonus += (getEnergyMultiplier(tesla) - 1);
            }

            let cluster = tesla.cluster;
            if (cluster?.topologyBonus?.teslaBuffMultiplier) {
                bonus += cluster.topologyBonus.teslaBuffMultiplier;
            }

            totalBonus += bonus;
        }
      }

      totalBonus = Math.min(totalBonus, 2.0);
      let totalBuffValue = baseTotalBuffValue * (1 + totalBonus);

      let overloadDamageBonus = 0;
      let extraOverloadDamage = upgradeManager?.getRawClassStat('Tesla', 'tesla_overload_damage') || 0;
      if (extraOverloadDamage > 0) {
        for (let tesla of tower.teslaLinks || []) {
            if (tesla.energy >= 200) {
                overloadDamageBonus += extraOverloadDamage;
                break; // Only apply once per tower
            }
        }
      }

      tower.buffs.push({
        id: `tesla_stack_${tower.position.x}_${tower.position.y}`,
        source: 'tesla',
        stat: buffStat,
        type: buffType,
        value: totalBuffValue,
        duration: Infinity
      });

      if (totalBonus > 0 || overloadDamageBonus > 0) {
        tower.buffs.push({
          id: `tesla_damage_bonus_${tower.position.x}_${tower.position.y}`,
          source: 'tesla',
          stat: 'damage',
          type: 'multiply',
          value: totalBonus + overloadDamageBonus,
          duration: Infinity
        });
      }

      if (ENABLE_TESLA_FLOW) {
        for (const tesla of tower.teslaLinks) {
          if (tesla.flowMode === "OVERFLOW") {
            let nearestDist = Infinity;
            let nearestTower = null;
            for (const other of towers) {
              if (!other || other === tower || other.constructor.name === 'Tesla') continue;
              const dist = tower.position.dist(other.position);
              if (dist < nearestDist) {
                nearestDist = dist;
                nearestTower = other;
              }
            }

            if (nearestTower) {
              nearestTower.buffs.push({
                id: `tesla_overflow_${tower.position.x}_${tower.position.y}_${tesla.position.x}_${tesla.position.y}`,
                source: 'tesla',
                stat: buffStat,
                type: buffType,
                value: totalBuffValue * 0.3,
                duration: Infinity
              });
            }
          }
        }
      }
    }
  }
}
