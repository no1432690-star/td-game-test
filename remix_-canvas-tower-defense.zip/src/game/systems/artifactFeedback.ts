export function playArtifactSound(type: string) {
  try {
    switch (type) {
      case "select":
        console.log("[Sound] select");
        break;
      case "reroll":
        console.log("[Sound] reroll");
        break;
      default:
        console.log("[Sound] default");
    }
  } catch (e) {}
}

export function showFloatingText(text: string) {
  try {
    if (!text) return;
    console.log("[FloatingText]", text);
  } catch (e) {}
}
