import { Projectile } from "../entities/Projectile"

export class ProjectilePool {

  private pool: Projectile[] = []

  get(): Projectile {

    if (this.pool.length > 0) {
      return this.pool.pop()!
    }

    return new Projectile()
  }

  release(p: Projectile) {
    if (p.constructor.name === 'Projectile') {
      p.active = false
      this.pool.push(p)
    }
  }

}

export const projectilePool = new ProjectilePool()
