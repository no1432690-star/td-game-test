export const SlotEconomy = {
  getUnlockCost(index: number) {
    if (index < 30) {
      return 0;
    }
    const base = 10000;
    const step = 2500;
    return base + (index - 30) * step;
  }
};
