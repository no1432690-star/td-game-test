export function isCrazyGamesEnvironment() {
  try {
    return window.self !== window.top
  } catch {
    return true
  }
}
