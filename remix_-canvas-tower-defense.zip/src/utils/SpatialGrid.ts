export class SpatialGrid<T extends { x: number; y: number }> {

  cellSize: number
  grid: Map<string, T[]>

  constructor(cellSize = 120) {
    this.cellSize = cellSize
    this.grid = new Map()
  }

  private key(x: number, y: number) {
    const gx = Math.floor(x / this.cellSize)
    const gy = Math.floor(y / this.cellSize)
    return gx + "," + gy
  }

  clear() {
    this.grid.clear()
  }

  insert(obj: T) {
    const k = this.key(obj.x, obj.y)

    if (!this.grid.has(k)) {
      this.grid.set(k, [])
    }

    this.grid.get(k)!.push(obj)
  }

  queryRadius(x: number, y: number, radius: number): T[] {

    const result: T[] = []

    const minX = Math.floor((x - radius) / this.cellSize)
    const maxX = Math.floor((x + radius) / this.cellSize)
    const minY = Math.floor((y - radius) / this.cellSize)
    const maxY = Math.floor((y + radius) / this.cellSize)

    for (let gx = minX; gx <= maxX; gx++) {
      for (let gy = minY; gy <= maxY; gy++) {

        const key = gx + "," + gy
        const cell = this.grid.get(key)

        if (!cell) continue

        result.push(...cell)
      }
    }

    return result
  }
}
