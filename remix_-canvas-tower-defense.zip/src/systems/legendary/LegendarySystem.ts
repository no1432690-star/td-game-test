export class LegendarySystem {
  static LEGENDARY_CHANCE = 0.01;

  static tryRollLegendary(tower: any) {
    if (!tower) return;
    if (tower.isCorrupted) return;
    if (tower.isLegendary) return;

    const roll = Math.random();
    if (roll < this.LEGENDARY_CHANCE) {
      tower.isLegendary = true;
      
      // Optional UI notification
      if (typeof window !== 'undefined') {
        const event = new CustomEvent('legendary-discovered', { detail: { tower } });
        window.dispatchEvent(event);
      }
    }
  }
}
