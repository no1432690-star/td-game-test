export function applyLegendaryModifier(stats: any, tower: any) {
  if (!tower.isLegendary) return stats;

  const result = { ...stats };

  if (result.damage) result.damage *= 1.5;
  if (result.attackSpeed) result.attackSpeed *= 1.5;
  if (result.range) result.range *= 1.5;

  if (result.splashRadius) result.splashRadius *= 1.5;
  if (result.slowDuration) result.slowDuration *= 1.5;

  return result;
}
