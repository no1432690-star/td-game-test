export class MutationRewardSystem {
  static getShardDrop(enemyType: string) {
    if (enemyType === "mutated") {
      return 1 + Math.floor(Math.random() * 4);
    }
    if (enemyType === "firework_mutation") {
      return 1 + Math.floor(Math.random() * 2);
    }
    return 0;
  }
}
