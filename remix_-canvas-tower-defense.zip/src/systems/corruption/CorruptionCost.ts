export function getCorruptionCost(corruptedTowerCount: number) {
  const base = 100;
  return Math.floor(base * Math.pow(1.15, corruptedTowerCount));
}
