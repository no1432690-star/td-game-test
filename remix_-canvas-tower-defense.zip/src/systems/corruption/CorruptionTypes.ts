export enum CorruptionType {
  BLOOD_PACT = "blood_pact",
  OVERCLOCK = "overclock",
  FROZEN_CORE = "frozen_core",
  UNSTABLE_CORE = "unstable_core",
  FIREWORK = "firework"
}
