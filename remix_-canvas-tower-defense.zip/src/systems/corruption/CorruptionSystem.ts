import { CORRUPTION_DATA } from "./CorruptionData";

export class CorruptionSystem {
  static applyModifiers(towerStats: any, corruptionType: string) {
    if (!corruptionType) return towerStats;

    const data = (CORRUPTION_DATA as any)[corruptionType];
    if (!data) return towerStats;

    const result = { ...towerStats };

    if (data.damageMult) result.damage *= data.damageMult;
    if (data.attackSpeedMult) result.attackSpeed *= data.attackSpeedMult;
    if (data.rangeMult) result.range *= data.rangeMult;

    return result;
  }
}
