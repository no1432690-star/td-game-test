import { CorruptionType } from "./CorruptionTypes";

export const CORRUPTION_DATA = {
  [CorruptionType.BLOOD_PACT]: {
    damageMult: 1.5,
    attackSpeedMult: 0.4,
    rangeMult: 0.9
  },
  [CorruptionType.OVERCLOCK]: {
    attackSpeedMult: 1.5,
    damageMult: 0.6
  },
  [CorruptionType.FROZEN_CORE]: {
    slowDurationMult: 1.5,
    damageMult: 0.75,
    attackSpeedMult: 0.95
  },
  [CorruptionType.UNSTABLE_CORE]: {
    damageMult: 1.4,
    missChance: 0.2
  },
  [CorruptionType.FIREWORK]: {
    damageMult: 0.5,
    rangeMult: 1.25,
    splashMult: 1.25,
    projectileCount: 3,
    attackSpeedMult: 0.95
  }
};
