export const ENABLE_TOWER_MERGE = false;
