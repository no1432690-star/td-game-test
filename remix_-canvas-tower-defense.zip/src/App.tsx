/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { AudioSystem } from './game/systems/AudioSystem';
import { Game } from './game/core/Game';
import { CorruptedShardManager } from './game/systems/CorruptedShardManager';
import { CorruptionType } from './game/entities/Tower';
import { GameState } from './game/core/GameState';
import { Play, Pause, FastForward } from 'lucide-react';
import { DraftPanel } from './ui/DraftPanel';
import { PlacementOverlay } from './ui/PlacementOverlay';
import { TowerUpgradePanel } from './ui/towerPanel/TowerUpgradePanel';

import { GameOverOverlay } from './ui/GameOverOverlay';
import { EnemyStatsPanel } from './ui/EnemyStatsPanel';
import { RelicShopPanel } from './ui/RelicShopPanel';
import { metaSaveManager } from './core/MenuSystem';
import { DebugSpeed } from './game/debug/DebugSpeed';
import { ARTIFACT_DEFS } from './game/systems/artifactDefinitions';

const CanvasBorder = ({ isLegendary, isCorrupted }: { isLegendary: boolean, isCorrupted: boolean }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const draw = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      const { width, height } = canvas.getBoundingClientRect();
      if (width === 0 || height === 0) return;
      
      // Handle high DPI displays
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
      
      ctx.clearRect(0, 0, width, height);
      
      if (isLegendary) {
        const gradient = ctx.createLinearGradient(0, 0, width, height);
        gradient.addColorStop(0, '#FFF5CC');
        gradient.addColorStop(0.5, '#D4AF37');
        gradient.addColorStop(1, '#B8860B');
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 4;
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 15;
      } else if (isCorrupted) {
        const gradient = ctx.createLinearGradient(0, 0, width, height);
        gradient.addColorStop(0, '#6A0DAD');
        gradient.addColorStop(0.5, '#8A2BE2');
        gradient.addColorStop(1, '#4B0082');
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 4;
        ctx.shadowColor = '#8A2BE2';
        ctx.shadowBlur = 12;
      } else {
        return;
      }
      
      ctx.beginPath();
      if (ctx.roundRect) {
        ctx.roundRect(2, 2, width - 4, height - 4, 12); // 12px radius for rounded-xl
      } else {
        ctx.rect(2, 2, width - 4, height - 4);
      }
      ctx.stroke();
    };

    draw();
    
    const observer = new ResizeObserver(() => {
      draw();
    });
    observer.observe(canvas);
    
    return () => observer.disconnect();
  }, [isLegendary, isCorrupted]);
  
  if (!isLegendary && !isCorrupted) return null;
  
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none rounded-xl" style={{ zIndex: -1 }} />;
};

function formatStat(label: string, current: number, next?: number, suffix = "") {
  if (next === undefined) {
    return `${label}: ${current}${suffix}`;
  }

  const diff = next - current;

  return `${label}: ${current}${suffix} → ${next}${suffix} (+${diff.toFixed(2)})`;
}

function getNextMilestone(level: number, type: string) {
  const milestones = [5, 10, 15];
  const next = milestones.find(m => m > level);
  if (!next) return null;

  return `Next Milestone (Lv${next})`;
}

import { applyArtifactDamage } from './game/systems/artifactHooks';

function getTowerStats(tower: any) {
  const stats: any = {};
  
  const game = (window as any).gameInstance;
  const baseDmg = tower.damage || 0;
  const finalDmg = game ? applyArtifactDamage(baseDmg, game) : baseDmg;

  const current = {
    Damage: finalDmg,
    "Attack Speed": tower.attackSpeed,
    Range: tower.range,
    "Crit Chance": tower.flatCritChance + tower.critChance,
    "Crit Damage": tower.flatCritDamage,
    "Splash Radius": tower.flatSplashRadius,
    "Splash Damage": tower.flatSplashDamage,
    "Burn DPS": tower.flatBurnDamage,
    "Burn Duration": tower.flatBurnDuration,
    "Slow Effect": tower.flatSlowEffect,
    "Slow Duration": tower.flatSlowDuration,
    "Multi-target": tower.multiTargetSlow
  };

  Object.keys(current).forEach(k => {
    const val = (current as any)[k];
    if (val > 0 || k === 'Damage' || k === 'Attack Speed' || k === 'Range') {
      if (k === 'Splash Damage') {
        if (val !== undefined && tower.flatSplashRadius > 0) {
          stats[k] = Math.round(val * 100) + "%";
        }
      } else {
        stats[k] = Number.isInteger(val) ? val : Number(val.toFixed(2));
      }
    }
  });

  // Support future stats automatically
  Object.keys(tower).forEach(key => {
    if (typeof tower[key] === 'number' && !key.startsWith('_') && !key.startsWith('base') && !key.startsWith('flat') && !key.startsWith('bonus') && key !== 'level' && key !== 'maxLevel' && key !== 'baseCost' && key !== 'timer' && key !== 'fireRate' && key !== 'overclockDamagePenalty' && key !== 'damage' && key !== 'attackSpeed' && key !== 'range' && key !== 'critChance' && key !== 'critDamage' && key !== 'splashRadius' && key !== 'splashDamage' && key !== 'burnDamage' && key !== 'burnDuration' && key !== 'slowEffect' && key !== 'slowDuration' && key !== 'multiTargetSlow' && key !== 'x' && key !== 'y') {
      if (tower[key] > 0) {
        const name = key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1').trim();
        stats[name] = Number.isInteger(tower[key]) ? tower[key] : Number(tower[key].toFixed(2));
      }
    }
  });

  return stats;
}

function getPreviewStats(tower: any, gameRef: any) {
  if (tower.level >= tower.maxLevel) return null;
  
  const preview = Object.assign(Object.create(Object.getPrototypeOf(tower)), tower);
  preview.level++;
  preview.applyLevelScaling();
  preview.applyMilestoneBonuses();
  preview.recalculateFinalStats(gameRef.current!.runSystem.modifiers);
  
  return getTowerStats(preview);
}

export default function App({ continueRun = false }: { continueRun?: boolean }) {
  // ── Inject wave banner CSS once ─────────────────────────────────────────
  if (typeof document !== 'undefined' && !document.getElementById('td-wave-banner-css')) {
    const s = document.createElement('style');
    s.id = 'td-wave-banner-css';
    s.textContent = `
      @keyframes td-wb-in {
        from { opacity:0; transform:translateX(-50%) translateY(-20px) scale(.88); }
        to   { opacity:1; transform:translateX(-50%) translateY(0)     scale(1);   }
      }
      @keyframes td-wb-out {
        from { opacity:1; transform:translateX(-50%) translateY(0)     scale(1);   }
        to   { opacity:0; transform:translateX(-50%) translateY(-14px) scale(.94); }
      }
      @keyframes td-wb-shine {
        from { left:-60%; }
        to   { left:120%; }
      }
      @keyframes td-wb-boss-glow {
        0%,100% { box-shadow: 0 0 18px rgba(239,68,68,.4), 0 8px 32px rgba(0,0,0,.6); }
        50%     { box-shadow: 0 0 36px rgba(239,68,68,.7), 0 8px 40px rgba(0,0,0,.7); }
      }
      @keyframes td-wb-pulse {
        0%   { box-shadow: 0 0 0 0   rgba(239,68,68,.5); }
        70%  { box-shadow: 0 0 0 14px rgba(239,68,68,0);  }
        100% { box-shadow: 0 0 0 0   rgba(239,68,68,0);   }
      }
      .td-wb-normal {
        animation: td-wb-in .38s cubic-bezier(.34,1.56,.64,1) both;
      }
      .td-wb-normal.td-wb-hiding {
        animation: td-wb-out .3s ease both;
      }
      .td-wb-boss {
        animation: td-wb-in .38s cubic-bezier(.34,1.56,.64,1) both,
                   td-wb-boss-glow 2s ease-in-out infinite .4s,
                   td-wb-pulse     1.5s ease-out    infinite .5s;
      }
      .td-wb-boss.td-wb-hiding {
        animation: td-wb-out .3s ease both;
      }
      .td-wb-shine {
        position:absolute; top:0; left:-60%;
        width:40%; height:100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.07), transparent);
        animation: td-wb-shine .9s ease .25s both;
        pointer-events:none;
      }
      @keyframes td-heart-pulse {
        0%,100% { transform: scale(1);    filter: brightness(1);   }
        50%     { transform: scale(1.22); filter: brightness(1.4); }
      }
      @keyframes td-gold-fly-in {
        from { opacity:0; transform:translateY(6px) scale(.85); }
        to   { opacity:1; transform:translateY(0)   scale(1);   }
      }
      @keyframes td-gold-fly-out {
        from { opacity:1; transform:translateY(0)    scale(1);   }
        to   { opacity:0; transform:translateY(-18px) scale(.9); }
      }
      @keyframes td-arc-tick {
        from { stroke-dashoffset: 0; }
      }
      .td-heart-low {
        animation: td-heart-pulse 0.9s ease-in-out infinite;
        display: inline-block;
      }
      .td-gold-notif-in {
        animation: td-gold-fly-in .3s cubic-bezier(.34,1.56,.64,1) both;
      }
      .td-gold-notif-out {
        animation: td-gold-fly-out .4s ease both;
      }
      @keyframes td-leg-in {
        0%   { opacity:0; transform:translateX(-50%) translateY(-28px) scale(.8); }
        60%  { opacity:1; transform:translateX(-50%) translateY(4px) scale(1.04); }
        100% { opacity:1; transform:translateX(-50%) translateY(0) scale(1); }
      }
      @keyframes td-leg-out {
        from { opacity:1; transform:translateX(-50%) translateY(0) scale(1); }
        to   { opacity:0; transform:translateX(-50%) translateY(-18px) scale(.92); }
      }
      @keyframes td-leg-glow {
        0%,100% { box-shadow: 0 0 20px rgba(234,179,8,.3), 0 8px 40px rgba(0,0,0,.7); }
        50%     { box-shadow: 0 0 40px rgba(234,179,8,.6), 0 8px 50px rgba(0,0,0,.8); }
      }
      @keyframes td-leg-shine {
        from { left:-60%; }
        to   { left:130%; }
      }
      .td-leg-banner {
        animation: td-leg-in .5s cubic-bezier(.34,1.56,.64,1) both,
                   td-leg-glow 2.4s ease-in-out infinite .55s;
      }
      .td-leg-banner.td-leg-hiding {
        animation: td-leg-out .38s ease both;
      }
      .td-leg-shine-sweep {
        position:absolute; top:0; left:-60%;
        width:35%; height:100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.06), transparent);
        animation: td-leg-shine 1.1s ease .3s both;
        pointer-events:none; border-radius:inherit;
      }
    `;
    document.head.appendChild(s);
  }
  // ────────────────────────────────────────────────────────────────────────
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [showRelicShop, setShowRelicShop] = useState(false);
  const [legendaryNotification, setLegendaryNotification] = useState<{ towerName: string; hiding: boolean } | null>(null);
  const towerPanelRef = useRef<TowerUpgradePanel | null>(null);

  const [wavePopup, setWavePopup] = useState<{ wave: number, visible: boolean, hiding: boolean }>({ wave: 0, visible: false, hiding: false });
  const prevActiveRef = useRef(false);
  const goldAtWaveStartRef = useRef(0);
  const [goldNotif, setGoldNotif] = useState<{ delta: number; visible: boolean; hiding: boolean }>({ delta: 0, visible: false, hiding: false });

  useEffect(() => {
    const el = document.getElementById("tower-ui");
    if (el && !towerPanelRef.current) {
      towerPanelRef.current = new TowerUpgradePanel(el);
    }
    
    if (towerPanelRef.current) {
      if (gameState?.selectedTower && !gameState.isPlacingTower && gameRef.current?.selectedTower) {
        const rawTower = gameRef.current!.selectedTower!;
        const tower = (rawTower as any).baseTower || rawTower;
        
        towerPanelRef.current.showTower(
          tower,
          getTowerStats(tower),
          getPreviewStats(tower, gameRef),
          gameState.gold,
          (t: any) => {
            if (gameRef.current) {
              gameRef.current.upgradeSelectedTower();
              setGameState(gameRef.current.getState());
            }
          },
          (t: any) => {
            if (gameRef.current) {
              let types: any[] = [
                CorruptionType.UnstableCore,
                CorruptionType.BloodPact,
                CorruptionType.Overclock,
                CorruptionType.FrozenCore,
                CorruptionType.Firework
              ];
              if (gameRef.current.selectedTower?.constructor.name === 'Tesla') {
                types = ['Overloaded Core', 'Arc Reactor', 'Wild Current'];
              }
              const randomType = types[Math.floor(Math.random() * types.length)];
              gameRef.current.selectedTower?.applyCorruption(randomType);
              setGameState(gameRef.current.getState());
            }
          }
        );
      } else {
        const uiEl = document.getElementById("tower-ui");
        if (uiEl) uiEl.innerHTML = "";
      }
    }
  }, [gameState?.selectedTower, gameState?.isPlacingTower, gameState?.gold]);

  useEffect(() => {
    const handleLegendary = (e: any) => {
      const rawName: string = e?.detail?.tower?.constructor?.name ?? 'Tower';
      // Map internal class names to display names
      const nameMap: Record<string, string> = {
        Archer: 'Archer', Bomber: 'Bomber', Frost: 'Frost',
        Tesla: 'Tesla', CursedArcher: 'Cursed Archer',
      };
      const towerName = nameMap[rawName] ?? rawName;
      setLegendaryNotification({ towerName, hiding: false });
      // Start hide animation after 2.8s, remove after it completes
      setTimeout(() => {
        setLegendaryNotification(prev => prev ? { ...prev, hiding: true } : null);
        setTimeout(() => setLegendaryNotification(null), 400);
      }, 2800);
    };
    window.addEventListener('legendary-discovered', handleLegendary);
    return () => window.removeEventListener('legendary-discovered', handleLegendary);
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize game
    gameRef.current = new Game(canvasRef.current, continueRun);
    (window as any).gameInstance = gameRef.current;

    if (continueRun) {
      const loaded = gameRef.current.loadRunState();
      if (!loaded) {
        console.warn('[App] loadRunState failed, starting fresh');
      }
    }

    gameRef.current.start();

    // Poll game state for UI updates
    const interval = setInterval(() => {
      if (gameRef.current) {
        setGameState(gameRef.current.getState());
      }
    }, 100);

    // Cleanup
    return () => {
      clearInterval(interval);
      if (gameRef.current) {
        gameRef.current.destroy();
        gameRef.current = null;
        (window as any).gameInstance = null;
      }
    };
  }, [continueRun]);

  // Keybind handler: E = Upgrade, Q = Sell, R = Target, 1/2/3 = Select tower
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const game = gameRef.current;
      if (!game) return;

      // Allow ESC even when paused (to toggle pause)
      if (e.key === 'Escape') {
        e.preventDefault();
        if (game && !game.isGameOver) {
          game.togglePause();
          setGameState(game.getState());
        }
        return;
      }
      if (game.isPaused || game.isGameOver || game.intermissionMode !== 'None') return;

      // Block keys when typing in an input field
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;

      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          if (gameRef.current) {
            gameRef.current.togglePause();
            setGameState(gameRef.current.getState());
          }
          return;

        case 'e':
        case 'E':
          e.preventDefault();
          game.upgradeSelectedTower();
          setGameState(game.getState());
          break;

        case 'q':
        case 'Q':
          e.preventDefault();
          game.sellSelectedTower();
          setGameState(game.getState());
          break;

        case 'r':
        case 'R':
          e.preventDefault();
          game.cycleTowerTargetMode();
          setGameState(game.getState());
          break;

        case '1':
          e.preventDefault();
          game.selectTowerByIndex(0);
          setGameState(game.getState());
          break;

        case '2':
          e.preventDefault();
          game.selectTowerByIndex(1);
          setGameState(game.getState());
          break;

        case '3':
          e.preventDefault();
          game.selectTowerByIndex(2);
          setGameState(game.getState());
          break;

        case 'd':
        case 'D':
          if (e.shiftKey) {
            e.preventDefault();
            const btn = document.getElementById('debugX6Btn') as HTMLButtonElement | null;
            if (btn) {
              const isVisible = btn.style.display !== 'none';
              btn.style.display = isVisible ? 'none' : '';
            }
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (!gameState) return;
    
    // Wave started
    if (gameState.isWaveActive && !prevActiveRef.current) {
      goldAtWaveStartRef.current = gameState.gold;
      setWavePopup({ wave: gameState.wave, visible: true, hiding: false });
      // Start hide animation after 1.8s, remove after animation completes
      setTimeout(() => {
        setWavePopup(prev => ({ ...prev, hiding: true }));
        setTimeout(() => {
          setWavePopup(prev => ({ ...prev, visible: false, hiding: false }));
        }, 320);
      }, 1800);
    }

    // Wave ended → show gold earned notification
    if (!gameState.isWaveActive && prevActiveRef.current) {
      const earned = gameState.gold - goldAtWaveStartRef.current;
      if (earned > 0) {
        setGoldNotif({ delta: earned, visible: true, hiding: false });
        setTimeout(() => {
          setGoldNotif(prev => ({ ...prev, hiding: true }));
          setTimeout(() => {
            setGoldNotif(prev => ({ ...prev, visible: false, hiding: false }));
          }, 420);
        }, 1600);
      }
    }
    
    prevActiveRef.current = gameState.isWaveActive;
  }, [gameState?.isWaveActive, gameState?.wave]);

  const handleTogglePause = () => {
    if (gameRef.current) {
      gameRef.current.togglePause();
      setGameState(gameRef.current.getState());
    }
  };

  const handleSpeedChange = () => {
    if (gameRef.current && gameState) {
      const newSpeed = gameState.speedMultiplier === 1 ? 2 : 1;
      gameRef.current.setSpeed(newSpeed);
      setGameState(gameRef.current.getState());
    }
  };

  const handleUpgradeChoice = (choiceId: string) => {
    if (gameRef.current) {
      AudioSystem.instance.sfx('upgrade_pick');
      gameRef.current.applyUpgrade(choiceId);
      setGameState(gameRef.current.getState());
    }
  };

  const handleDraftSelect = (index: number) => {
    if (gameRef.current) {
      gameRef.current.selectDraft(index);
      setGameState(gameRef.current.getState());
    }
  };

  const getTowerCost = (type: string) => {
    const baseCosts: Record<string, number> = {
      Archer: 100,
      Bomber: 120,
      Frost: 110,
      CursedArcher: 110
    };
    const baseCost = baseCosts[type] || 100;
    return Math.floor(baseCost * (gameState?.costMultiplier || 1));
  };

  return (
    <div className="w-full h-screen bg-black flex flex-col items-center justify-center overflow-hidden relative font-sans">
      {/* Legendary Toast */}
      {legendaryNotification && (() => {
        const F = '"Segoe UI", system-ui, sans-serif';
        return (
          <div
            className={`td-leg-banner${legendaryNotification.hiding ? ' td-leg-hiding' : ''}`}
            style={{
              position: 'absolute',
              top: '72px', left: '50%',
              zIndex: 65, pointerEvents: 'none',
              background: 'linear-gradient(135deg, #1a1200, #0d0900)',
              border: '1px solid rgba(234,179,8,.5)',
              borderRadius: '14px', padding: '12px 32px',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              overflow: 'hidden', whiteSpace: 'nowrap',
              fontFamily: F,
            }}
          >
            {/* Top stripe */}
            <div style={{ position:'absolute', top:0, left:0, right:0, height:'2px', background:'linear-gradient(90deg,transparent,#eab308,#fde047,#eab308,transparent)' }} />
            {/* Shine sweep */}
            <div className="td-leg-shine-sweep" />
            {/* Label */}
            <div style={{ fontSize:'8px', letterSpacing:'4px', color:'#ca8a04', fontWeight:700, marginBottom:'3px' }}>
              ✦ LEGENDARY
            </div>
            {/* Tower name */}
            <div style={{ fontSize:'26px', fontWeight:800, color:'#fef08a', letterSpacing:'2px', lineHeight:1, textShadow:'0 0 24px rgba(234,179,8,.5)' }}>
              {legendaryNotification.towerName}
            </div>
            {/* Subtitle */}
            <div style={{ fontSize:'9px', letterSpacing:'2px', color:'#a16207', marginTop:'3px' }}>
              LEGENDARY TOWER DISCOVERED
            </div>
          </div>
        );
      })()}

      {/* Top Bar */}
      {gameState && (
        <div className="w-full bg-slate-900 border-b border-slate-800 p-3 flex items-center justify-between z-20 shrink-0 shadow-md">
          {/* Left: Resources */}
          <div className="flex gap-6 items-center">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-xs uppercase font-bold tracking-wider">Gold</span>
              <span className="text-amber-400 font-mono text-lg font-bold">{gameState.gold}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-xs uppercase font-bold tracking-wider">Lives</span>
              <div style={{ display:'flex', alignItems:'center', gap:'2px' }}>
                {(() => {
                  const lives = gameState.lives;
                  const isLow = lives <= 3;
                  const maxShow = 10;
                  const shown = Math.min(lives, maxShow);
                  const lost = Math.max(0, maxShow - lives);
                  const overflow = lives > maxShow ? lives - maxShow : 0;
                  return (
                    <>
                      {Array.from({ length: shown }).map((_, i) => (
                        <span
                          key={`full-${i}`}
                          className={isLow ? 'td-heart-low' : ''}
                          style={{
                            fontSize: '13px',
                            color: isLow ? '#ef4444' : '#f87171',
                            filter: isLow ? 'drop-shadow(0 0 4px rgba(239,68,68,.6))' : 'none',
                            animationDelay: isLow ? `${i * 0.12}s` : '0s',
                          }}
                        >♥</span>
                      ))}
                      {Array.from({ length: lost }).map((_, i) => (
                        <span key={`empty-${i}`} style={{ fontSize:'13px', color:'#2d4a6a' }}>♥</span>
                      ))}
                      {overflow > 0 && (
                        <span style={{ fontSize:'11px', color:'#f87171', fontWeight:700, marginLeft:'3px', fontFamily:'monospace' }}>
                          +{overflow}
                        </span>
                      )}
                    </>
                  );
                })()}
              </div>
            </div>
            
            {/* Buy Slot Button */}
            <button
              disabled={gameState.unlockedSlots >= gameState.maxSlots || gameState.gold < gameState.nextSlotPrice}
              onClick={() => {
                if (gameRef.current) {
                  gameRef.current.buySlot();
                  setGameState(gameRef.current.getState());
                }
              }}
              className={`ml-4 px-3 py-1 rounded border transition-colors flex items-center gap-2 ${
                gameState.unlockedSlots >= gameState.maxSlots
                  ? 'bg-slate-800 border-slate-700 text-slate-500 cursor-not-allowed'
                  : gameState.gold < gameState.nextSlotPrice
                    ? 'bg-slate-800 border-red-900/50 text-slate-500 cursor-not-allowed'
                    : 'bg-indigo-900/50 hover:bg-indigo-800/50 border-indigo-500/50 text-indigo-300 hover:text-indigo-200'
              }`}
            >
              <span className="text-[10px] uppercase font-bold tracking-wider">
                {gameState.unlockedSlots >= gameState.maxSlots ? 'Max Slots' : 'Unlock Slot'}
              </span>
              {gameState.unlockedSlots < gameState.maxSlots && (
                <span className="font-mono text-xs font-bold">{gameState.nextSlotPrice}g</span>
              )}
            </button>

            {/* Artifacts Display */}
            {gameState.artifacts && gameState.artifacts.length > 0 && (() => {
              const RARITY_STYLE: Record<string, { accent: string; bg: string; border: string; abbrev: (name: string) => string }> = {
                Rare:      { accent: '#a78bfa', bg: 'rgba(109,40,217,.18)',  border: 'rgba(139,92,246,.5)',  abbrev: n => n.split(' ').map(w => w[0]).join('').slice(0,3) },
                Gold:      { accent: '#fbbf24', bg: 'rgba(217,119,6,.18)',   border: 'rgba(251,191,36,.5)',  abbrev: n => n.split(' ').map(w => w[0]).join('').slice(0,3) },
                Legendary: { accent: '#fb923c', bg: 'rgba(194,65,12,.18)',   border: 'rgba(251,146,60,.5)',  abbrev: n => n.split(' ').map(w => w[0]).join('').slice(0,3) },
                Quality:   { accent: '#34d399', bg: 'rgba(5,150,105,.18)',   border: 'rgba(52,211,153,.5)',  abbrev: n => n.split(' ').map(w => w[0]).join('').slice(0,3) },
              };
              const F = '"Segoe UI", system-ui, sans-serif';
              return (
                <div style={{ display:'flex', alignItems:'center', gap:'6px', marginLeft:'16px' }}>
                  <span style={{ fontSize:'9px', letterSpacing:'3px', color:'#64748b', fontWeight:700, textTransform:'uppercase', fontFamily:F }}>Artifacts</span>
                  <div style={{ display:'flex', gap:'4px', flexWrap:'wrap', maxWidth:'200px' }}>
                    {gameState.artifacts.map(a => {
                      const def = ARTIFACT_DEFS[a.id];
                      if (!def) return null;
                      const rs = RARITY_STYLE[def.rarity] ?? RARITY_STYLE['Rare'];
                      const abbrev = rs.abbrev(def.name);
                      return (
                        <div
                          key={a.id}
                          style={{
                            position: 'relative',
                            width: '30px', height: '30px',
                            borderRadius: '8px',
                            background: rs.bg,
                            border: `1px solid ${rs.border}`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            cursor: 'help', fontFamily: F,
                          }}
                          className="group"
                        >
                          <span style={{ fontSize: abbrev.length > 2 ? '7px' : '9px', fontWeight: 800, color: rs.accent, letterSpacing: '-0.5px' }}>
                            {abbrev}
                          </span>
                          {a.stacks > 1 && (
                            <span style={{
                              position:'absolute', bottom:'-4px', right:'-4px',
                              background: rs.accent, color:'#000',
                              fontSize:'8px', fontWeight:800,
                              padding:'0 3px', borderRadius:'6px', lineHeight:'13px',
                              minWidth:'13px', textAlign:'center',
                            }}>{a.stacks}</span>
                          )}
                          {/* Hover tooltip */}
                          <div style={{
                            position:'absolute', top:'calc(100% + 6px)', left:'50%', transform:'translateX(-50%)',
                            width:'180px', padding:'8px 10px',
                            background:'#0a1525', border:`1px solid ${rs.border}`,
                            borderRadius:'10px', boxShadow:'0 8px 24px rgba(0,0,0,.7)',
                            pointerEvents:'none', zIndex:100, fontFamily:F,
                          }} className="opacity-0 group-hover:opacity-100 transition-opacity">
                            <div style={{ fontSize:'11px', fontWeight:800, color:rs.accent, marginBottom:'3px' }}>{def.name}</div>
                            <div style={{ fontSize:'10px', color:'#94a3b8', lineHeight:1.4, marginBottom:'4px' }}>{def.description}</div>
                            <div style={{ fontSize:'8px', letterSpacing:'2px', color:'#64748b', fontWeight:700 }}>{def.rarity.toUpperCase()}</div>
                            {a.stacks > 1 && (
                              <div style={{ fontSize:'9px', color:rs.accent, marginTop:'2px' }}>Stacks: ×{a.stacks}</div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Center: Wave Info */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-xs uppercase font-bold tracking-wider">Wave</span>
              <span className="text-white font-mono text-lg font-bold">{gameState.wave}</span>
            </div>
            {!gameState.isWaveActive && !gameState.pendingUpgrades && (() => {
              const maxDelay = 5;
              const remaining = Math.max(0, gameState.waveDelayTimer);
              const progress = Math.min(remaining / maxDelay, 1); // 1 = full, 0 = done
              const r = 14;
              const circ = 2 * Math.PI * r;
              const dash = circ * progress;
              const isUrgent = remaining <= 2;
              const arcColor = remaining > 3 ? '#34d399' : remaining > 1.5 ? '#facc15' : '#ef4444';
              const secs = Math.ceil(remaining);
              return (
                <div style={{ display:'flex', alignItems:'center', gap:'5px' }}>
                  <svg width="36" height="36" viewBox="0 0 36 36" style={{ transform:'rotate(-90deg)', overflow:'visible' }}>
                    {/* Track */}
                    <circle cx="18" cy="18" r={r} fill="none" stroke="rgba(255,255,255,.07)" strokeWidth="2.5" />
                    {/* Arc */}
                    <circle
                      cx="18" cy="18" r={r}
                      fill="none"
                      stroke={arcColor}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeDasharray={`${dash} ${circ}`}
                      style={{
                        filter: `drop-shadow(0 0 4px ${arcColor}88)`,
                        transition: 'stroke-dasharray 0.3s linear, stroke 0.4s ease',
                      }}
                    />
                    {/* Center text — counter-rotate to stay upright */}
                    <text
                      x="18" y="18"
                      dominantBaseline="central"
                      textAnchor="middle"
                      style={{ transform:'rotate(90deg)', transformOrigin:'18px 18px' }}
                      fill={arcColor}
                      fontSize="9"
                      fontWeight="700"
                      fontFamily='"Segoe UI", system-ui, sans-serif'
                    >{secs}</text>
                  </svg>
                  <span style={{
                    fontSize:'9px', letterSpacing:'2px', fontWeight:600,
                    color: isUrgent ? arcColor : '#64748b',
                    textTransform:'uppercase',
                    fontFamily:'"Segoe UI", system-ui, sans-serif',
                  }}>
                    {isUrgent ? 'INCOMING' : 'NEXT WAVE'}
                  </span>
                </div>
              );
            })()}
            {gameState.enemyScaling && (() => {
              const hpPct  = Math.round((gameState.enemyScaling!.hp    - 1) * 100);
              const spdPct = Math.round((gameState.enemyScaling!.speed - 1) * 100);
              const F = '"Segoe UI", system-ui, sans-serif';
              return (
                <div
                  style={{
                    display:'flex', gap:'8px', alignItems:'center',
                    background:'rgba(15,30,53,.8)', border:'1px solid rgba(255,255,255,.07)',
                    borderRadius:'8px', padding:'4px 10px', fontFamily:F,
                    position:'relative', cursor:'default',
                  }}
                  className="group"
                >
                  <span style={{ fontSize:'8px', letterSpacing:'2px', color:'#64748b', fontWeight:700 }}>ENEMIES</span>
                  <span style={{ fontSize:'11px', fontWeight:700, color:'#f87171', fontFamily:'monospace' }}>
                    HP +{hpPct}%
                  </span>
                  <span style={{ fontSize:'9px', color:'#4a6080' }}>·</span>
                  <span style={{ fontSize:'11px', fontWeight:700, color:'#38bdf8', fontFamily:'monospace' }}>
                    SPD +{spdPct}%
                  </span>
                  {/* Hover tooltip */}
                  <div style={{
                    position:'absolute', top:'calc(100% + 6px)', left:'50%', transform:'translateX(-50%)',
                    width:'200px', padding:'8px 10px',
                    background:'#0a1525', border:'1px solid rgba(255,255,255,.1)',
                    borderRadius:'10px', boxShadow:'0 8px 24px rgba(0,0,0,.8)',
                    pointerEvents:'none', zIndex:100, fontFamily:F,
                    whiteSpace:'normal',
                  }} className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <div style={{ fontSize:'9px', letterSpacing:'2px', color:'#64748b', fontWeight:700, marginBottom:'6px' }}>ENEMY SCALING</div>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'3px' }}>
                      <span style={{ fontSize:'10px', color:'#64748b' }}>Health</span>
                      <span style={{ fontSize:'10px', fontWeight:700, color:'#f87171' }}>+{hpPct}% vs Wave 1</span>
                    </div>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'6px' }}>
                      <span style={{ fontSize:'10px', color:'#64748b' }}>Speed</span>
                      <span style={{ fontSize:'10px', fontWeight:700, color:'#38bdf8' }}>+{spdPct}% vs Wave 1</span>
                    </div>
                    <div style={{ fontSize:'9px', color:'#4a6080', lineHeight:1.4 }}>
                      Enemies scale each wave. Build towers that deal percentage-based damage.
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Right: Controls */}
          <div className="flex gap-2">
            <button 
              onClick={handleTogglePause}
              disabled={!!gameState.pendingUpgrades}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-2 rounded border border-slate-600 transition-colors flex items-center justify-center"
            >
              {gameState.isPaused && !gameState.pendingUpgrades ? <Play size={16} /> : <Pause size={16} />}
            </button>
            <button 
              onClick={handleSpeedChange}
              disabled={!!gameState.pendingUpgrades}
              className={`p-2 rounded border transition-colors flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${
                gameState.speedMultiplier > 1 
                  ? 'bg-blue-600 hover:bg-blue-500 border-blue-400 text-white' 
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-300'
              }`}
            >
              <FastForward size={16} />
              <span className="font-mono font-bold text-xs">{gameState.speedMultiplier}x</span>
            </button>
            <button
              id="debugX6Btn"
              onClick={(e) => {
                DebugSpeed.toggle();
                setGameState(gameRef.current?.getState() || gameState);
              }}
              disabled={!!gameState.pendingUpgrades}
              className={`p-2 rounded border transition-colors font-mono font-bold text-xs disabled:opacity-50 disabled:cursor-not-allowed ${
                DebugSpeed.enabled
                  ? 'bg-purple-600 hover:bg-purple-500 border-purple-400 text-white' 
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-300'
              }`}
            >
              x{DebugSpeed.enabled ? '6' : '6'}
            </button>
          </div>
        </div>
      )}

      {/* Wave Start Banner */}
      {wavePopup.visible && (() => {
        const w = wavePopup.wave;
        // Boss waves: 5, 10, 15, then every 5 waves after 15
        const isBoss = w === 5 || w === 10 || w === 15 || (w > 15 && w % 5 === 0);
        const F = '"Segoe UI", system-ui, sans-serif';

        if (isBoss) {
          return (
            <div
              className={`td-wb-boss${wavePopup.hiding ? ' td-wb-hiding' : ''}`}
              style={{
                position: 'absolute',
                top: '72px', left: '50%',
                zIndex: 60, pointerEvents: 'none',
                background: 'linear-gradient(135deg,#1a0508,#0d0205)',
                border: '1px solid rgba(239,68,68,.5)',
                borderRadius: '14px', padding: '12px 36px',
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                overflow: 'hidden', whiteSpace: 'nowrap',
                fontFamily: F,
              }}
            >
              {/* Top stripe */}
              <div style={{ position:'absolute', top:0, left:0, right:0, height:'2px', background:'linear-gradient(90deg,transparent,#dc2626,#f87171,#dc2626,transparent)' }} />
              {/* Shine */}
              <div className="td-wb-shine" />
              <div style={{ fontSize:'8px', letterSpacing:'4px', color:'#f87171', fontWeight:700, marginBottom:'3px' }}>
                ⚠ BOSS WAVE
              </div>
              <div style={{ fontSize:'30px', fontWeight:800, color:'#f8fafc', letterSpacing:'2px', lineHeight:1, textShadow:'0 0 20px rgba(239,68,68,.4)' }}>
                Wave {w}
              </div>
              <div style={{ fontSize:'9px', letterSpacing:'2px', color:'#b91c1c', marginTop:'3px' }}>
                BOSS INCOMING
              </div>
              <div style={{ fontSize:'9px', color:'#f87171', marginTop:'5px', letterSpacing:'1px' }}>
                ⚠ Prepare your defenses
              </div>
            </div>
          );
        }

        return (
          <div
            className={`td-wb-normal${wavePopup.hiding ? ' td-wb-hiding' : ''}`}
            style={{
              position: 'absolute',
              top: '72px', left: '50%',
              zIndex: 60, pointerEvents: 'none',
              background: 'linear-gradient(135deg,#0f1e35,#0a1525)',
              border: '1px solid rgba(250,204,21,.32)',
              borderRadius: '14px', padding: '10px 32px',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              overflow: 'hidden', whiteSpace: 'nowrap',
              boxShadow: '0 0 20px rgba(250,204,21,.12), 0 8px 32px rgba(0,0,0,.6)',
              fontFamily: F,
            }}
          >
            {/* Top stripe */}
            <div style={{ position:'absolute', top:0, left:0, right:0, height:'1px', background:'linear-gradient(90deg,transparent,rgba(250,204,21,.6),transparent)' }} />
            {/* Shine */}
            <div className="td-wb-shine" />
            <div style={{ fontSize:'8px', letterSpacing:'4px', color:'#facc15', fontWeight:700, marginBottom:'3px' }}>
              WAVE START
            </div>
            <div style={{ fontSize:'28px', fontWeight:800, color:'#f8fafc', letterSpacing:'2px', lineHeight:1 }}>
              Wave {w}
            </div>
            <div style={{ fontSize:'9px', letterSpacing:'2px', color:'#64748b', marginTop:'3px' }}>
              ENEMIES INCOMING
            </div>
          </div>
        );
      })()}

      {/* Gold Earned Notification */}
      {goldNotif.visible && (
        <div
          className={goldNotif.hiding ? 'td-gold-notif-out' : 'td-gold-notif-in'}
          style={{
            position: 'absolute',
            top: '72px', left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 55, pointerEvents: 'none',
            display: 'flex', alignItems: 'center', gap: '6px',
            background: 'linear-gradient(135deg, #1a2e0a, #0f1e06)',
            border: '1px solid rgba(74,222,128,.35)',
            borderRadius: '20px', padding: '6px 18px',
            boxShadow: '0 0 16px rgba(74,222,128,.15), 0 6px 24px rgba(0,0,0,.5)',
            fontFamily: '"Segoe UI", system-ui, sans-serif',
            whiteSpace: 'nowrap',
          }}
        >
          <span style={{ fontSize: '13px', color: '#facc15' }}>✦</span>
          <span style={{ fontSize: '15px', fontWeight: 800, color: '#4ade80', letterSpacing: '1px' }}>
            +{goldNotif.delta}
          </span>
          <span style={{ fontSize: '9px', letterSpacing: '2px', color: '#16a34a', fontWeight: 700 }}>
            GOLD
          </span>
        </div>
      )}

      {/* Game Area */}
      <div className="flex-1 w-full flex items-center justify-center p-4 relative">
        <div className="relative w-full h-full max-w-[1600px] max-h-[90vh] aspect-video bg-slate-900 shadow-2xl border border-slate-800 rounded-xl overflow-hidden">
          <canvas
            ref={canvasRef}
            className="block w-full h-full"
          />
        {gameState?.isPaused && !gameState.pendingUpgrades && !gameState.isGameOver && (
          <div
            style={{
              position: 'absolute', inset: '0',
              background: 'rgba(6,11,20,.75)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              zIndex: 9000,
              fontFamily: '"Segoe UI", system-ui, sans-serif',
            }}
            onClick={(e) => { if (e.target === e.currentTarget) { gameRef.current?.togglePause(); setGameState(gameRef.current!.getState()); } }}
          >
            <div style={{
              background: 'linear-gradient(160deg,#0f1e35,#0a1525)',
              border: '1px solid rgba(250,204,21,.18)',
              borderRadius: '18px', padding: '32px 36px',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              width: '320px', position: 'relative',
              boxShadow: '0 30px 80px rgba(0,0,0,.8)',
            }}>
              {/* Corner decorations */}
              {[
                { top:'11px', left:'13px' },
                { top:'11px', right:'13px', borderLeft:'none', borderRight:'2px solid rgba(250,204,21,.3)' },
                { bottom:'11px', left:'13px', borderTop:'none', borderBottom:'2px solid rgba(250,204,21,.3)' },
                { bottom:'11px', right:'13px', borderTop:'none', borderLeft:'none', borderBottom:'2px solid rgba(250,204,21,.3)', borderRight:'2px solid rgba(250,204,21,.3)' },
              ].map((s, i) => (
                <div key={i} style={{ position:'absolute', width:'9px', height:'9px', borderTop:'2px solid rgba(250,204,21,.3)', borderLeft:'2px solid rgba(250,204,21,.3)', ...s }} />
              ))}

              {/* Title */}
              <div style={{ fontSize:'10px', letterSpacing:'5px', color:'#facc15', fontWeight:'700', marginBottom:'12px' }}>PAUSED</div>
              <div style={{ fontSize:'26px', fontWeight:'800', color:'#f8fafc', marginBottom:'4px' }}>Wave {gameState.wave}</div>
              <div style={{ fontSize:'9px', letterSpacing:'2px', color:'#64748b', marginBottom:'22px' }}>GAME PAUSED · TIME FROZEN</div>

              {/* Resume */}
              <button
                onClick={() => { gameRef.current?.togglePause(); setGameState(gameRef.current!.getState()); }}
                style={{ width:'100%', padding:'11px', borderRadius:'10px', border:'1px solid rgba(217,119,6,.6)', background:'linear-gradient(135deg,#d97706,#b45309)', color:'#fff', fontSize:'13px', fontWeight:'700', cursor:'pointer', marginBottom:'8px', fontFamily:'inherit', letterSpacing:'1px' }}
              >▶ &nbsp;Resume</button>

              {/* Enemy Strengths toggle */}
              <button
                onClick={() => {
                  const el = document.getElementById('td-pause-enemy-panel');
                  if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
                }}
                style={{ width:'100%', padding:'11px', borderRadius:'10px', border:'1px solid rgba(56,189,248,.25)', background:'rgba(56,189,248,.1)', color:'#38bdf8', fontSize:'13px', fontWeight:'500', cursor:'pointer', marginBottom:'8px', fontFamily:'inherit' }}
              >👁 &nbsp;Enemy Strengths</button>

              {/* Enemy panel (hidden by default) */}
              <div id="td-pause-enemy-panel" style={{ width:'100%', display:'none', marginBottom:'8px' }}>
                <div style={{ background:'#0f1e35', border:'1px solid rgba(255,255,255,.08)', borderRadius:'10px', padding:'10px' }}>
                  {[
                    { name:'Grunt',            color:'#ef4444', stroke:'#991b1b', shape:'circle', boss:false },
                    { name:'Runner',           color:'#eab308', stroke:'#854d0e', shape:'tri',    boss:false },
                    { name:'Tank',             color:'#6b7280', stroke:'#374151', shape:'square', boss:false },
                    { name:'Boss: Titan',      color:'#ef4444', stroke:'#fff',    shape:'circle', boss:true  },
                    { name:'Boss: Swift',      color:'#eab308', stroke:'#fff',    shape:'tri',    boss:true  },
                    { name:'Boss: Juggernaut', color:'#6b7280', stroke:'#fff',    shape:'square', boss:true  },
                  ].map((e, i) => {
                    const hp = Math.round((gameState.enemyScaling?.hp || 1) * (e.boss ? 400 : e.name==='Tank'?200:e.name==='Runner'?48:80));
                    return (
                      <div key={i} style={{ display:'flex', alignItems:'center', gap:'8px', padding:'5px 6px', borderRadius:'7px', marginBottom:'4px', background: e.boss?'rgba(239,68,68,.06)':'rgba(255,255,255,.02)', border:`1px solid ${e.boss?'rgba(239,68,68,.15)':'rgba(255,255,255,.05)'}` }}>
                        <svg viewBox="0 0 24 24" style={{ width:'20px', height:'20px', flexShrink:0 }}>
                          {e.shape==='circle' && <circle cx="12" cy="12" r="9" fill={e.color} stroke={e.stroke} strokeWidth={e.boss?2.5:1.5}/>}
                          {e.shape==='tri'    && <polygon points="12,2 22,22 2,22" fill={e.color} stroke={e.stroke} strokeWidth={e.boss?2.5:1.5}/>}
                          {e.shape==='square' && <rect x="2" y="2" width="20" height="20" fill={e.color} stroke={e.stroke} strokeWidth={e.boss?2.5:1.5}/>}
                        </svg>
                        <span style={{ fontSize:'11px', color: e.boss?'#f87171':'#e2e8f0', fontWeight:'600', flex:1 }}>{e.boss?'⚠ ':''}{e.name}</span>
                        <span style={{ fontSize:'10px', color:'#64748b' }}>HP <span style={{ color:'#facc15', fontWeight:'600' }}>{hp.toLocaleString()}</span></span>
                      </div>
                    );
                  })}
                  <div style={{ fontSize:'9px', color:'#64748b', marginTop:'6px', paddingTop:'6px', borderTop:'1px solid rgba(255,255,255,.05)' }}>
                    HP values approximate for current wave
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div style={{ width:'100%', height:'1px', background:'rgba(255,255,255,.07)', margin:'4px 0 10px' }} />

              {/* Library */}
              <button
                onClick={() => {
                  gameRef.current?.togglePause();
                  setGameState(gameRef.current!.getState());
                  setTimeout(() => {
                    const lib = (window as any).__createLibraryMenu?.(() => {
                      document.body.removeChild(lib);
                      gameRef.current?.togglePause();
                      setGameState(gameRef.current!.getState());
                    });
                    if (lib) document.body.appendChild(lib);
                  }, 50);
                }}
                style={{ width:'100%', padding:'9px', borderRadius:'10px', border:'1px solid rgba(34,197,94,.2)', background:'rgba(34,197,94,.08)', color:'#34d399', fontSize:'12px', fontWeight:'500', cursor:'pointer', marginBottom:'8px', fontFamily:'inherit' }}
              >📚 &nbsp;Library</button>

              {/* Exit */}
              <button
                onClick={() => { if (window.confirm('Exit this run? Your progress will be lost.')) location.reload(); }}
                style={{ width:'100%', padding:'9px', borderRadius:'10px', border:'1px solid rgba(239,68,68,.18)', background:'rgba(239,68,68,.07)', color:'#f87171', fontSize:'12px', fontWeight:'500', cursor:'pointer', marginBottom:'0', fontFamily:'inherit' }}
              >✕ &nbsp;Exit Run</button>

              <div style={{ fontSize:'9px', color:'#4a6080', marginTop:'10px' }}>Press ESC to resume</div>
            </div>
          </div>
        )}
        
        {/* Game Over Overlay */}
        {gameState?.intermissionMode === 'GameOver' && !showRelicShop && (
          <GameOverOverlay
            wave={gameState.wave}
            gold={gameState.gold}
            onRestart={() => {
              if (gameRef.current) {
                const canvas = document.querySelector('canvas') as HTMLCanvasElement | null;
                if (canvas) canvas.style.filter = '';
                gameRef.current.restart();
                setGameState(gameRef.current.getState());
              }
            }}
            onMenu={() => location.reload()}
            onRelicShop={() => setShowRelicShop(true)}
          />
        )}

        {/* Relic Shop Overlay */}
        {showRelicShop && (
          <div style={{ position: 'absolute', inset: 0, zIndex: 60, background: 'rgba(0,0,0,0.9)' }}>
            <div style={{ position: 'absolute', top: '16px', right: '16px', zIndex: 70 }}>
              <button 
                onClick={() => setShowRelicShop(false)}
                style={{ padding: '8px 16px', background: '#334155', color: 'white', borderRadius: '8px', fontWeight: 'bold' }}
              >
                Back to Game Over
              </button>
            </div>
            <RelicShopPanel 
              voidEssence={metaSaveManager.getSave().voidEssence || 0}
              relicShop={metaSaveManager.getSave().relicShop}
              currentWave={metaSaveManager.getSave().statistics?.highestWave || 0}
              voidEssenceHistory={metaSaveManager.getSave().voidEssenceHistory}
              onPurchaseRelic={(relicId) => {
                if (gameRef.current) {
                  gameRef.current.relicShopSystem.purchaseRelic(relicId);
                  // Force a re-render to update the UI
                  setGameState({ ...gameRef.current.getState() });
                }
              }}
              onResetRelic={(relicId) => {
                if (gameRef.current) {
                  gameRef.current.relicShopSystem.resetRelic(relicId);
                  setGameState({ ...gameRef.current.getState() });
                }
              }}
            />
          </div>
        )}

        {/* Starter Tower Overlay */}
        {gameState?.starterTowerActive && gameState?.starterTowerChoices && (() => {
          const F = '"Segoe UI", system-ui, sans-serif';
          const TOWER_META: Record<string, { icon: string; accent: string; glow: string; role: string; dmg: string; rng: string; cd: string; special: string }> = {
            Archer:      { icon: '🏹', accent: '#22c55e', glow: 'rgba(34,197,94,.25)',  role: 'Single Target · DPS',   dmg: '10', rng: '160', cd: '0.8s', special: 'Crit' },
            Bomber:      { icon: '💣', accent: '#f97316', glow: 'rgba(249,115,22,.25)', role: 'AoE · Crowd Control',   dmg: '40', rng: '130', cd: '2.4s', special: 'Splash' },
            Frost:       { icon: '❄️', accent: '#38bdf8', glow: 'rgba(56,189,248,.25)', role: 'Support · Slow',        dmg: '10', rng: '100', cd: '1.2s', special: 'Slow 50%' },
            Tesla:       { icon: '⚡', accent: '#facc15', glow: 'rgba(250,204,21,.25)', role: 'Network · Buff',        dmg: '5',  rng: '150', cd: '1.4s', special: 'Chain' },
            CursedArcher:{ icon: '💀', accent: '#a855f7', glow: 'rgba(168,85,247,.25)', role: 'Curse · Scaling',       dmg: '15', rng: '160', cd: '0.9s', special: 'Mark' },
          };

          return (
            <div style={{
              position: 'absolute', inset: 0,
              background: 'rgba(6,11,20,.92)',
              backdropFilter: 'blur(8px)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              padding: '32px', zIndex: 50, fontFamily: F,
            }}>
              {/* Header */}
              <div style={{ textAlign: 'center', marginBottom: '28px' }}>
                <div style={{ display: 'inline-block', background: 'rgba(250,204,21,.12)', border: '1px solid rgba(250,204,21,.3)', borderRadius: '20px', padding: '4px 16px', fontSize: '10px', letterSpacing: '4px', color: '#facc15', fontWeight: 700, marginBottom: '12px' }}>
                  GAME START
                </div>
                <div style={{ fontSize: '32px', fontWeight: 800, color: '#f8fafc', letterSpacing: '1px', lineHeight: 1 }}>
                  Choose Your Starter
                </div>
                <div style={{ fontSize: '10px', letterSpacing: '3px', color: '#64748b', marginTop: '6px' }}>
                  SELECT ONE TOWER TO BEGIN · FREE PLACEMENT
                </div>
              </div>

              {/* Tower Cards */}
              <div style={{ display: 'flex', gap: '16px', maxWidth: '1000px', width: '100%', justifyContent: 'center', flexWrap: 'wrap' }}>
                {gameState.starterTowerChoices.map((towerType, index) => {
                  const meta = TOWER_META[towerType] || { icon: '🗼', accent: '#64748b', glow: 'rgba(100,116,139,.2)', role: 'Tower', dmg: '?', rng: '?', cd: '?', special: '-' };
                  return (
                    <button
                      key={index}
                      onClick={() => {
                        if (gameRef.current) {
                          gameRef.current.selectStarterTower(index);
                          setGameState(gameRef.current.getState());
                        }
                      }}
                      style={{
                        flex: '1', minWidth: '180px', maxWidth: '220px',
                        background: 'linear-gradient(160deg, #0f1e35, #0a1525)',
                        border: `1px solid ${meta.accent}55`,
                        borderRadius: '16px', padding: '20px 16px 16px',
                        display: 'flex', flexDirection: 'column', alignItems: 'center',
                        cursor: 'pointer', fontFamily: F, transition: 'all .18s',
                        boxShadow: `0 0 0 0 ${meta.glow}`,
                        position: 'relative', overflow: 'hidden',
                      }}
                      onMouseEnter={e => {
                        (e.currentTarget as HTMLButtonElement).style.border = `1px solid ${meta.accent}cc`;
                        (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-3px)';
                        (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 12px 32px ${meta.glow}`;
                      }}
                      onMouseLeave={e => {
                        (e.currentTarget as HTMLButtonElement).style.border = `1px solid ${meta.accent}55`;
                        (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                        (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 0 0 0 ${meta.glow}`;
                      }}
                    >
                      {/* Top accent stripe */}
                      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '2px', background: `linear-gradient(90deg, transparent, ${meta.accent}, transparent)` }} />

                      {/* Icon */}
                      <div style={{
                        width: '56px', height: '56px', borderRadius: '14px',
                        background: `${meta.accent}18`, border: `1px solid ${meta.accent}44`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '26px', marginBottom: '10px',
                      }}>{meta.icon}</div>

                      {/* Name */}
                      <div style={{ fontSize: '17px', fontWeight: 800, color: meta.accent, marginBottom: '3px', letterSpacing: '.5px' }}>
                        {towerType}
                      </div>

                      {/* Role */}
                      <div style={{ fontSize: '9px', color: '#64748b', letterSpacing: '2px', marginBottom: '12px', textTransform: 'uppercase' }}>
                        {meta.role}
                      </div>

                      {/* Stats */}
                      <div style={{ width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5px', marginBottom: '14px' }}>
                        {[
                          { label: 'DMG', value: meta.dmg },
                          { label: 'RNG', value: meta.rng },
                          { label: 'CD',  value: meta.cd },
                          { label: '',    value: meta.special, special: true },
                        ].map((s, i) => (
                          <div key={i} style={{
                            background: 'rgba(255,255,255,.03)', border: '1px solid rgba(255,255,255,.06)',
                            borderRadius: '8px', padding: '5px 6px', textAlign: 'center',
                          }}>
                            {s.label && <div style={{ fontSize: '8px', color: '#64748b', letterSpacing: '1px', marginBottom: '1px' }}>{s.label}</div>}
                            <div style={{ fontSize: s.special ? '9px' : '13px', fontWeight: 700, color: s.special ? meta.accent : '#e2e8f0' }}>{s.value}</div>
                          </div>
                        ))}
                      </div>

                      {/* Select Button */}
                      <div style={{
                        width: '100%', padding: '8px', borderRadius: '10px',
                        background: `${meta.accent}22`, border: `1px solid ${meta.accent}66`,
                        color: meta.accent, fontSize: '12px', fontWeight: 700,
                        letterSpacing: '1px', textAlign: 'center',
                      }}>Select</div>
                      <div style={{ fontSize: '8px', color: '#4a6080', marginTop: '5px', letterSpacing: '1px' }}>FREE PLACEMENT</div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })()}

        {/* Artifact Shop Overlay */}
        {gameState?.intermissionMode === 'Artifact' && gameState?.pendingArtifacts && (() => {
          const F = '"Segoe UI", system-ui, sans-serif';
          const RARITY_META: Record<string, { label: string; accent: string; bg: string; border: string; glow: string }> = {
            Rare:      { label: 'RARE',      accent: '#a78bfa', bg: 'rgba(109,40,217,.12)',  border: 'rgba(139,92,246,.4)',  glow: 'rgba(139,92,246,.15)' },
            Gold:      { label: 'GOLD',      accent: '#fbbf24', bg: 'rgba(217,119,6,.12)',   border: 'rgba(251,191,36,.4)',  glow: 'rgba(251,191,36,.15)' },
            Legendary: { label: 'LEGENDARY', accent: '#fb923c', bg: 'rgba(194,65,12,.12)',   border: 'rgba(251,146,60,.4)',  glow: 'rgba(251,146,60,.15)' },
            Quality:   { label: 'QUALITY',   accent: '#34d399', bg: 'rgba(5,150,105,.12)',   border: 'rgba(52,211,153,.4)',  glow: 'rgba(52,211,153,.15)' },
          };

          const rerollCost = gameState.artifactShopRerollCost ?? 500_000;
          const canReroll = (gameState.canRerollArtifact ?? true) && gameState.gold >= rerollCost;
          const rerollCount = gameState.artifactShopRerollCount ?? 0;
          const nextShopWave = gameState.wave + (10 - ((gameState.wave - 40) % 10));

          return (
            <div style={{
              position: 'absolute', inset: 0,
              background: 'rgba(6,11,20,.92)', backdropFilter: 'blur(8px)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              padding: '24px', zIndex: 50, fontFamily: F,
            }}>
              {/* Header */}
              <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                <div style={{ display: 'inline-block', background: 'rgba(250,204,21,.12)', border: '1px solid rgba(250,204,21,.3)', borderRadius: '20px', padding: '4px 16px', fontSize: '10px', letterSpacing: '4px', color: '#facc15', fontWeight: 700, marginBottom: '10px' }}>
                  ARTIFACT SHOP
                </div>
                <div style={{ fontSize: '28px', fontWeight: 800, color: '#facc15', letterSpacing: '1px', lineHeight: 1 }}>
                  Wave {gameState.wave} · Shop Open
                </div>
                <div style={{ fontSize: '9px', letterSpacing: '3px', color: '#64748b', marginTop: '5px' }}>
                  PURCHASE ONE ARTIFACT TO ENHANCE YOUR RUN
                </div>
              </div>

              {/* Pricing info banner */}
              <div style={{
                maxWidth: '820px', width: '100%',
                background: 'rgba(250,204,21,.06)', border: '1px solid rgba(250,204,21,.15)',
                borderRadius: '10px', padding: '8px 14px', marginBottom: '16px',
                display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '11px', color: '#64748b',
              }}>
                <span style={{ color: '#facc15', fontSize: '13px', flexShrink: 0 }}>💡</span>
                <span>
                  <strong style={{ color: '#94a3b8' }}>Pricing system:</strong> Mỗi artifact có giá khởi điểm riêng (tối thiểu 5,000,000g).
                  Mỗi lần mua, giá <strong style={{ color: '#facc15' }}>nhân đôi</strong>. Shop mở lại mỗi 10 wave (wave 40, 50, 60...).
                  Reroll tối đa <strong style={{ color: '#94a3b8' }}>2 lần/shop</strong>, giá tăng gấp đôi mỗi lần.
                </span>
              </div>

              {/* Artifact Cards */}
              <div style={{ display: 'flex', gap: '14px', maxWidth: '820px', width: '100%', justifyContent: 'center', marginBottom: '16px' }}>
                {gameState.pendingArtifacts.map((artifact) => {
                  const price = artifact.basePrice * Math.pow(2, artifact.purchaseCount);
                  const canAfford = gameState.gold >= price;
                  const ownedCount = artifact.purchaseCount;
                  const def = (window as any).ARTIFACT_DEFS_REF?.[artifact.id];
                  const rarityKey = def?.rarity ?? 'Rare';
                  const rm = RARITY_META[rarityKey] ?? RARITY_META['Rare'];
                  const isMaxed = def?.hardCap && ownedCount >= def.hardCap;

                  return (
                    <div
                      key={artifact.id}
                      style={{
                        flex: 1, minWidth: '220px', maxWidth: '260px',
                        background: `linear-gradient(160deg, #0f1e35, #0a1525)`,
                        border: `1px solid ${canAfford && !isMaxed ? rm.border : 'rgba(255,255,255,.08)'}`,
                        borderRadius: '14px', padding: '16px',
                        display: 'flex', flexDirection: 'column',
                        opacity: canAfford && !isMaxed ? 1 : 0.55,
                        boxShadow: canAfford && !isMaxed ? `0 0 20px ${rm.glow}` : 'none',
                        position: 'relative', overflow: 'hidden',
                      }}
                    >
                      {/* Top accent */}
                      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '2px', background: `linear-gradient(90deg, transparent, ${rm.accent}, transparent)` }} />

                      {/* Rarity badge */}
                      <div style={{
                        display: 'inline-block', alignSelf: 'flex-start',
                        background: rm.bg, border: `1px solid ${rm.border}`,
                        borderRadius: '6px', padding: '2px 8px',
                        fontSize: '8px', letterSpacing: '2px', color: rm.accent, fontWeight: 700,
                        marginBottom: '8px',
                      }}>{rm.label}</div>

                      {/* Name */}
                      <div style={{ fontSize: '16px', fontWeight: 800, color: rm.accent, marginBottom: '6px', lineHeight: 1.2 }}>
                        {ownedCount > 0 && <span style={{ marginRight: '5px' }}>✦</span>}
                        {artifact.name}
                      </div>

                      {/* Description */}
                      <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '10px', lineHeight: 1.5, flex: 1 }}>
                        {artifact.description}
                      </div>

                      {/* Owned indicator */}
                      <div style={{ fontSize: '10px', marginBottom: '8px' }}>
                        {ownedCount > 0
                          ? <span style={{ color: rm.accent }}>● Owned ×{ownedCount}{!isMaxed ? ' — add stack' : ' (maxed)'}</span>
                          : <span style={{ color: '#64748b' }}>○ Not owned</span>
                        }
                      </div>

                      {/* Price */}
                      <div style={{ fontSize: '18px', fontWeight: 800, color: canAfford ? rm.accent : '#ef4444', marginBottom: '2px', fontFamily: 'monospace' }}>
                        {price.toLocaleString()}g
                      </div>
                      {ownedCount > 0 && (
                        <div style={{ fontSize: '9px', color: '#64748b', marginBottom: '8px' }}>
                          ×2 price (owned ×{ownedCount})
                        </div>
                      )}
                      {!ownedCount && (
                        <div style={{ fontSize: '9px', color: '#64748b', marginBottom: '8px' }}>
                          Base price · ×2 after each purchase
                        </div>
                      )}

                      {/* Action button */}
                      <button
                        onClick={() => {
                          if (canAfford && !isMaxed && gameRef.current) {
                            gameRef.current.gold = gameRef.current.artifactSystem.purchaseArtifact(artifact.id, gameState.gold, gameRef.current);
                            gameRef.current.finishArtifactPhase();
                            setGameState(gameRef.current.getState());
                          }
                        }}
                        disabled={!canAfford || !!isMaxed}
                        style={{
                          width: '100%', padding: '9px', borderRadius: '9px', fontFamily: F,
                          border: `1px solid ${canAfford && !isMaxed ? rm.border : 'rgba(255,255,255,.08)'}`,
                          background: canAfford && !isMaxed ? rm.bg : 'rgba(255,255,255,.03)',
                          color: canAfford && !isMaxed ? rm.accent : '#64748b',
                          fontSize: '12px', fontWeight: 700, cursor: canAfford && !isMaxed ? 'pointer' : 'not-allowed',
                          letterSpacing: '.5px',
                        }}
                      >
                        {isMaxed ? 'Maxed' : !canAfford ? 'Cannot Afford' : ownedCount > 0 ? `Stack (+1)` : 'Purchase'}
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Bottom actions */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', maxWidth: '820px', width: '100%' }}>
                <div style={{ display: 'flex', gap: '10px', width: '100%' }}>
                  {/* Reroll button */}
                  <button
                    onClick={() => {
                      if (canReroll && gameRef.current) {
                        gameRef.current.gold -= rerollCost;
                        gameRef.current.artifactSystem.rerollChoices();
                        setGameState(gameRef.current.getState());
                      }
                    }}
                    disabled={!canReroll}
                    style={{
                      flex: 1, padding: '11px', borderRadius: '10px', fontFamily: F,
                      border: `1px solid ${canReroll ? 'rgba(56,189,248,.4)' : 'rgba(255,255,255,.08)'}`,
                      background: canReroll ? 'rgba(56,189,248,.1)' : 'rgba(255,255,255,.03)',
                      color: canReroll ? '#38bdf8' : '#64748b',
                      fontSize: '12px', fontWeight: 700, cursor: canReroll ? 'pointer' : 'not-allowed',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
                    }}
                  >
                    <span>↺</span>
                    <span>Reroll ({rerollCost.toLocaleString()}g)</span>
                    {rerollCount > 0 && (
                      <span style={{ fontSize: '9px', color: '#4a6080', marginLeft: '4px' }}>{rerollCount}/2 used</span>
                    )}
                  </button>

                  {/* Skip button */}
                  <button
                    onClick={() => {
                      if (gameRef.current) {
                        gameRef.current.finishArtifactPhase();
                        setGameState(gameRef.current.getState());
                      }
                    }}
                    style={{
                      flex: 1, padding: '11px', borderRadius: '10px', fontFamily: F,
                      border: '1px solid rgba(255,255,255,.08)', background: 'rgba(255,255,255,.03)',
                      color: '#64748b', fontSize: '12px', fontWeight: 500, cursor: 'pointer',
                    }}
                  >
                    Skip
                  </button>
                </div>

                {/* Next shop info */}
                <div style={{ fontSize: '9px', color: '#4a6080', letterSpacing: '1px' }}>
                  Next shop: Wave {nextShopWave}
                </div>
              </div>
            </div>
          );
        })()}

        {/* Upgrade Choices Overlay */}
        {gameState?.intermissionMode === 'Upgrade' && gameState?.pendingUpgrades && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-8 z-50">
            <h2 className="text-3xl font-bold text-white mb-2">Wave Complete!</h2>
            <p className="text-slate-400 mb-8">Choose an upgrade for the next wave</p>
            
            <div className="flex gap-6 max-w-4xl w-full justify-center">
              {gameState.pendingUpgrades.map((upgrade) => {
                const synergyHits = upgrade.tags ? upgrade.tags.filter(tag => gameState.activeTags?.includes(tag)).length : 0;
                const hasSynergy = synergyHits > 0;
                
                return (
                <button
                  key={upgrade.id}
                  onClick={() => handleUpgradeChoice(upgrade.id)}
                  className={`flex-1 bg-slate-800 hover:bg-slate-700 border-2 rounded-xl p-6 flex flex-col items-center text-center transition-all hover:scale-105 hover:shadow-xl group relative overflow-hidden ${
                    hasSynergy ? 'border-yellow-500 hover:border-yellow-400 hover:shadow-yellow-900/30' : 'border-slate-600 hover:border-blue-500 hover:shadow-blue-900/20'
                  }`}
                >
                  {hasSynergy && (
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-yellow-500 via-orange-500 to-yellow-500 opacity-80"></div>
                  )}
                  <h3 className={`text-xl font-bold mb-2 ${hasSynergy ? 'text-yellow-400 group-hover:text-yellow-300' : 'text-white group-hover:text-blue-400'}`}>
                    {upgrade.name}
                  </h3>
                  <p className={
                    upgrade.rarity === 'Legendary' ? 'text-yellow-300 font-bold' :
                    upgrade.rarity === 'Gold' ? 'text-yellow-500 font-bold' :
                    upgrade.rarity === 'Quality' ? 'text-orange-400 font-bold' :
                    upgrade.rarity === 'Rare' ? 'text-purple-400 font-semibold' :
                    upgrade.rarity === 'Uncommon' ? 'text-blue-300' :
                    'text-slate-300'
                  }>{upgrade.description}</p>
                  
                  {upgrade.tags && upgrade.tags.length > 0 && (
                    <div className="mt-4 flex flex-wrap gap-1 justify-center">
                      {upgrade.tags.map(tag => {
                        const isSynergyTag = gameState.activeTags?.includes(tag);
                        return (
                          <span 
                            key={tag} 
                            className={`text-[10px] px-2 py-0.5 rounded-full font-mono uppercase tracking-wider ${
                              isSynergyTag 
                                ? 'bg-yellow-900/50 text-yellow-300 border border-yellow-700/50' 
                                : 'bg-slate-900/50 text-slate-400 border border-slate-700/50'
                            }`}
                          >
                            {tag}
                          </span>
                        );
                      })}
                    </div>
                  )}
                </button>
              )})}
            </div>
            
            <div className="mt-8 text-slate-500 font-mono">
              Auto-picking in {Math.ceil(gameState.upgradeTimer)}s...
            </div>
          </div>
        )}

        {/* Draft Panel Overlay */}
        {gameState?.intermissionMode === 'Draft' && gameState?.pendingDraft && (
          <DraftPanel 
            draft={gameState.pendingDraft} 
            gold={gameState.gold}
            rerollCost={gameState.rerollCost}
            getCost={getTowerCost}
            onSelect={handleDraftSelect} 
            onReroll={() => gameRef.current?.rerollDraft()}
            onSkip={() => gameRef.current?.skipDraft()}
            onCancel={() => gameRef.current?.cancelPlacement()}
          />
        )}

        {/* Tower Upgrade Info Panel */}
        <div 
          className="absolute bottom-4 left-1/2 -translate-x-1/2 z-40 pointer-events-auto flex flex-col items-center gap-2"
          style={{ display: (gameState?.selectedTower && !gameState.isPlacingTower && gameRef.current?.selectedTower) ? 'flex' : 'none' }}
        >
          <div id="tower-ui"></div>
        </div>

        {/* Placement Overlay */}
        {gameState?.intermissionMode === 'Placement' && (gameState?.selectedDraftType || gameState?.pendingStarterTower) && (
          <PlacementOverlay 
            towerType={gameState.selectedDraftType || gameState.pendingStarterTower!} 
            gold={gameState.gold}
            costMultiplier={gameState.pendingStarterTower ? 0 : gameState.costMultiplier}
            onCancel={() => gameRef.current?.cancelPlacement()}
          />
        )}
        </div>
      </div>
    </div>
  );
}
