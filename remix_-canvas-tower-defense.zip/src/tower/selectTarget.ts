export function selectTarget(enemies: any[], tower: any) {
 if (!enemies || enemies.length === 0) return null

 const mode = tower.targetMode || "first"

 if (mode === "FIRST" || mode === "first") {
   return enemies.reduce((a,b)=> a.progress>b.progress?a:b)
 }

 if (mode === "LAST" || mode === "last") {
   return enemies.reduce((a,b)=> a.progress<b.progress?a:b)
 }

 if (mode === "STRONG" || mode === "strong") {
   return enemies.reduce((a,b)=> a.health>b.health?a:b)
 }

 if (mode === "CLOSE" || mode === "close") {
   return enemies.reduce((a,b)=>{
     const da = distance(a,tower)
     const db = distance(b,tower)
     return da<db?a:b
   })
 }

 return enemies[0]
}

function distance(e: any, t: any){
 const dx=e.position.x-t.position.x
 const dy=e.position.y-t.position.y
 return Math.sqrt(dx*dx+dy*dy)
}
