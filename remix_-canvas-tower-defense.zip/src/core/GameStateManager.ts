import { GameState } from "./GameState";

export class GameStateManager {
  private state: GameState = GameState.MAIN_MENU;

  setState(newState: GameState) {
    this.state = newState;
  }

  getState(): GameState {
    return this.state;
  }
}
