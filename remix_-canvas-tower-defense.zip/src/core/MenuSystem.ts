import { GameStateManager } from './GameStateManager';
import { UIManager } from '../ui/UIManager';
import { MetaSaveManager } from '../meta/MetaSaveManager';
import { MetaProgressionSystem } from '../meta/MetaProgressionSystem';

export const gameStateManager = new GameStateManager();
export const uiManager = new UIManager();

export const metaSaveManager = new MetaSaveManager();
export const metaProgression = new MetaProgressionSystem(metaSaveManager);
