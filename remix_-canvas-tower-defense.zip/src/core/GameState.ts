export enum GameState {
  MAIN_MENU,
  RUNNING,
  PAUSED,
  GAME_OVER,
  PRESTIGE_MENU
}
