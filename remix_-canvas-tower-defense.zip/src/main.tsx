import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

import { gameStateManager, uiManager, metaSaveManager } from './core/MenuSystem';
import { createMainMenu } from './ui/menu/MainMenu';
import { createPauseMenu } from './ui/menu/PauseMenu';
import { createCorruptionLabMenu } from './ui/meta/CorruptionLabMenu';
import { GameState } from './core/GameState';

try {
  const startGame = (continueRun: boolean) => {
    gameStateManager.setState(GameState.RUNNING);
    uiManager.clear();

    createRoot(document.getElementById('root')!).render(
      <StrictMode>
        <App continueRun={continueRun} />
      </StrictMode>,
    );
  };

  uiManager.show(
    createMainMenu(
      () => startGame(false),
      () => startGame(true)
    )
  );

} catch (e) {
  console.error("Failed to initialize menu system, starting game directly", e);
  gameStateManager.setState(GameState.RUNNING);
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
