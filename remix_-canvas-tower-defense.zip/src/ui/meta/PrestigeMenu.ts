export function createPrestigeMenu(
  highestWave: number,
  reward: number,
  onPrestige: () => void,
  onBack: () => void
) {
  const menu = document.createElement("div");

  Object.assign(menu.style, {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    background: "#111",
    padding: "30px",
    color: "white",
    textAlign: "center"
  });

  const title = document.createElement("h2");
  title.innerText = "Prestige Reset";

  const info = document.createElement("p");
  info.innerText = "Highest Wave: " + highestWave;

  const rewardText = document.createElement("p");
  rewardText.innerText = "Void Essence: +" + reward;

  const prestigeBtn = document.createElement("button");
  prestigeBtn.innerText = "Prestige";
  prestigeBtn.onclick = onPrestige;

  const backBtn = document.createElement("button");
  backBtn.innerText = "Back";
  backBtn.onclick = onBack;

  menu.appendChild(title);
  menu.appendChild(info);
  menu.appendChild(rewardText);
  menu.appendChild(prestigeBtn);
  menu.appendChild(backBtn);

  return menu;
}
