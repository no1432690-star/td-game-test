import { CorruptionType } from "../../systems/corruption/CorruptionTypes";
import { getCorruptionCost } from "../../systems/corruption/CorruptionCost";

export function createCorruptionLabMenu(
  shards: number,
  towers: any[],
  corruptedTowerCount: number,
  onApply: (tower: any, corruptionType: string, cost: number) => void,
  onBack: () => void
) {
  const menu = document.createElement("div");

  Object.assign(menu.style, {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    background: "#111",
    padding: "30px",
    color: "white",
    textAlign: "center",
    maxHeight: "80vh",
    overflowY: "auto",
    borderRadius: "8px",
    minWidth: "400px"
  });

  const title = document.createElement("h2");
  title.innerText = "Corruption Lab";
  title.style.marginBottom = "10px";

  const shardsInfo = document.createElement("p");
  shardsInfo.innerText = "Corrupted Shards: " + shards;
  shardsInfo.style.marginBottom = "20px";
  shardsInfo.style.color = "#a855f7";

  menu.appendChild(title);
  menu.appendChild(shardsInfo);

  const cost = getCorruptionCost(corruptedTowerCount);
  const costInfo = document.createElement("p");
  costInfo.innerText = "Next Corruption Cost: " + cost;
  costInfo.style.marginBottom = "20px";
  menu.appendChild(costInfo);

  const eligibleTowers = towers.filter(t => t && t.level >= 16 && !t.isLegendary && !t.corruptionType);

  if (eligibleTowers.length === 0) {
    const noTowers = document.createElement("p");
    noTowers.innerText = "No eligible towers found. (Requires Level 16+, Non-Legendary, Uncorrupted)";
    noTowers.style.color = "#888";
    menu.appendChild(noTowers);
  } else {
    eligibleTowers.forEach((tower, index) => {
      const towerDiv = document.createElement("div");
      Object.assign(towerDiv.style, {
        border: "1px solid #333",
        padding: "10px",
        marginBottom: "10px",
        borderRadius: "4px",
        textAlign: "left"
      });

      const towerName = document.createElement("h3");
      towerName.innerText = `Tower ${index + 1} (Level ${tower.level})`;
      towerDiv.appendChild(towerName);

      const types = Object.values(CorruptionType);
      types.forEach(type => {
        const btn = document.createElement("button");
        btn.innerText = `Apply ${type}`;
        Object.assign(btn.style, {
          display: "block",
          width: "100%",
          padding: "5px",
          marginTop: "5px",
          background: shards >= cost ? "#a855f7" : "#555",
          color: "white",
          border: "none",
          cursor: shards >= cost ? "pointer" : "not-allowed"
        });

        if (shards >= cost) {
          btn.onclick = () => onApply(tower, type, cost);
        }

        towerDiv.appendChild(btn);
      });

      menu.appendChild(towerDiv);
    });
  }

  const backBtn = document.createElement("button");
  backBtn.innerText = "Back";
  Object.assign(backBtn.style, {
    marginTop: "20px",
    padding: "10px 20px",
    background: "#333",
    color: "white",
    border: "none",
    cursor: "pointer",
    borderRadius: "4px"
  });
  backBtn.onclick = onBack;

  menu.appendChild(backBtn);

  return menu;
}
