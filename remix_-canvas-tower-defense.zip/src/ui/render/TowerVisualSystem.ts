export function getTowerBorderColor(tower: any) {
  if (tower.isLegendary) {
    return "#D4AF37";
  }
  if (tower.isCorrupted) {
    return "#7A00FF";
  }
  return "#888888";
}
