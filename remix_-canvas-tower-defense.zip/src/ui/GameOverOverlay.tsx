import React, { useEffect } from 'react';
import { AudioSystem } from '../game/systems/AudioSystem';

type GameOverOverlayProps = {
  wave: number;
  gold: number;
  onRestart: () => void;
  onMenu?: () => void;
  onRelicShop?: () => void;
};

const F = '"Segoe UI", system-ui, sans-serif';

const CORNER_STYLE = (pos: React.CSSProperties): React.CSSProperties => ({
  position: 'absolute', width: '9px', height: '9px',
  borderTop: '2px solid rgba(239,68,68,.3)',
  borderLeft: '2px solid rgba(239,68,68,.3)',
  ...pos,
});

export const GameOverOverlay: React.FC<GameOverOverlayProps> = ({ wave, gold, onRestart, onMenu, onRelicShop }) => {

  useEffect(() => {
    AudioSystem.instance.playSynth('game_over');
    // Desaturate canvas
    const canvas = document.querySelector('canvas') as HTMLCanvasElement | null;
    if (canvas) {
      canvas.style.transition = 'filter 1.5s ease';
      canvas.style.filter = 'saturate(0.15) brightness(0.4)';
    }
    return () => {
      const canvas = document.querySelector('canvas') as HTMLCanvasElement | null;
      if (canvas) canvas.style.filter = '';
    };
  }, []);

  // Calculate rewards
  const inkReward    = wave * 2;
  const shardReward  = Math.floor(wave * 0.5);
  const voidEssenceReward = Math.floor(wave / 10);
  const towersBuilt  = (() => {
    try { return ((window as any).gameInstance?.towers?.length) || 0; } catch(_) { return 0; }
  })();

  return (
    <div style={{
      position: 'absolute', inset: '0',
      background: 'radial-gradient(ellipse at 50% 30%, rgba(26,5,8,.95) 0%, rgba(6,11,20,.97) 70%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: '9500', fontFamily: F,
    }}>
      {/* Decorative shards */}
      {[
        { top:'15%', left:'12%', h:'14px', rot:'25deg', op:'.3' },
        { top:'22%', right:'18%', h:'9px', rot:'-40deg', op:'.2' },
        { bottom:'18%', left:'22%', h:'18px', rot:'15deg', op:'.15' },
        { bottom:'12%', right:'14%', h:'11px', rot:'-60deg', op:'.25' },
        { top:'40%', left:'8%', h:'7px', rot:'70deg', op:'.15' },
        { top:'35%', right:'8%', h:'12px', rot:'-20deg', op:'.2' },
      ].map((s, i) => (
        <div key={i} style={{
          position: 'absolute', width: '2.5px', height: s.h,
          background: `rgba(239,68,68,${s.op})`,
          transform: `rotate(${s.rot})`, borderRadius: '2px',
          top: s.top, left: (s as any).left, right: (s as any).right,
          bottom: (s as any).bottom,
        }} />
      ))}

      {/* Card */}
      <div style={{
        background: 'linear-gradient(160deg,#0f1e35,#0a1525)',
        border: '1px solid rgba(239,68,68,.25)',
        borderRadius: '18px', padding: '32px 36px',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        width: '340px', position: 'relative',
        boxShadow: '0 30px 80px rgba(0,0,0,.9)',
      }}>
        {/* Top stripe */}
        <div style={{
          position:'absolute', top:0, left:0, right:0, height:'2px',
          background:'linear-gradient(90deg,transparent,#dc2626,#f87171,#dc2626,transparent)',
          borderRadius:'18px 18px 0 0',
        }} />
        {/* Corners */}
        <div style={CORNER_STYLE({ top:'11px', left:'13px' })} />
        <div style={{ ...CORNER_STYLE({ top:'11px', right:'13px' }), borderLeft:'none', borderRight:'2px solid rgba(239,68,68,.3)' }} />
        <div style={{ ...CORNER_STYLE({ bottom:'11px', left:'13px' }), borderTop:'none', borderBottom:'2px solid rgba(239,68,68,.3)' }} />
        <div style={{ position:'absolute', width:'9px', height:'9px', bottom:'11px', right:'13px', borderBottom:'2px solid rgba(239,68,68,.3)', borderRight:'2px solid rgba(239,68,68,.3)' }} />

        {/* Title */}
        <div style={{ fontSize:'10px', letterSpacing:'5px', color:'#f87171', fontWeight:'700', marginBottom:'8px' }}>
          RUN ENDED
        </div>
        <div style={{ fontSize:'36px', fontWeight:'800', color:'#f8fafc', lineHeight:'1' }}>
          Wave {wave}
        </div>
        <div style={{ fontSize:'9px', letterSpacing:'3px', color:'#334155', marginBottom:'20px', marginTop:'3px' }}>
          ENDLESS TOWER DEFENSE
        </div>

        {/* Stats grid */}
        <div style={{ width:'100%', display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px', marginBottom:'14px' }}>
          {[
            { val: gold.toLocaleString() + 'g', lbl: 'GOLD LEFT',     color: '#facc15' },
            { val: towersBuilt,                  lbl: 'TOWERS BUILT',  color: '#34d399' },
            { val: wave,                         lbl: 'WAVES SURVIVED',color: '#f8fafc' },
            { val: inkReward,                    lbl: 'INK EARNED',    color: '#a78bfa' },
          ].map((s, i) => (
            <div key={i} style={{ background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.06)', borderRadius:'9px', padding:'10px', textAlign:'center' }}>
              <div style={{ fontSize:'20px', fontWeight:'700', color: s.color, marginBottom:'3px' }}>{s.val}</div>
              <div style={{ fontSize:'9px', color:'#334155', letterSpacing:'1px' }}>{s.lbl}</div>
            </div>
          ))}
        </div>

        {/* Rewards */}
        <div style={{ width:'100%', marginBottom:'14px' }}>
          <div style={{ fontSize:'8px', letterSpacing:'2px', color:'#1e3a5f', marginBottom:'8px' }}>REWARDS EARNED THIS RUN</div>
          {[
            { key:'✦  Ink',               val:`+${inkReward}`,   color:'#a78bfa' },
            { key:'◆  Corrupted Shards',   val:`+${shardReward}`, color:'#f87171' },
            { key:'✧  Void Essence',      val:`+${voidEssenceReward}`, color:'#c084fc' },
          ].map((r, i) => (
            <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'5px 0', borderBottom:'1px solid rgba(255,255,255,.04)' }}>
              <span style={{ fontSize:'11px', color:'#64748b' }}>{r.key}</span>
              <span style={{ fontSize:'12px', fontWeight:'600', color: r.color }}>{r.val}</span>
            </div>
          ))}
        </div>

        {/* Buttons */}
        <button
          onClick={onRestart}
          style={{
            width:'100%', padding:'12px', borderRadius:'10px',
            border:'1px solid rgba(239,68,68,.4)', background:'rgba(239,68,68,.12)',
            color:'#f87171', fontSize:'14px', fontWeight:'700',
            cursor:'pointer', fontFamily: F, marginBottom:'8px', letterSpacing:'1px',
            transition:'all .15s',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(239,68,68,.22)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(239,68,68,.12)'; }}
        >
          ↺ &nbsp;Try Again
        </button>
        {onRelicShop && (
          <button
            onClick={onRelicShop}
            style={{
              width:'100%', padding:'10px', borderRadius:'10px',
              border:'1px solid rgba(168,85,247,.4)', background:'rgba(168,85,247,.12)',
              color:'#c084fc', fontSize:'12px', fontWeight:'600',
              cursor:'pointer', fontFamily: F, marginBottom:'8px', letterSpacing:'1px',
              transition:'all .15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(168,85,247,.22)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(168,85,247,.12)'; }}
          >
            ✦ &nbsp;Relic Shop
          </button>
        )}
        <button
          onClick={onMenu || (() => location.reload())}
          style={{
            width:'100%', padding:'10px', borderRadius:'10px',
            border:'1px solid rgba(255,255,255,.08)', background:'rgba(255,255,255,.03)',
            color:'#64748b', fontSize:'12px', cursor:'pointer', fontFamily: F,
            transition:'all .15s',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#94a3b8'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#64748b'; }}
        >
          Return to Menu
        </button>
      </div>
    </div>
  );
};
