import React from 'react';
import { TowerTooltipManager } from '../game/systems/tower/TowerTooltipManager';

type DraftPanelProps = {
  draft: any[];
  gold: number;
  rerollCost: number;
  getCost: (type: string) => number;
  onSelect: (index: number) => void;
  onReroll: () => void;
  onSkip: () => void;
  onCancel: () => void;
};

const TOWER_META: Record<string, { icon: string; color: string; bg: string; border: string }> = {
  archer: { icon: '🏹', color: 'text-green-400', bg: 'bg-green-900/20', border: 'border-green-500/30' },
  bomber: { icon: '💣', color: 'text-orange-400', bg: 'bg-orange-900/20', border: 'border-orange-500/30' },
  frost:  { icon: '❄️', color: 'text-sky-400', bg: 'bg-sky-900/20', border: 'border-sky-500/30' },
  tesla:  { icon: '⚡', color: 'text-yellow-400', bg: 'bg-yellow-900/20', border: 'border-yellow-500/30' },
};

export const DraftPanel: React.FC<DraftPanelProps> = ({ draft, gold, rerollCost, getCost, onSelect, onReroll, onCancel }) => {
  const canAffordAny = draft.some(item => gold >= getCost(item.type));
  const canReroll = gold >= rerollCost;

  return (
    <div className="absolute inset-0 bg-black/85 flex items-center justify-center z-50 backdrop-blur-sm">
      <div className="bg-[#0a1525] p-8 rounded-2xl border border-slate-700/50 shadow-2xl shadow-black/50 max-w-4xl w-full mx-4 flex flex-col items-center">
        <h2 className="text-3xl font-bold text-white mb-8 text-center tracking-wide" style={{ fontFamily: '"Segoe UI", system-ui, sans-serif' }}>
          Choose Your Tower
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
          {draft.map((item, index) => {
            const typeName = item.type.toLowerCase();
            const meta = TOWER_META[typeName] || { icon: '🗼', color: 'text-slate-400', bg: 'bg-slate-800/50', border: 'border-slate-700' };
            
            let rarityBorder = '';
            let rarityShadow = '';
            if (item.rarity === 'rare') {
              rarityBorder = 'border-blue-500/50';
              rarityShadow = 'shadow-[0_0_15px_rgba(59,130,246,0.15)]';
            } else if (item.rarity === 'epic') {
              rarityBorder = 'border-purple-500/50';
              rarityShadow = 'shadow-[0_0_15px_rgba(168,85,247,0.15)]';
            } else if (item.rarity === 'legendary') {
              rarityBorder = 'border-yellow-500/50';
              rarityShadow = 'shadow-[0_0_15px_rgba(234,179,8,0.15)]';
            }

            const cost = getCost(item.type);
            const canAfford = gold >= cost;
            const tooltip = TowerTooltipManager.getTooltipContent(item.type);

            return (
              <div 
                key={index} 
                className={`relative overflow-hidden p-6 rounded-xl border flex flex-col items-center transition-all duration-200 ${
                  canAfford 
                    ? `bg-[#111c2e] hover:-translate-y-1 hover:shadow-xl ${rarityBorder || meta.border} ${rarityShadow}` 
                    : 'bg-[#0f172a] border-red-900/30 opacity-60 grayscale-[0.5]'
                }`}
                style={{ fontFamily: '"Segoe UI", system-ui, sans-serif' }}
              >
                {/* Background accent */}
                <div className={`absolute top-0 left-0 right-0 h-1 ${meta.bg} opacity-50`}></div>
                
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-3xl mb-4 ${meta.bg} border ${meta.border}`}>
                  {meta.icon}
                </div>
                
                <div className={`text-xl font-bold mb-1 tracking-wide ${meta.color}`}>
                  {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                </div>
                
                {item.rarity && item.rarity !== 'common' && (
                  <div className={`text-[10px] uppercase tracking-widest font-bold px-2 py-0.5 rounded mb-3 ${
                    item.rarity === 'rare' ? 'bg-blue-900/30 text-blue-400 border border-blue-500/30' :
                    item.rarity === 'epic' ? 'bg-purple-900/30 text-purple-400 border border-purple-500/30' :
                    'bg-yellow-900/30 text-yellow-400 border border-yellow-500/30'
                  }`}>
                    {item.rarity}
                  </div>
                )}
                
                <div className="text-slate-400 text-sm mb-4 bg-black/20 px-3 py-1 rounded-md border border-white/5">
                  Cost: <span className={canAfford ? "text-yellow-400 font-mono font-bold" : "text-red-400 font-mono font-bold"}>{cost}g</span>
                </div>
                
                {tooltip.stats && Object.keys(tooltip.stats).length > 0 && (
                  <div className="text-xs text-slate-400 mb-6 text-center w-full bg-white/5 rounded-lg p-3 border border-white/5">
                    <div className="flex justify-between mb-1">
                      <span>Damage</span>
                      <span className="text-slate-200 font-medium">{tooltip.stats.damage}</span>
                    </div>
                    <div className="flex justify-between mb-1">
                      <span>Range</span>
                      <span className="text-slate-200 font-medium">{tooltip.stats.range}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Cooldown</span>
                      <span className="text-slate-200 font-medium">{tooltip.stats.cooldown}s</span>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => onSelect(index)}
                  disabled={!canAfford}
                  className={`w-full py-2.5 px-4 rounded-lg font-bold tracking-wide transition-all mt-auto border ${
                    canAfford 
                      ? 'bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white border-indigo-400/30 shadow-[0_0_10px_rgba(79,70,229,0.2)]' 
                      : 'bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed'
                  }`}
                >
                  {canAfford ? 'SELECT' : 'NOT ENOUGH GOLD'}
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-8 flex gap-4 w-full max-w-md justify-center">
          <button
            onClick={onReroll}
            disabled={!canReroll}
            className={`flex-1 py-3 px-4 rounded-lg font-bold tracking-wide transition-all border ${
              canReroll
                ? 'bg-[#1e293b] hover:bg-[#334155] border-slate-600 text-white shadow-lg'
                : 'bg-slate-800/50 border-slate-700/50 text-slate-500 cursor-not-allowed'
            }`}
            style={{ fontFamily: '"Segoe UI", system-ui, sans-serif' }}
          >
            REROLL <span className="text-yellow-400 font-mono ml-1">{rerollCost}g</span>
          </button>
          
          <button
            onClick={onCancel}
            className="flex-1 py-3 px-4 rounded-lg font-bold tracking-wide transition-all border bg-red-900/40 hover:bg-red-800/60 border-red-700/50 text-red-200 hover:text-white shadow-lg"
            style={{ fontFamily: '"Segoe UI", system-ui, sans-serif' }}
          >
            CANCEL
          </button>
        </div>
      </div>
    </div>
  );
};
