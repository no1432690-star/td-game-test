// This file is intentionally empty.
// Game Over UI is now handled by GameOverOverlay.tsx in App.tsx
export function createGameOverMenu(_wave: number, _onReturn: () => void): HTMLElement {
  // No-op: returns invisible div, real UI is React overlay
  const div = document.createElement('div');
  div.style.display = 'none';
  return div;
}
