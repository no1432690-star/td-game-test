import { AudioSystem } from '../../game/systems/AudioSystem';
import { createLibraryMenu } from './LibraryMenu';
import { EnemyType } from '../../game/entities/EnemyType';
import { EnemyFactory } from '../../game/entities/EnemyFactory';

export function createPauseMenu(
  onResume: () => void,
  onExit: () => void,
  onCorruptionLab?: () => void
): HTMLElement {
  const F = '"Segoe UI", system-ui, sans-serif';
  const audio = AudioSystem.instance;
  audio.sfx('pause_open');

  // ── Inject CSS ───────────────────────────────────────────────────────────
  if (!document.getElementById('td-pause-css')) {
    const s = document.createElement('style');
    s.id = 'td-pause-css';
    s.textContent = `
      @keyframes td-pause-in {
        from { opacity:0; transform:scale(.95); }
        to   { opacity:1; transform:scale(1); }
      }
      @keyframes td-canvas-gray {
        from { filter: saturate(1) brightness(1); }
        to   { filter: saturate(0.25) brightness(0.55); }
      }
      @keyframes td-canvas-restore {
        from { filter: saturate(0.25) brightness(0.55); }
        to   { filter: saturate(1) brightness(1); }
      }
      .td-pause-card { animation: td-pause-in .25s ease both; }
      .td-pause-bg-in  canvas { animation: td-canvas-gray    1.5s ease forwards; }
      .td-pause-bg-out canvas { animation: td-canvas-restore 1.5s ease forwards; }
      .td-pb { transition: background .15s, border-color .15s, color .15s, transform .1s; }
      .td-pb:hover { transform: translateY(-2px); }
      .td-pb:active { transform: translateY(0); }
    `;
    document.head.appendChild(s);
  }

  // Desaturate the game canvas
  const gameCanvas = document.querySelector('canvas');
  if (gameCanvas) {
    gameCanvas.style.transition = 'filter 1.5s ease';
    gameCanvas.style.filter = 'saturate(0.25) brightness(0.55)';
  }

  // ── Overlay ──────────────────────────────────────────────────────────────
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'absolute', top: '0', left: '0',
    width: '100%', height: '100%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: '9000', pointerEvents: 'auto',
  });

  // ── Card ─────────────────────────────────────────────────────────────────
  const card = document.createElement('div');
  card.className = 'td-pause-card';
  Object.assign(card.style, {
    background: 'linear-gradient(160deg,#0f1e35,#0a1525)',
    border: '1px solid rgba(250,204,21,.18)',
    borderRadius: '18px',
    padding: '32px 36px',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    width: '320px', position: 'relative',
    fontFamily: F,
    boxShadow: '0 30px 80px rgba(0,0,0,.8)',
  });

  // Corner decorations
  ([
    { top:'11px', left:'13px' },
    { top:'11px', right:'13px', transform:'rotate(90deg)' },
    { bottom:'11px', left:'13px', transform:'rotate(-90deg)' },
    { bottom:'11px', right:'13px', transform:'rotate(180deg)' },
  ] as Partial<CSSStyleDeclaration>[]).forEach(pos => {
    const c = document.createElement('div');
    Object.assign(c.style, {
      position:'absolute', width:'9px', height:'9px',
      borderTop:'2px solid rgba(250,204,21,.3)',
      borderLeft:'2px solid rgba(250,204,21,.3)',
      ...pos,
    });
    card.appendChild(c);
  });

  // Title
  const title = document.createElement('div');
  title.textContent = 'PAUSED';
  Object.assign(title.style, { fontSize:'10px', letterSpacing:'5px', color:'#facc15', fontWeight:'700', marginBottom:'12px', fontFamily: F });

  // Wave info
  const waveInfo = document.createElement('div');
  try {
    const g = (window as any).gameInstance;
    const wave = g?.waveManager?.wave || '—';
    const gold = g?.gold || 0;
    waveInfo.innerHTML = `<span style="font-size:26px;font-weight:800;color:#f8fafc;">Wave ${wave}</span>`;
  } catch(_) {}
  waveInfo.style.marginBottom = '4px';

  const sub = document.createElement('div');
  sub.textContent = 'GAME PAUSED · TIME FROZEN';
  Object.assign(sub.style, { fontSize:'9px', letterSpacing:'2px', color:'#334155', marginBottom:'22px', fontFamily: F });

  card.appendChild(title);
  card.appendChild(waveInfo);
  card.appendChild(sub);

  // ── Button factory ────────────────────────────────────────────────────────
  const makeBtn = (text: string, onClick: () => void, style: {
    bg: string; border: string; color: string; size?: string; bold?: boolean;
  }): HTMLButtonElement => {
    const btn = document.createElement('button') as HTMLButtonElement;
    btn.className = 'td-pb';
    btn.innerHTML = text;
    Object.assign(btn.style, {
      width: '100%', padding: style.size === 'sm' ? '9px' : '11px',
      borderRadius: '10px', border: `1px solid ${style.border}`,
      background: style.bg, color: style.color,
      fontSize: style.size === 'sm' ? '12px' : '13px',
      fontWeight: style.bold ? '700' : '500',
      cursor: 'pointer', fontFamily: F,
      marginBottom: '8px', textAlign: 'center',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
    });
    btn.onclick = onClick;
    return btn;
  };

  // ── Resume ────────────────────────────────────────────────────────────────
  const resumeBtn = makeBtn('▶ &nbsp;Resume', () => {
    audio.sfx('pause_close');
    // Restore canvas
    const c = document.querySelector('canvas') as HTMLCanvasElement | null;
    if (c) {
      c.style.transition = 'filter 1.5s ease';
      c.style.filter = 'saturate(1) brightness(1)';
    }
    // Small delay so animation plays before game resumes
    setTimeout(() => { onResume(); }, 100);
    overlay.remove();
  }, { bg:'linear-gradient(135deg,#d97706,#b45309)', border:'rgba(217,119,6,.6)', color:'#fff', bold:true });
  resumeBtn.onmouseenter = () => { resumeBtn.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)'; };
  resumeBtn.onmouseleave = () => { resumeBtn.style.background = 'linear-gradient(135deg,#d97706,#b45309)'; };
  card.appendChild(resumeBtn);

  // ── Enemy Strengths ───────────────────────────────────────────────────────
  let enemyPanelVisible = false;
  const enemyContainer = document.createElement('div');
  Object.assign(enemyContainer.style, { width:'100%', marginBottom:'8px', display:'none' });

  const enemyBtn = makeBtn('👁 &nbsp;Enemy Strengths', () => {
    enemyPanelVisible = !enemyPanelVisible;
    enemyContainer.style.display = enemyPanelVisible ? 'block' : 'none';
    enemyBtn.style.borderColor = enemyPanelVisible ? 'rgba(56,189,248,.5)' : 'rgba(56,189,248,.25)';
    enemyBtn.style.background = enemyPanelVisible ? 'rgba(56,189,248,.18)' : 'rgba(56,189,248,.1)';
  }, { bg:'rgba(56,189,248,.1)', border:'rgba(56,189,248,.25)', color:'#38bdf8' });
  card.appendChild(enemyBtn);
  card.appendChild(enemyContainer);
  buildEnemyPanel(enemyContainer);

  // ── Library ───────────────────────────────────────────────────────────────
  const libraryBtn = makeBtn('📚 &nbsp;Library', () => {
    overlay.style.display = 'none';
    try {
      const libOverlay = createLibraryMenu(() => {
        document.body.removeChild(libOverlay);
        overlay.style.display = 'flex';
      });
      document.body.appendChild(libOverlay);
    } catch(_) {}
  }, { bg:'rgba(34,197,94,.08)', border:'rgba(34,197,94,.2)', color:'#34d399', size:'sm' });

  // Divider
  const hr = document.createElement('div');
  Object.assign(hr.style, { width:'100%', height:'1px', background:'rgba(255,255,255,.07)', margin:'4px 0 10px' });
  card.appendChild(hr);
  card.appendChild(libraryBtn);

  // ── Corruption Lab ────────────────────────────────────────────────────────
  if (onCorruptionLab) {
    const labBtn = makeBtn('⚗ &nbsp;Corruption Lab', onCorruptionLab,
      { bg:'rgba(139,92,246,.1)', border:'rgba(139,92,246,.25)', color:'#a78bfa', size:'sm' });
    card.appendChild(labBtn);
  }

  // ── Exit ──────────────────────────────────────────────────────────────────
  const exitBtn = makeBtn('✕ &nbsp;Exit Run', () => {
    if (confirm('Exit this run? Your progress will be lost.')) onExit();
  }, { bg:'rgba(239,68,68,.07)', border:'rgba(239,68,68,.18)', color:'#f87171', size:'sm' });
  card.appendChild(exitBtn);

  // Keybind hint
  const hint = document.createElement('div');
  hint.textContent = 'Press ESC to resume';
  Object.assign(hint.style, { fontSize:'9px', color:'#1e3a5f', marginTop:'10px', fontFamily: F });
  card.appendChild(hint);

  overlay.appendChild(card);
  return overlay;
}

// ── Enemy Panel builder ──────────────────────────────────────────────────────
function buildEnemyPanel(container: HTMLElement): void {
  const F = '"Segoe UI", system-ui, sans-serif';
  try {
    const g = (window as any).gameInstance;
    const wave = g?.waveManager?.wave || 1;

    const panel = document.createElement('div');
    Object.assign(panel.style, {
      background: 'linear-gradient(160deg,#0f1e35,#0a1525)',
      border: '1px solid rgba(255,255,255,.08)',
      borderRadius: '12px', padding: '12px',
      marginTop: '4px', fontFamily: F,
    });

    const ENEMIES = [
      { type: EnemyType.Red,        name: 'Grunt',            shape: 'circle', color: '#ef4444', stroke: '#991b1b', isBoss: false },
      { type: EnemyType.Yellow,     name: 'Runner',           shape: 'tri',    color: '#eab308', stroke: '#854d0e', isBoss: false },
      { type: EnemyType.Gray,       name: 'Tank',             shape: 'square', color: '#6b7280', stroke: '#374151', isBoss: false },
      { type: EnemyType.BossRed,    name: 'Boss: Titan',      shape: 'circle', color: '#ef4444', stroke: '#fff',    isBoss: true  },
      { type: EnemyType.BossYellow, name: 'Boss: Swift',      shape: 'tri',    color: '#eab308', stroke: '#fff',    isBoss: true  },
      { type: EnemyType.BossGray,   name: 'Boss: Juggernaut', shape: 'square', color: '#6b7280', stroke: '#fff',    isBoss: true  },
    ];

    ENEMIES.forEach(e => {
      const stats   = EnemyFactory.calculateStatsForType(e.type, wave);
      const statsNxt = EnemyFactory.calculateStatsForType(e.type, wave + 1);

      const row = document.createElement('div');
      Object.assign(row.style, {
        display: 'flex', alignItems: 'center', gap: '10px',
        padding: '7px 8px', borderRadius: '8px', marginBottom: '5px',
        background: e.isBoss ? 'rgba(239,68,68,.06)' : 'rgba(255,255,255,.02)',
        border: `1px solid ${e.isBoss ? 'rgba(239,68,68,.15)' : 'rgba(255,255,255,.05)'}`,
      });

      // SVG icon
      const svgNS = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('viewBox', '0 0 28 28');
      Object.assign(svg.style, { width:'26px', height:'26px', flexShrink:'0' });
      const sw = e.isBoss ? '2.5' : '1.5';
      if (e.shape === 'circle') {
        const c = document.createElementNS(svgNS, 'circle');
        c.setAttribute('cx','14'); c.setAttribute('cy','14'); c.setAttribute('r','10');
        c.setAttribute('fill', e.color); c.setAttribute('stroke', e.stroke); c.setAttribute('stroke-width', sw);
        svg.appendChild(c);
      } else if (e.shape === 'tri') {
        const p = document.createElementNS(svgNS, 'polygon');
        p.setAttribute('points','14,3 25,25 3,25');
        p.setAttribute('fill', e.color); p.setAttribute('stroke', e.stroke); p.setAttribute('stroke-width', sw);
        svg.appendChild(p);
      } else {
        const r = document.createElementNS(svgNS, 'rect');
        r.setAttribute('x','3'); r.setAttribute('y','3'); r.setAttribute('width','22'); r.setAttribute('height','22');
        r.setAttribute('fill', e.color); r.setAttribute('stroke', e.stroke); r.setAttribute('stroke-width', sw);
        svg.appendChild(r);
      }

      const info = document.createElement('div');
      info.style.flex = '1';

      const nameEl = document.createElement('div');
      nameEl.textContent = (e.isBoss ? '⚠ ' : '') + e.name;
      Object.assign(nameEl.style, {
        fontSize: '11px', fontWeight: '600',
        color: e.isBoss ? '#f87171' : '#e2e8f0',
        marginBottom: '2px', fontFamily: F,
      });

      const statsRow = document.createElement('div');
      Object.assign(statsRow.style, { display:'flex', gap:'12px', fontSize:'10px', fontFamily: F });

      const hp  = Math.round(stats.maxHealth);
      const hpN = Math.round(statsNxt.maxHealth);
      const spd = Math.round(stats.speed);
      const spdN = Math.round(statsNxt.speed);

      statsRow.innerHTML =
        `<span style="color:#475569">HP</span> ` +
        `<span style="color:#facc15;font-weight:600">\${hp.toLocaleString()}</span>` +
        `<span style="color:#334155;font-size:9px;margin:0 1px">›</span>` +
        `<span style="color:#f97316;font-size:10px">\${hpN.toLocaleString()}</span>` +
        `&nbsp;&nbsp;` +
        `<span style="color:#475569">SPD</span> ` +
        `<span style="color:#facc15;font-weight:600">\${spd}</span>`;

      info.appendChild(nameEl);
      info.appendChild(statsRow);
      row.appendChild(svg);
      row.appendChild(info);
      panel.appendChild(row);
    });

    // Legend
    const legend = document.createElement('div');
    Object.assign(legend.style, {
      display:'flex', gap:'12px', marginTop:'8px', paddingTop:'7px',
      borderTop:'1px solid rgba(255,255,255,.05)',
      fontSize:'9px', color:'#334155', fontFamily: F,
    });
    legend.innerHTML =
      `<span style="color:#facc15">■ current wave</span>` +
      `<span style="color:#f97316">■ next wave</span>`;

    // Next boss wave
    try {
      const nextBoss = wave < 5 ? 5 : wave < 10 ? 10 : wave < 15 ? 15 : null;
      if (nextBoss) {
        legend.innerHTML += `<span style="margin-left:auto;color:#1e3a5f">Next boss: Wave \${nextBoss}</span>`;
      }
    } catch(_) {}

    panel.appendChild(legend);
    container.appendChild(panel);
  } catch(err) {
    container.textContent = 'Enemy data unavailable.';
  }
}
