// ─── ICON CONFIG — dễ thay thế bằng <img> hoặc SVG thật sau này ───────────
const TOWER_ICONS: Record<string, string> = {
  archer: '🏹',
  bomber: '💣',
  frost:  '❄️',
  tesla:  '⚡',
};

const CURRENCY_ICONS: Record<string, string> = {
  gold:   '◈',
  ink:    '✦',
  shards: '◆',
  void:   '◇',
};
// ─────────────────────────────────────────────────────────────────────────────

export function createLibraryMenu(onClose: () => void): HTMLElement {
  const F = 'Segoe UI,system-ui,sans-serif';

  // ── Inject style once ──────────────────────────────────────────────────────
  if (!document.getElementById('td-library-style')) {
    const s = document.createElement('style');
    s.id = 'td-library-style';
    s.textContent = `
      @keyframes td-lib-in { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
      .td-lib-panel { animation: td-lib-in .3s ease both; }
      .td-lib-tab-btn { transition: color .15s, border-color .15s; }
      .td-lib-tab-btn:hover:not(.active) { color: #94a3b8 !important; }
      .td-lib-card { transition: border-color .18s, background .18s; }
      .td-lib-card:hover { border-color: rgba(250,204,21,.3) !important; background: #0d1a2d !important; }
      .td-lib-btn { transition: background .15s; cursor: pointer; }
      .td-lib-btn:hover { background: rgba(250,204,21,.18) !important; }
    `;
    document.head.appendChild(s);
  }

  // ── Overlay ────────────────────────────────────────────────────────────────
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0',
    background: 'rgba(0,0,0,.82)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: '1000',
  });

  // ── Panel ──────────────────────────────────────────────────────────────────
  const panel = document.createElement('div');
  panel.className = 'td-lib-panel';
  Object.assign(panel.style, {
    background: '#060b14',
    border: '1px solid rgba(250,204,21,.15)',
    borderRadius: '16px',
    width: '90%', maxWidth: '560px',
    maxHeight: '82vh',
    display: 'flex', flexDirection: 'column',
    overflow: 'hidden',
    fontFamily: F,
  });

  // ── Header ─────────────────────────────────────────────────────────────────
  const header = document.createElement('div');
  Object.assign(header.style, {
    background: '#0a1525',
    padding: '14px 20px',
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    borderBottom: '1px solid rgba(250,204,21,.12)',
    flexShrink: '0',
  });
  const headerTitle = document.createElement('span');
  headerTitle.textContent = 'LIBRARY';
  Object.assign(headerTitle.style, { fontSize: '12px', letterSpacing: '4px', color: '#facc15', fontWeight: '700' });
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    width: '28px', height: '28px', borderRadius: '50%',
    background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)',
    color: '#94a3b8', cursor: 'pointer', fontSize: '13px', fontFamily: F,
  });
  closeBtn.onclick = onClose;
  header.appendChild(headerTitle);
  header.appendChild(closeBtn);

  // ── Tabs ───────────────────────────────────────────────────────────────────
  const TABS = ['TOWERS', 'ARTIFACTS', 'RELICS', 'ENEMIES', 'CURRENCIES'] as const;
  type Tab = typeof TABS[number];
  let activeTab: Tab = 'TOWERS';

  const tabBar = document.createElement('div');
  Object.assign(tabBar.style, {
    display: 'flex', background: '#0a1525',
    borderBottom: '1px solid rgba(255,255,255,.06)', flexShrink: '0',
  });

  const tabBtns: Partial<Record<Tab, HTMLButtonElement>> = {};
  TABS.forEach(tab => {
    const btn = document.createElement('button');
    btn.className = 'td-lib-tab-btn';
    btn.textContent = tab;
    Object.assign(btn.style, {
      flex: '1', padding: '10px 4px', fontSize: '9px', letterSpacing: '1.5px',
      color: '#334155', background: 'none',
      border: 'none', borderBottom: '2px solid transparent',
      cursor: 'pointer', fontFamily: F, textAlign: 'center',
    });
    btn.onclick = () => switchTab(tab);
    tabBtns[tab] = btn;
    tabBar.appendChild(btn);
  });

  // ── Body ───────────────────────────────────────────────────────────────────
  const body = document.createElement('div');
  Object.assign(body.style, { padding: '18px', overflowY: 'auto', flex: '1' });

  // ── Helpers ────────────────────────────────────────────────────────────────
  const el = (tag: string, styles: Partial<CSSStyleDeclaration> = {}, text?: string): HTMLElement => {
    const e = document.createElement(tag);
    Object.assign(e.style, styles);
    if (text !== undefined) e.textContent = text;
    return e;
  };

  // ── Tab: TOWERS ────────────────────────────────────────────────────────────
  const TOWERS = [
    { key: 'archer', name: 'Archer',  role: 'Single target · High DPS',  color: '#22c55e', stats: [['Damage','10'],['Range','160'],['Cooldown','0.8s'],['Special','Crit + Pierce']], specialColor: '#34d399' },
    { key: 'bomber', name: 'Bomber',  role: 'AoE · Crowd control',        color: '#f97316', stats: [['Damage','40'],['Range','130'],['Cooldown','2.4s'],['Special','Splash r=70']],   specialColor: '#f97316' },
    { key: 'frost',  name: 'Frost',   role: 'Support · Slow',             color: '#38bdf8', stats: [['Damage','10'],['Range','100'],['Cooldown','1.2s'],['Special','Slow 50%/2s']],  specialColor: '#38bdf8' },
    { key: 'tesla',  name: 'Tesla',   role: 'Network · Buff',             color: '#facc15', stats: [['Damage','5'], ['Range','150'],['Cooldown','1.4s'],['Special','Chain link']],    specialColor: '#facc15' },
  ];

  function renderTowers(): HTMLElement {
    const grid = el('div', { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' });
    TOWERS.forEach(t => {
      const card = el('div', {
        background: '#0f1e35', border: '1px solid rgba(255,255,255,.08)',
        borderRadius: '12px', padding: '14px', cursor: 'pointer',
      });
      card.className = 'td-lib-card';
      const iconBox = el('div', {
        width: '40px', height: '40px', borderRadius: '10px', marginBottom: '8px',
        background: `rgba(${t.color === '#22c55e' ? '34,197,94' : t.color === '#f97316' ? '249,115,22' : t.color === '#38bdf8' ? '56,189,248' : '250,204,21'},.12)`,
        border: `1px solid ${t.color}33`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px',
      }, TOWER_ICONS[t.key]);
      const name = el('div', { fontSize: '13px', fontWeight: '600', color: '#e2e8f0', marginBottom: '2px' }, t.name);
      const role = el('div', { fontSize: '10px', color: '#475569', marginBottom: '8px' }, t.role);
      card.appendChild(iconBox); card.appendChild(name); card.appendChild(role);
      t.stats.forEach(([k, v]) => {
        const row = el('div', { display: 'flex', justifyContent: 'space-between', fontSize: '11px', padding: '2px 0', borderBottom: '1px solid rgba(255,255,255,.04)' });
        row.appendChild(el('span', { color: '#475569' }, k));
        row.appendChild(el('span', { color: k === 'Special' ? t.specialColor : '#94a3b8', fontWeight: '500' }, v));
        card.appendChild(row);
      });
      grid.appendChild(card);
    });
    return grid;
  }

  // ── Tab: ARTIFACTS ─────────────────────────────────────────────────────────
  const ARTIFACTS = [
    { name: "Golden Momentum",   rarity: "RARE",      desc: "+5% Gold per wave (up to +50%)" },
    { name: "Blood Investment",  rarity: "GOLD",      desc: "Huge gold bonus, lowers damage initially" },
    { name: "Merchant's Insight",rarity: "LEGENDARY", desc: "Increases upgrade choices by 1" },
    { name: "Overflow Vault",    rarity: "QUALITY",   desc: "Gain damage from unspent gold" },
    { name: "Endless Pressure",  rarity: "GOLD",      desc: "Gain damage based on current wave" },
    { name: "Compound Growth",   rarity: "LEGENDARY", desc: "Gain damage based on total artifacts" },
    { name: "Chain Reaction",    rarity: "RARE",      desc: "Attacks chain to another enemy" },
    { name: "Static Field",      rarity: "RARE",      desc: "Attacks have a chance to shock" },
    { name: "Overkill Conversion","rarity": "GOLD",   desc: "Excess damage splashes to nearby enemies" },
    { name: "Critical Cascade",  rarity: "LEGENDARY", desc: "Crits chain to nearby enemies" },
    { name: "Temporal Surge",    rarity: "QUALITY",   desc: "Speed boost at start of each wave" },
    { name: "Time Fracture",     rarity: "QUALITY",   desc: "Every Nth attack deals massive damage" },
    { name: "Time Echo",         rarity: "QUALITY",   desc: "Attacks have a chance to hit twice" },
    { name: "Tactical Reserve",  rarity: "QUALITY",   desc: "Gain free rerolls in the shop" },
    { name: "Second Chance",     rarity: "LEGENDARY", desc: "Chance to survive a fatal hit" },
    { name: "Blood Momentum",    rarity: "GOLD",      desc: "Gain damage based on lives lost" },
  ];
  const RARITY_STYLE: Record<string, [string, string]> = {
    COMMON:    ['rgba(148,163,184,.12)', '#94a3b8'],
    RARE:      ['rgba(167,139,250,.12)', '#a78bfa'],
    GOLD:      ['rgba(250,204,21,.1)',   '#facc15'],
    LEGENDARY: ['rgba(251,146,60,.12)',  '#fb923c'],
    QUALITY:   ['rgba(56,189,248,.1)',   '#38bdf8'],
  };

  function renderArtifacts(): HTMLElement {
    const grid = el('div', { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '8px' });
    ARTIFACTS.forEach(a => {
      const [bg, color] = RARITY_STYLE[a.rarity] || RARITY_STYLE.COMMON;
      const card = el('div', { background: '#0f1e35', borderRadius: '10px', padding: '11px', border: '1px solid rgba(255,255,255,.06)' });
      const pill = el('div', { display: 'inline-block', padding: '2px 7px', borderRadius: '4px', fontSize: '9px', letterSpacing: '1px', fontWeight: '600', marginBottom: '5px', background: bg, color });
      pill.textContent = a.rarity;
      const name = el('div', { fontSize: '11px', fontWeight: '600', color: '#cbd5e1', marginBottom: '3px' }, a.name);
      const desc = el('div', { fontSize: '10px', color: '#475569', lineHeight: '1.5' }, a.desc);
      card.appendChild(pill); card.appendChild(name); card.appendChild(desc);
      grid.appendChild(card);
    });
    return grid;
  }

  // ── Tab: RELICS ────────────────────────────────────────────────────────────
  const RELICS = [
    { icon: '⚙', name: 'Bronze Gear',   bonus: '+2% ATK / lv' },
    { icon: '⏱', name: 'Chrono Core',   bonus: '+3% ATK SPD / lv' },
    { icon: '🔭', name: 'Arcane Lens',   bonus: '+3% Range / lv' },
    { icon: '🧲', name: 'Gold Magnet',   bonus: '+10% Gold / lv' },
    { icon: '❄', name: 'Frost Crystal', bonus: '+5% Slow dur / lv' },
  ];

  function renderRelics(): HTMLElement {
    const list = el('div', { display: 'flex', flexDirection: 'column', gap: '10px' });
    RELICS.forEach(r => {
      const card = el('div', { background: '#0f1e35', border: '1px solid rgba(255,255,255,.07)', borderRadius: '10px', padding: '14px', display: 'flex', alignItems: 'center', gap: '14px' });
      const gem = el('div', { width: '36px', height: '36px', borderRadius: '8px', background: 'rgba(250,204,21,.1)', border: '1px solid rgba(250,204,21,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', flexShrink: '0' }, r.icon);
      const info = el('div', { flex: '1' });
      info.appendChild(el('div', { fontSize: '13px', fontWeight: '600', color: '#e2e8f0', marginBottom: '2px' }, r.name));
      info.appendChild(el('div', { fontSize: '11px', color: '#475569' }, 'Passive relic · Stackable'));
      card.appendChild(gem); card.appendChild(info);
      card.appendChild(el('div', { fontSize: '11px', color: '#34d399', fontWeight: '600', whiteSpace: 'nowrap' }, r.bonus));
      list.appendChild(card);
    });
    return list;
  }

  // ── Tab: ENEMIES ───────────────────────────────────────────────────────────
  type EnemyDef = { shape: string; badge: string; badgeBg: string; badgeColor: string; name: string; stats: string; };
  const ENEMIES: EnemyDef[] = [
    { shape: '<circle cx="18" cy="18" r="13" fill="#ef4444" stroke="#991b1b" stroke-width="2"/>', badge: 'NORMAL', badgeBg: 'rgba(239,68,68,.15)', badgeColor: '#fca5a5', name: 'Red',        stats: 'HP: 100 base\nSPD: 45 base' },
    { shape: '<polygon points="18,4 32,30 4,30" fill="#eab308" stroke="#854d0e" stroke-width="2"/>', badge: 'FAST', badgeBg: 'rgba(234,179,8,.12)', badgeColor: '#fde047', name: 'Yellow',     stats: 'HP: ×0.6\nSPD: ×1.6' },
    { shape: '<rect x="5" y="5" width="26" height="26" fill="#6b7280" stroke="#374151" stroke-width="2"/>', badge: 'TANK', badgeBg: 'rgba(107,114,128,.15)', badgeColor: '#d1d5db', name: 'Gray',       stats: 'HP: ×2.5\nSPD: ×0.6' },
    { shape: '<circle cx="18" cy="18" r="13" fill="#ef4444" stroke="#fff" stroke-width="3"/>', badge: 'BOSS', badgeBg: 'rgba(239,68,68,.2)', badgeColor: '#fca5a5', name: 'Boss Red',    stats: 'HP: ×(4+wave/5)\nGold: ×1.5' },
    { shape: '<polygon points="18,4 32,30 4,30" fill="#eab308" stroke="#fff" stroke-width="3"/>', badge: 'BOSS', badgeBg: 'rgba(234,179,8,.18)', badgeColor: '#fde047', name: 'Boss Yellow', stats: 'HP: ×(boss×0.6)\nGold: ×1.5' },
    { shape: '<rect x="5" y="5" width="26" height="26" fill="#6b7280" stroke="#fff" stroke-width="3"/>', badge: 'BOSS', badgeBg: 'rgba(107,114,128,.2)', badgeColor: '#d1d5db', name: 'Boss Gray',   stats: 'HP: ×(boss×2.5)\nGold: ×1.5' },
  ];

  function renderEnemies(): HTMLElement {
    const grid = el('div', { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px' });
    ENEMIES.forEach(e => {
      const card = el('div', { background: '#0f1e35', border: '1px solid rgba(255,255,255,.07)', borderRadius: '12px', padding: '14px', textAlign: 'center' });
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', '0 0 36 36');
      Object.assign(svg.style, { width: '36px', height: '36px', display: 'block', margin: '0 auto 7px' });
      svg.innerHTML = e.shape;
      const badge = el('div', { display: 'inline-block', padding: '2px 6px', borderRadius: '4px', fontSize: '9px', letterSpacing: '1px', fontWeight: '600', marginBottom: '5px', background: e.badgeBg, color: e.badgeColor }, e.badge);
      const name = el('div', { fontSize: '12px', fontWeight: '600', color: '#e2e8f0', marginBottom: '5px' }, e.name);
      const stats = el('div', { fontSize: '10px', color: '#475569', lineHeight: '1.8', whiteSpace: 'pre-line' }, e.stats);
      card.appendChild(svg); card.appendChild(badge); card.appendChild(name); card.appendChild(stats);
      grid.appendChild(card);
    });
    return grid;
  }

  // ── Tab: CURRENCIES ────────────────────────────────────────────────────────
  type CurrencyDef = {
    key: string; name: string; badge: string; badgeBg: string; badgeColor: string;
    cardBg: string; cardBorder: string; nameColor: string; dotColor: string;
    tagBg: string; tagColor: string; tagBorder: string; formulaBg: string; formulaBorder: string; formulaColor: string;
    type: string; earn: string[]; formula: string; formulaNote?: string; tags: string[]; isNew?: boolean;
  };
  const CURRENCIES: CurrencyDef[] = [
    {
      key: 'gold', name: 'Gold', badge: 'IN-RUN', badgeBg: 'rgba(250,204,21,.1)', badgeColor: '#92400e',
      cardBg: 'rgba(250,204,21,.06)', cardBorder: 'rgba(250,204,21,.18)', nameColor: '#facc15', dotColor: '#facc15',
      tagBg: 'rgba(250,204,21,.1)', tagColor: '#fde68a', tagBorder: 'rgba(250,204,21,.15)',
      formulaBg: 'rgba(250,204,21,.1)', formulaBorder: 'rgba(250,204,21,.2)', formulaColor: '#facc15',
      type: 'IN-RUN CURRENCY · RESETS ON DEFEAT',
      earn: ['Kill enemies — reward scales with max HP', 'Sell tower (Q): refunds 50% × baseCost × level', 'Artifact Golden Momentum increases gold per wave'],
      formula: 'Enemy reward = floor(maxHP × 0.003)',
      tags: ['Place Tower', 'Unlock Slot', 'Reroll Draft'],
    },
    {
      key: 'ink', name: 'Ink', badge: 'META', badgeBg: 'rgba(139,92,246,.1)', badgeColor: '#6d28d9',
      cardBg: 'rgba(139,92,246,.06)', cardBorder: 'rgba(139,92,246,.2)', nameColor: '#a78bfa', dotColor: '#a78bfa',
      tagBg: 'rgba(139,92,246,.1)', tagColor: '#c4b5fd', tagBorder: 'rgba(139,92,246,.15)',
      formulaBg: 'rgba(139,92,246,.1)', formulaBorder: 'rgba(139,92,246,.2)', formulaColor: '#a78bfa',
      type: 'META CURRENCY · PERSISTS AFTER DEFEAT',
      earn: ['At the end of each run (defeat or exit)', 'Higher wave reached → more Ink earned'],
      formula: 'Ink/run = wave × 2',
      formulaNote: 'Example: reach wave 20 → earn 40 Ink',
      tags: ['Meta: +Damage', 'Meta: +Gold', 'Meta: +Life', 'Meta: +Crit'],
      isNew: true,
    },
    {
      key: 'shards', name: 'Corrupted Shards', badge: 'META', badgeBg: 'rgba(239,68,68,.1)', badgeColor: '#7f1d1d',
      cardBg: 'rgba(239,68,68,.05)', cardBorder: 'rgba(239,68,68,.18)', nameColor: '#f87171', dotColor: '#f87171',
      tagBg: 'rgba(239,68,68,.1)', tagColor: '#fca5a5', tagBorder: 'rgba(239,68,68,.15)',
      formulaBg: 'rgba(239,68,68,.1)', formulaBorder: 'rgba(239,68,68,.18)', formulaColor: '#f87171',
      type: 'META CURRENCY · PERSISTS AFTER DEFEAT',
      earn: ['End of run: a portion of Shards is retained', 'Watch a rewarded ad to double your reward'],
      formula: 'Shards/run = floor(wave × 0.5)',
      tags: ['Corruption Lab', 'Apply Corruption'],
    },
    {
      key: 'void', name: 'Void Essence', badge: 'PRESTIGE', badgeBg: 'rgba(56,189,248,.1)', badgeColor: '#0c4a6e',
      cardBg: 'rgba(56,189,248,.05)', cardBorder: 'rgba(56,189,248,.15)', nameColor: '#38bdf8', dotColor: '#38bdf8',
      tagBg: 'rgba(56,189,248,.1)', tagColor: '#7dd3fc', tagBorder: 'rgba(56,189,248,.15)',
      formulaBg: 'rgba(56,189,248,.1)', formulaBorder: 'rgba(56,189,248,.18)', formulaColor: '#38bdf8',
      type: 'PRESTIGE CURRENCY · RAREST',
      earn: ['Perform Prestige — resets all run progress', 'Reward scales with the highest wave reached'],
      formula: 'Void Essence = floor(√ highestWave)',
      tags: ['Unlock Relics', 'Upgrade Relic level'],
    },
  ];

  function renderCurrencies(): HTMLElement {
    const wrap = el('div', { display: 'flex', flexDirection: 'column', gap: '12px' });
    CURRENCIES.forEach(c => {
      const card = el('div', { borderRadius: '14px', padding: '16px 18px', background: c.cardBg, border: `1px solid ${c.cardBorder}`, display: 'flex', gap: '14px', alignItems: 'flex-start' });
      const iconBox = el('div', { width: '44px', height: '44px', borderRadius: '12px', background: c.cardBg, border: `1px solid ${c.cardBorder}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', flexShrink: '0', color: c.nameColor });
      iconBox.textContent = CURRENCY_ICONS[c.key] || '◈';
      const info = el('div', { flex: '1' });
      const titleRow = el('div', { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px', flexWrap: 'wrap' });
      titleRow.appendChild(el('span', { fontSize: '15px', fontWeight: '700', color: c.nameColor }, c.name));
      const badgePill = el('span', { fontSize: '9px', padding: '2px 7px', borderRadius: '4px', background: c.badgeBg, color: c.badgeColor, border: `1px solid ${c.cardBorder}`, letterSpacing: '1px' }, c.badge);
      titleRow.appendChild(badgePill);
      if (c.isNew) {
        const newBadge = el('span', { fontSize: '9px', padding: '1px 6px', borderRadius: '4px', background: 'rgba(34,197,94,.15)', color: '#4ade80', border: '1px solid rgba(34,197,94,.25)', fontWeight: '700', letterSpacing: '1px' }, 'NEW ✦');
        titleRow.appendChild(newBadge);
      }
      info.appendChild(titleRow);
      info.appendChild(el('div', { fontSize: '10px', letterSpacing: '1.5px', color: '#334155', marginBottom: '10px' }, c.type));
      info.appendChild(el('div', { fontSize: '10px', letterSpacing: '1.5px', color: '#64748b', marginBottom: '6px' }, 'HOW TO EARN'));
      c.earn.forEach(line => {
        const row = el('div', { display: 'flex', alignItems: 'flex-start', gap: '8px', marginBottom: '4px' });
        const dot = el('div', { width: '4px', height: '4px', borderRadius: '50%', marginTop: '5px', flexShrink: '0', background: c.dotColor });
        row.appendChild(dot);
        row.appendChild(el('span', { fontSize: '12px', color: '#64748b', lineHeight: '1.6' }, line));
        info.appendChild(row);
      });
      const formulaBox = el('div', { display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '5px 10px', borderRadius: '7px', fontSize: '12px', fontWeight: '600', marginTop: '8px', marginBottom: c.formulaNote ? '4px' : '8px', background: c.formulaBg, border: `1px solid ${c.formulaBorder}`, color: c.formulaColor });
      formulaBox.textContent = c.formula;
      info.appendChild(formulaBox);
      if (c.formulaNote) {
        info.appendChild(el('div', { fontSize: '10px', color: '#4b5563', marginBottom: '8px', paddingLeft: '2px' }, c.formulaNote));
      }
      info.appendChild(el('div', { fontSize: '10px', letterSpacing: '1.5px', color: '#64748b', marginBottom: '6px' }, 'USED FOR'));
      const tagsRow = el('div', { display: 'flex', flexWrap: 'wrap', gap: '6px' });
      c.tags.forEach(t => tagsRow.appendChild(el('span', { padding: '3px 9px', borderRadius: '5px', fontSize: '10px', fontWeight: '500', background: c.tagBg, color: c.tagColor, border: `1px solid ${c.tagBorder}` }, t)));
      info.appendChild(tagsRow);
      card.appendChild(iconBox);
      card.appendChild(info);
      wrap.appendChild(card);
    });
    return wrap;
  }

  // ── switchTab ──────────────────────────────────────────────────────────────
  const renderers: Record<Tab, () => HTMLElement> = {
    TOWERS: renderTowers, ARTIFACTS: renderArtifacts,
    RELICS: renderRelics, ENEMIES: renderEnemies, CURRENCIES: renderCurrencies,
  };

  function switchTab(tab: Tab) {
    activeTab = tab;
    TABS.forEach(t => {
      const btn = tabBtns[t]!;
      btn.style.color = t === tab ? '#facc15' : '#334155';
      btn.style.borderBottom = t === tab ? '2px solid #facc15' : '2px solid transparent';
    });
    body.innerHTML = '';
    body.appendChild(renderers[tab]());
  }

  // ── Assemble ───────────────────────────────────────────────────────────────
  panel.appendChild(header);
  panel.appendChild(tabBar);
  panel.appendChild(body);
  overlay.appendChild(panel);

  switchTab('TOWERS');
  return overlay;
}
