import { createLibraryMenu } from './LibraryMenu';
import { createMetaMenu } from './MetaMenu';

export function createMainMenu(onStart: () => void, onContinue?: () => void): HTMLElement {
  const F = '"Segoe UI", system-ui, sans-serif';

  // ── Inject CSS (một lần) ──────────────────────────────────────────────────
  if (!document.getElementById('td-mainmenu-style')) {
    const style = document.createElement('style');
    style.id = 'td-mainmenu-style';
    style.textContent = `
      @keyframes td-flicker {
        0%,100%{ opacity:1; text-shadow:0 0 18px #facc15,0 0 40px #f59e0b88; }
        48%    { opacity:1; }
        50%    { opacity:.82; text-shadow:0 0 6px #facc15; }
        52%    { opacity:1; }
      }
      @keyframes td-pulse-ring {
        0%  { box-shadow:0 0 0 0 rgba(217,119,6,.45); }
        70% { box-shadow:0 0 0 10px rgba(217,119,6,0); }
        100%{ box-shadow:0 0 0 0 rgba(217,119,6,0); }
      }
      @keyframes td-menu-in {
        from{ opacity:0; transform:translate(-50%,-48%); }
        to  { opacity:1; transform:translate(-50%,-50%); }
      }
      .td-menu-card   { animation: td-menu-in .4s ease both; }
      .td-title-glow  { animation: td-flicker 4s ease-in-out infinite; }
      .td-start-pulse { animation: td-pulse-ring 2.2s ease-out infinite; }
      .td-btn-secondary {
        transition: background .18s, border-color .18s, color .18s, transform .12s;
      }
      .td-btn-secondary:hover  { transform:translateY(-2px); }
      .td-btn-secondary:active { transform:translateY(0); }
      .td-btn-continue {
        transition: background .18s, border-color .18s, transform .12s;
      }
      .td-btn-continue:hover  { transform:translateY(-2px); }
      .td-btn-continue:active { transform:translateY(0); }
    `;
    document.head.appendChild(style);
  }

  // ── Backdrop fullscreen ───────────────────────────────────────────────────
  const backdrop = document.createElement('div');
  Object.assign(backdrop.style, {
    position: 'fixed', inset: '0',
    background: 'radial-gradient(ellipse at 50% 30%, #0f1a2e 0%, #060b14 100%)',
    zIndex: '500',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  });

  // ── Particle canvas ───────────────────────────────────────────────────────
  const particleCanvas = document.createElement('canvas');
  Object.assign(particleCanvas.style, {
    position: 'absolute', inset: '0',
    width: '100%', height: '100%',
    pointerEvents: 'none',
  });
  backdrop.appendChild(particleCanvas);

  // Start particle animation after DOM is attached
  requestAnimationFrame(() => {
    const W = particleCanvas.offsetWidth, H = particleCanvas.offsetHeight;
    particleCanvas.width = W; particleCanvas.height = H;
    const ctx = particleCanvas.getContext('2d')!;
    const N = 70;
    const pts = Array.from({ length: N }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      r: 0.5 + Math.random() * 1.2,
      dy: -0.12 - Math.random() * 0.18,
      dx: (Math.random() - 0.5) * 0.08,
      o: 0.15 + Math.random() * 0.5,
      po: 0.15 + Math.random() * 0.5,
      dpo: (Math.random() - 0.5) * 0.006,
    }));
    function drawParticles() {
      ctx.clearRect(0, 0, W, H);
      pts.forEach(p => {
        p.y += p.dy; p.x += p.dx;
        p.po += p.dpo;
        if (p.po < 0.1 || p.po > 0.65) p.dpo *= -1;
        if (p.y < -4) { p.y = H + 4; p.x = Math.random() * W; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(250,204,21,${p.po.toFixed(2)})`;
        ctx.fill();
      });
      requestAnimationFrame(drawParticles);
    }
    drawParticles();
  });

  // ── Card ──────────────────────────────────────────────────────────────────
  const menu = document.createElement('div');
  menu.className = 'td-menu-card';
  Object.assign(menu.style, {
    position: 'absolute',
    top: '50%', left: '50%',
    transform: 'translate(-50%,-50%)',
    background: 'linear-gradient(160deg,#0f1e35 0%,#0a1525 100%)',
    border: '1px solid rgba(250,204,21,.18)',
    borderRadius: '18px',
    padding: '40px 36px 30px',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    gap: '0',
    minWidth: '320px', maxWidth: '360px', width: '90vw',
    boxShadow: '0 30px 80px rgba(0,0,0,.8), inset 0 1px 0 rgba(255,255,255,.06)',
    fontFamily: F,
    zIndex: '1',
  });

  // Corner decorations
  ([
    { top:'12px', left:'14px' },
    { top:'12px', right:'14px', transform:'rotate(90deg)' },
    { bottom:'12px', left:'14px', transform:'rotate(-90deg)' },
    { bottom:'12px', right:'14px', transform:'rotate(180deg)' },
  ] as Partial<CSSStyleDeclaration>[]).forEach(pos => {
    const c = document.createElement('div');
    Object.assign(c.style, {
      position:'absolute', width:'10px', height:'10px',
      borderTop:'2px solid rgba(250,204,21,.35)',
      borderLeft:'2px solid rgba(250,204,21,.35)',
      ...pos,
    });
    menu.appendChild(c);
  });

  // ── Logo canvas (3D animated: cube + tetrahedron + sphere) ────────────────
  const logoCanvas = document.createElement('canvas');
  logoCanvas.width = 100; logoCanvas.height = 100;
  Object.assign(logoCanvas.style, { display:'block', marginBottom:'10px' });

  const lctx = logoCanvas.getContext('2d')!;
  const S = 34;
  const rY = (v: number[], a: number) => {
    const c = Math.cos(a), s = Math.sin(a);
    return [v[0]*c+v[2]*s, v[1], -v[0]*s+v[2]*c];
  };
  const rX = (v: number[], a: number) => {
    const c = Math.cos(a), s = Math.sin(a);
    return [v[0], v[1]*c-v[2]*s, v[1]*s+v[2]*c];
  };
  const rZ = (v: number[], a: number) => {
    const c = Math.cos(a), s = Math.sin(a);
    return [v[0]*c-v[1]*s, v[0]*s+v[1]*c, v[2]];
  };
  const pr = (x: number, y: number, z: number): [number,number] => {
    const d = 1 / (1 + z * 0.14);
    return [50 + x * d * S, 50 + y * d * S];
  };

  const R = 0.85;
  const CV = [[-R,-R,-R],[R,-R,-R],[R,R,-R],[-R,R,-R],[-R,-R,R],[R,-R,R],[R,R,R],[-R,R,R]];
  const CE: [number,number][] = [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]];
  const T = 0.52;
  const TV = [[T,T,T],[T,-T,-T],[-T,T,-T],[-T,-T,T]];
  const TE: [number,number][] = [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]];

  let lt = 0, lastLT = 0;
  function drawLogo(ts: number) {
    const dt = Math.min((ts - lastLT) / 1000, 0.05); lastLT = ts; lt += dt;
    lctx.clearRect(0, 0, 100, 100);

    // Glow halo
    const grad = lctx.createRadialGradient(50,50,10,50,50,45);
    grad.addColorStop(0, 'rgba(250,204,21,.08)');
    grad.addColorStop(1, 'rgba(250,204,21,0)');
    lctx.beginPath(); lctx.arc(50,50,45,0,Math.PI*2);
    lctx.fillStyle = grad; lctx.fill();

    // Cube (slow, clockwise)
    const ca = lt * 0.45;
    lctx.strokeStyle = 'rgba(250,204,21,.80)'; lctx.lineWidth = 1.4;
    CE.forEach(([a, b]) => {
      const va = rX(rY(CV[a], ca), 0.35);
      const vb = rX(rY(CV[b], ca), 0.35);
      const pa = pr(va[0],va[1],va[2]), pb = pr(vb[0],vb[1],vb[2]);
      lctx.beginPath(); lctx.moveTo(pa[0],pa[1]); lctx.lineTo(pb[0],pb[1]); lctx.stroke();
    });

    // Tetrahedron (faster, counter-clockwise, different axis)
    const ta = -lt * 0.72;
    lctx.strokeStyle = 'rgba(56,189,248,.85)'; lctx.lineWidth = 1.2;
    TE.forEach(([a, b]) => {
      const va = rZ(rX(TV[a], ta), lt * 0.28);
      const vb = rZ(rX(TV[b], ta), lt * 0.28);
      const pa = pr(va[0],va[1],va[2]), pb = pr(vb[0],vb[1],vb[2]);
      lctx.beginPath(); lctx.moveTo(pa[0],pa[1]); lctx.lineTo(pb[0],pb[1]); lctx.stroke();
    });

    // Sphere core
    lctx.beginPath(); lctx.arc(50, 50, S * 0.22, 0, Math.PI * 2);
    lctx.fillStyle = 'rgba(255,255,255,.06)'; lctx.fill();
    lctx.strokeStyle = 'rgba(255,255,255,.88)'; lctx.lineWidth = 1.2; lctx.stroke();
    // Orbit rings
    lctx.save(); lctx.translate(50, 50); lctx.rotate(lt * 0.9);
    lctx.beginPath(); lctx.ellipse(0, 0, S*0.22, S*0.22*0.28, 0, 0, Math.PI*2);
    lctx.strokeStyle = 'rgba(255,255,255,.3)'; lctx.lineWidth = 0.7; lctx.stroke();
    lctx.rotate(Math.PI / 2);
    lctx.beginPath(); lctx.ellipse(0, 0, S*0.22*0.28, S*0.22, 0, 0, Math.PI*2);
    lctx.strokeStyle = 'rgba(255,255,255,.18)'; lctx.lineWidth = 0.6; lctx.stroke();
    lctx.restore();

    requestAnimationFrame(drawLogo);
  }
  requestAnimationFrame(drawLogo);
  menu.appendChild(logoCanvas);

  // ── Title ─────────────────────────────────────────────────────────────────
  const titleEl = document.createElement('div');
  titleEl.className = 'td-title-glow';
  titleEl.textContent = 'ENDLESS';
  Object.assign(titleEl.style, {
    fontSize: '28px', fontWeight: '800', letterSpacing: '6px',
    color: '#facc15', fontFamily: F, margin: '0 0 2px 0',
  });
  menu.appendChild(titleEl);

  const subtitleEl = document.createElement('div');
  subtitleEl.textContent = 'TOWER DEFENSE';
  Object.assign(subtitleEl.style, {
    fontSize: '10px', letterSpacing: '5px', color: '#4b5563',
    marginBottom: '20px', fontFamily: F,
  });
  menu.appendChild(subtitleEl);

  // ── Button factory ────────────────────────────────────────────────────────
  const createBtn = (
    text: string,
    onClick: () => void,
    variant: 'primary' | 'secondary' | 'continue' = 'secondary'
  ): HTMLButtonElement => {
    const btn = document.createElement('button');
    btn.textContent = text;
    btn.onclick = onClick;

    const isPrimary  = variant === 'primary';
    const isContinue = variant === 'continue';

    if (isPrimary)  btn.className = 'td-start-pulse';
    if (!isPrimary && !isContinue) btn.className = 'td-btn-secondary';
    if (isContinue) btn.className = 'td-btn-continue';

    Object.assign(btn.style, {
      width: '100%',
      padding: isPrimary ? '13px 20px' : '11px 18px',
      fontSize: isPrimary ? '15px' : '13px',
      fontWeight: isPrimary ? '700' : isContinue ? '600' : '500',
      letterSpacing: isPrimary ? '2px' : '0.8px',
      cursor: 'pointer',
      borderRadius: '10px',
      border: isPrimary
        ? '1px solid rgba(217,119,6,.6)'
        : isContinue
        ? '1px solid rgba(52,211,153,.38)'
        : '1px solid rgba(255,255,255,.08)',
      background: isPrimary
        ? 'linear-gradient(135deg,#d97706,#b45309)'
        : isContinue
        ? 'rgba(16,185,129,.08)'
        : 'rgba(255,255,255,.03)',
      color: isPrimary ? '#fff' : isContinue ? '#34d399' : '#94a3b8',
      fontFamily: F,
      marginBottom: '8px',
      textTransform: isPrimary ? 'uppercase' : 'none',
      outline: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: isPrimary ? 'center' : 'flex-start',
      gap: '8px',
    });

    if (isPrimary) {
      btn.onmouseover = () => { btn.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)'; };
      btn.onmouseout  = () => { btn.style.background = 'linear-gradient(135deg,#d97706,#b45309)'; };
    } else if (isContinue) {
      btn.onmouseover = () => { btn.style.background = 'rgba(16,185,129,.18)'; btn.style.borderColor = 'rgba(52,211,153,.6)'; };
      btn.onmouseout  = () => { btn.style.background = 'rgba(16,185,129,.08)'; btn.style.borderColor = 'rgba(52,211,153,.38)'; };
    } else {
      btn.onmouseover = () => { btn.style.background = 'rgba(250,204,21,.08)'; btn.style.borderColor = 'rgba(250,204,21,.3)'; btn.style.color = '#facc15'; };
      btn.onmouseout  = () => { btn.style.background = 'rgba(255,255,255,.03)'; btn.style.borderColor = 'rgba(255,255,255,.08)'; btn.style.color = '#94a3b8'; };
    }

    return btn;
  };

  // ── Info panel helper ─────────────────────────────────────────────────────
  const openInfoPanel = (titleText: string, contentHTML: string) => {
    backdrop.style.display = 'none';

    const overlay = document.createElement('div');
    Object.assign(overlay.style, {
      position: 'fixed', inset: '0',
      background: 'rgba(0,0,0,.85)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: '1000',
    });

    const panel = document.createElement('div');
    Object.assign(panel.style, {
      background: 'linear-gradient(160deg,#0f1e35,#0a1525)',
      padding: '28px', borderRadius: '16px',
      maxWidth: '480px', width: '90%', maxHeight: '80vh', overflowY: 'auto',
      color: 'white', fontFamily: F,
      border: '1px solid rgba(250,204,21,.15)',
      boxShadow: '0 24px 60px rgba(0,0,0,.7)',
    });

    const hdr = document.createElement('h2');
    hdr.innerText = titleText;
    Object.assign(hdr.style, {
      marginTop: '0', fontSize: '13px', letterSpacing: '4px', color: '#facc15',
      textAlign: 'center', borderBottom: '1px solid rgba(250,204,21,.12)',
      paddingBottom: '14px', marginBottom: '18px',
    });

    const content = document.createElement('div');
    content.innerHTML = contentHTML;
    content.style.lineHeight = '1.7';
    content.style.marginBottom = '20px';

    const closeBtn = createBtn('Close', () => {
      document.body.removeChild(overlay);
      backdrop.style.display = 'flex';
    });
    closeBtn.style.justifyContent = 'center';
    closeBtn.style.marginBottom = '0';

    panel.appendChild(hdr);
    panel.appendChild(content);
    panel.appendChild(closeBtn);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  };

  // ── Info panel contents ───────────────────────────────────────────────────
  const HOW_TO_PLAY_HTML = `
    <div style="display:flex;flex-direction:column;gap:14px;font-size:14px;color:#cbd5e1;">
      <div style="display:flex;gap:12px;align-items:flex-start;">
        <span style="font-size:18px;flex-shrink:0;">🏰</span>
        <div><strong style="color:#f8fafc;">Defend your base</strong><br>Build towers to stop enemies reaching the end.</div>
      </div>
      <div style="display:flex;gap:12px;align-items:flex-start;">
        <span style="font-size:18px;flex-shrink:0;">💰</span>
        <div><strong style="color:#facc15;">Gold</strong><br>Earn gold by defeating enemies. Spend it to place and upgrade towers.</div>
      </div>
      <div style="display:flex;gap:12px;align-items:flex-start;">
        <span style="font-size:18px;flex-shrink:0;">⬆️</span>
        <div><strong style="color:#60a5fa;">Upgrades</strong><br>Select a tower and choose an upgrade every wave.</div>
      </div>
      <div style="display:flex;gap:12px;align-items:flex-start;">
        <span style="font-size:18px;flex-shrink:0;">🎯</span>
        <div><strong style="color:#34d399;">Targeting</strong><br>Change tower target priority to control which enemies it focuses.</div>
      </div>
      <div style="margin-top:6px;padding:12px;background:rgba(250,204,21,.07);border:1px solid rgba(250,204,21,.15);border-radius:8px;text-align:center;font-weight:600;color:#facc15;">
        Survive as many waves as possible!
      </div>
    </div>
  `;

  const CONTROLS_HTML = `
    <div style="font-size:13px;color:#cbd5e1;">
      <div style="color:#64748b;font-size:10px;letter-spacing:3px;margin-bottom:10px;">PC</div>
      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;">
        ${[['ESC','Pause game'],['1 / 2 / 3','Select tower by slot'],['E','Upgrade selected tower'],['Q','Sell selected tower'],['R','Cycle target priority']]
          .map(([k,v]) => `<div style="display:flex;align-items:center;gap:10px;"><kbd style="background:#1e3a5f;border:1px solid #3b5998;padding:3px 9px;border-radius:5px;font-family:monospace;font-size:11px;color:#93c5fd;flex-shrink:0;">${k}</kbd><span>${v}</span></div>`)
          .join('')}
      </div>
      <div style="color:#64748b;font-size:10px;letter-spacing:3px;margin-bottom:10px;">MOBILE</div>
      <div style="display:flex;flex-direction:column;gap:7px;">
        <div>📱 Tap a tower slot to select</div>
        <div>📱 Tap upgrade button to upgrade</div>
        <div>📱 Tap empty tile to build</div>
      </div>
    </div>
  `;

  const SETTINGS_HTML = `
    <div style="display:flex;flex-direction:column;gap:14px;font-size:13px;">
      <div>
        <label style="display:block;margin-bottom:6px;color:#64748b;font-size:10px;letter-spacing:2px;">MUSIC VOLUME</label>
        <input type="range" min="0" max="100" value="50" style="width:100%;accent-color:#facc15;">
      </div>
      <div>
        <label style="display:block;margin-bottom:6px;color:#64748b;font-size:10px;letter-spacing:2px;">SFX VOLUME</label>
        <input type="range" min="0" max="100" value="80" style="width:100%;accent-color:#facc15;">
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:11px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:8px;">
        <span style="color:#cbd5e1;">Screen Shake</span>
        <button onclick="this.textContent=this.textContent==='ON'?'OFF':'ON';this.style.background=this.textContent==='ON'?'#16a34a':'#475569';" style="background:#16a34a;color:white;border:none;padding:4px 14px;border-radius:6px;cursor:pointer;font-size:12px;">ON</button>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:11px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:8px;">
        <span style="color:#cbd5e1;">Damage Numbers</span>
        <button onclick="this.textContent=this.textContent==='ON'?'OFF':'ON';this.style.background=this.textContent==='ON'?'#16a34a':'#475569';" style="background:#16a34a;color:white;border:none;padding:4px 14px;border-radius:6px;cursor:pointer;font-size:12px;">ON</button>
      </div>
    </div>
  `;

  const CREDITS_HTML = `
    <div style="text-align:center;display:flex;flex-direction:column;gap:18px;font-size:13px;color:#cbd5e1;">
      <div>
        <div style="color:#64748b;font-size:10px;letter-spacing:3px;margin-bottom:4px;">GAME DESIGN & PROGRAMMING</div>
        <div style="font-size:17px;font-weight:700;color:#f8fafc;">Developer</div>
      </div>
      <hr style="border:none;border-top:1px solid rgba(255,255,255,.07);">
      <div>
        <div style="color:#64748b;font-size:10px;letter-spacing:3px;margin-bottom:4px;">BUILT WITH</div>
        <div style="font-weight:700;color:#38bdf8;font-size:15px;">HTML5 Canvas + TypeScript</div>
      </div>
      <div style="font-size:11px;color:#334155;">Thank you for playing ❤️</div>
    </div>
  `;

  // ── Helper: divider ───────────────────────────────────────────────────────
  const makeDivider = (): HTMLElement => {
    const hr = document.createElement('hr');
    Object.assign(hr.style, {
      border: 'none', borderTop: '1px solid rgba(255,255,255,.07)',
      width: '100%', margin: '4px 0 10px',
    });
    return hr;
  };

  // ── Continue button ───────────────────────────────────────────────────────
  try {
    const runSaveRaw = localStorage.getItem('run_save_v1');
    if (runSaveRaw && onContinue) {
      const runSave = JSON.parse(runSaveRaw);
      const waveNum = runSave?.wave ?? '?';
      const continueBtn = createBtn('▶  Continue Run', onContinue, 'continue');
      continueBtn.style.justifyContent = 'space-between';
      const waveTag = document.createElement('span');
      waveTag.textContent = `Wave ${waveNum}`;
      Object.assign(waveTag.style, {
        fontSize: '10px', background: 'rgba(52,211,153,.15)',
        padding: '2px 8px', borderRadius: '5px', pointerEvents: 'none',
      });
      continueBtn.appendChild(waveTag);
      menu.appendChild(continueBtn);
    }
  } catch (_) {}

  // ── Start Run (primary) ───────────────────────────────────────────────────
  const startBtn = createBtn('⚔  New Run', onStart, 'primary');
  startBtn.style.justifyContent = 'center';
  menu.appendChild(startBtn);

  menu.appendChild(makeDivider());

  // ── Library & Meta buttons ────────────────────────────────────────────────
  const libraryBtn = createBtn('📚  Library', () => {
    backdrop.style.display = 'none';
    const lib = createLibraryMenu(() => {
      document.body.removeChild(lib);
      backdrop.style.display = 'flex';
    });
    document.body.appendChild(lib);
  });

  const metaBtn = createBtn('⚙  Meta / Upgrades', () => {
    backdrop.style.display = 'none';
    const meta = createMetaMenu(() => {
      document.body.removeChild(meta);
      backdrop.style.display = 'flex';
    });
    document.body.appendChild(meta);
  });

  menu.appendChild(libraryBtn);
  menu.appendChild(metaBtn);
  menu.appendChild(makeDivider());

  // ── Secondary buttons ─────────────────────────────────────────────────────
  menu.appendChild(createBtn('How To Play', () => openInfoPanel('HOW TO PLAY', HOW_TO_PLAY_HTML)));
  menu.appendChild(createBtn('Controls',    () => openInfoPanel('CONTROLS',    CONTROLS_HTML)));
  menu.appendChild(createBtn('Settings',    () => openInfoPanel('SETTINGS',    SETTINGS_HTML)));
  menu.appendChild(createBtn('Credits',     () => openInfoPanel('CREDITS',     CREDITS_HTML)));

  // ── Version ───────────────────────────────────────────────────────────────
  const ver = document.createElement('div');
  ver.textContent = (window as any).GAME_VERSION || 'v0.1';
  Object.assign(ver.style, { marginTop: '14px', fontSize: '10px', color: '#1e293b', letterSpacing: '1px' });
  menu.appendChild(ver);

  backdrop.appendChild(menu);
  return backdrop;
}
