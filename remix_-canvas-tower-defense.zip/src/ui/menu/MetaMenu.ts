import { MetaSystem } from '../../game/core/MetaSystem';

function showCustomAlert(message: string) {
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', background: 'rgba(0,0,0,0.8)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: '9999',
    fontFamily: 'Segoe UI,system-ui,sans-serif'
  });

  const modal = document.createElement('div');
  Object.assign(modal.style, {
    background: '#0f172a', border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: '12px', padding: '24px', maxWidth: '400px', width: '90%',
    textAlign: 'center', color: '#f8fafc', boxShadow: '0 20px 40px rgba(0,0,0,0.5)'
  });

  const msg = document.createElement('div');
  msg.textContent = message;
  msg.style.marginBottom = '20px';
  msg.style.whiteSpace = 'pre-wrap';

  const btn = document.createElement('button');
  btn.textContent = 'OK';
  Object.assign(btn.style, {
    padding: '8px 24px', borderRadius: '6px', background: '#3b82f6',
    color: '#fff', border: 'none', cursor: 'pointer', fontWeight: '600'
  });
  btn.onclick = () => overlay.remove();

  modal.appendChild(msg);
  modal.appendChild(btn);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

function showCustomConfirm(message: string, onConfirm: () => void) {
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', background: 'rgba(0,0,0,0.8)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: '9999',
    fontFamily: 'Segoe UI,system-ui,sans-serif'
  });

  const modal = document.createElement('div');
  Object.assign(modal.style, {
    background: '#0f172a', border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: '12px', padding: '24px', maxWidth: '400px', width: '90%',
    textAlign: 'center', color: '#f8fafc', boxShadow: '0 20px 40px rgba(0,0,0,0.5)'
  });

  const msg = document.createElement('div');
  msg.textContent = message;
  msg.style.marginBottom = '24px';
  msg.style.whiteSpace = 'pre-wrap';

  const btnRow = document.createElement('div');
  Object.assign(btnRow.style, { display: 'flex', gap: '12px', justifyContent: 'center' });

  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  Object.assign(cancelBtn.style, {
    padding: '8px 20px', borderRadius: '6px', background: 'transparent',
    color: '#94a3b8', border: '1px solid #334155', cursor: 'pointer', fontWeight: '600'
  });
  cancelBtn.onclick = () => overlay.remove();

  const confirmBtn = document.createElement('button');
  confirmBtn.textContent = 'Confirm';
  Object.assign(confirmBtn.style, {
    padding: '8px 20px', borderRadius: '6px', background: '#8b5cf6',
    color: '#fff', border: 'none', cursor: 'pointer', fontWeight: '600'
  });
  confirmBtn.onclick = () => {
    overlay.remove();
    onConfirm();
  };

  btnRow.appendChild(cancelBtn);
  btnRow.appendChild(confirmBtn);
  modal.appendChild(msg);
  modal.appendChild(btnRow);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

export function createMetaMenu(onClose: () => void): HTMLElement {
  const F = 'Segoe UI,system-ui,sans-serif';

  if (!document.getElementById('td-meta-menu-style')) {
    const s = document.createElement('style');
    s.id = 'td-meta-menu-style';
    s.textContent = `
      @keyframes td-meta-in { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
      .td-meta-panel { animation: td-meta-in .3s ease both; }
      .td-meta-tab { transition: color .15s, border-color .15s; }
      .td-meta-tab:hover:not(.tm-active) { color: #94a3b8 !important; }
      .td-upg-card { transition: border-color .18s; }
      .td-upg-card:hover { border-color: rgba(250,204,21,.25) !important; }
      .td-upg-btn { transition: background .15s; }
      .td-upg-btn:hover:not(:disabled) { background: rgba(250,204,21,.2) !important; }
      .td-upg-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    `;
    document.head.appendChild(s);
  }

  // ── Load meta state ────────────────────────────────────────────────────────
  let metaState = MetaSystem.load();

  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', background: 'rgba(0,0,0,.82)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: '1000',
  });

  const panel = document.createElement('div');
  panel.className = 'td-meta-panel';
  Object.assign(panel.style, {
    background: '#060b14', border: '1px solid rgba(250,204,21,.15)',
    borderRadius: '16px', width: '90%', maxWidth: '520px', maxHeight: '82vh',
    display: 'flex', flexDirection: 'column', overflow: 'hidden', fontFamily: F,
  });

  // ── Header ─────────────────────────────────────────────────────────────────
  const header = document.createElement('div');
  Object.assign(header.style, { background: '#0a1525', padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid rgba(250,204,21,.12)', flexShrink: '0' });
  const ht = document.createElement('span');
  ht.textContent = 'META / UPGRADES';
  Object.assign(ht.style, { fontSize: '12px', letterSpacing: '4px', color: '#facc15', fontWeight: '700' });
  const cb = document.createElement('button');
  cb.textContent = '✕';
  Object.assign(cb.style, { width: '28px', height: '28px', borderRadius: '50%', background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)', color: '#94a3b8', cursor: 'pointer', fontSize: '13px', fontFamily: F });
  cb.onclick = onClose;
  header.appendChild(ht); header.appendChild(cb);

  // ── Tabs ───────────────────────────────────────────────────────────────────
  type MTab = 'UPGRADES' | 'PRESTIGE' | 'CORRUPTION';
  const MTABS: MTab[] = ['UPGRADES', 'PRESTIGE', 'CORRUPTION'];
  let activeTab: MTab = 'UPGRADES';

  const tabBar = document.createElement('div');
  Object.assign(tabBar.style, { display: 'flex', background: '#0a1525', borderBottom: '1px solid rgba(255,255,255,.06)', flexShrink: '0' });
  const mTabBtns: Partial<Record<MTab, HTMLButtonElement>> = {};
  MTABS.forEach(t => {
    const btn = document.createElement('button');
    btn.className = 'td-meta-tab';
    btn.textContent = t;
    Object.assign(btn.style, { flex: '1', padding: '10px 4px', fontSize: '10px', letterSpacing: '1.5px', color: '#334155', background: 'none', border: 'none', borderBottom: '2px solid transparent', cursor: 'pointer', fontFamily: F, textAlign: 'center' });
    btn.onclick = () => switchMTab(t);
    mTabBtns[t] = btn;
    tabBar.appendChild(btn);
  });

  const body = document.createElement('div');
  Object.assign(body.style, { padding: '18px', overflowY: 'auto', flex: '1' });

  const el = (tag: string, styles: Partial<CSSStyleDeclaration> = {}, text?: string): HTMLElement => {
    const e = document.createElement(tag);
    Object.assign(e.style, styles);
    if (text !== undefined) e.textContent = text;
    return e;
  };

  // ── Tab: UPGRADES ──────────────────────────────────────────────────────────
  const UPG_DEFS = [
    { key: 'damage', icon: '⚔', name: 'Damage',  desc: '+10% base damage per level', maxLv: 10 },
    { key: 'gold',   icon: '💰', name: 'Gold',    desc: '+10% starting gold per level', maxLv: 10 },
    { key: 'life',   icon: '❤', name: 'Life',    desc: '+5 starting lives per level', maxLv: 5 },
    { key: 'crit',   icon: '🎯', name: 'Crit',   desc: '+5% crit chance per level', maxLv: 10 },
  ];
  const UPG_COST_BASE = 100;
  const getUpgCost = (lv: number) => UPG_COST_BASE + lv * 50;

  function renderUpgrades(): HTMLElement {
    const wrap = document.createElement('div');

    // Ink bar
    const inkBar = el('div', { background: 'rgba(139,92,246,.08)', border: '1px solid rgba(139,92,246,.18)', borderRadius: '10px', padding: '11px 16px', display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '18px' });
    const inkIcon = el('div', { width: '28px', height: '28px', borderRadius: '50%', background: 'rgba(139,92,246,.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', flexShrink: '0' }, '✦');
    const inkInfo = el('div');
    const inkVal = el('div', { fontSize: '20px', fontWeight: '700', color: '#a78bfa' });
    inkVal.id = 'td-meta-ink-val';
    inkVal.textContent = (metaState.ink || 0) + ' Ink';
    inkInfo.appendChild(inkVal);
    inkInfo.appendChild(el('div', { fontSize: '10px', color: '#4c1d95', letterSpacing: '1px' }, 'AVAILABLE TO SPEND'));
    inkBar.appendChild(inkIcon); inkBar.appendChild(inkInfo);
    wrap.appendChild(inkBar);

    const grid = el('div', { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' });
    UPG_DEFS.forEach(u => {
      const lv = metaState.upgrades[u.key as keyof typeof metaState.upgrades] || 0;
      const cost = getUpgCost(lv);
      const maxed = lv >= u.maxLv;
      const card = el('div', { background: '#0f1e35', border: '1px solid rgba(255,255,255,.08)', borderRadius: '12px', padding: '14px', display: 'flex', flexDirection: 'column', gap: '6px' });
      card.className = 'td-upg-card';
      card.appendChild(el('div', { fontSize: '18px' }, u.icon));
      card.appendChild(el('div', { fontSize: '13px', fontWeight: '600', color: '#e2e8f0' }, u.name));
      card.appendChild(el('div', { fontSize: '11px', color: '#475569', lineHeight: '1.5' }, u.desc));

      const starsRow = el('div', { display: 'flex', gap: '3px', marginTop: '2px' });
      for (let i = 0; i < u.maxLv; i++) {
        const star = el('div', { width: '7px', height: '7px', borderRadius: '50%', background: i < lv ? '#facc15' : 'rgba(255,255,255,.1)' });
        starsRow.appendChild(star);
      }

      const bottomRow = el('div', { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '4px' });
      bottomRow.appendChild(starsRow);
      const btn = document.createElement('button');
      btn.className = 'td-upg-btn';
      btn.textContent = maxed ? 'MAX' : `Lv.${lv}→${lv+1}`;
      (btn as HTMLButtonElement).disabled = maxed || (metaState.ink || 0) < cost;
      Object.assign(btn.style, { padding: '5px 11px', borderRadius: '6px', fontSize: '11px', border: '1px solid rgba(250,204,21,.4)', background: 'rgba(250,204,21,.08)', color: '#facc15', cursor: 'pointer', fontFamily: F });
      btn.onclick = () => {
        const curLv = metaState.upgrades[u.key as keyof typeof metaState.upgrades] || 0;
        const c = getUpgCost(curLv);
        if ((metaState.ink || 0) < c || curLv >= u.maxLv) return;
        metaState.ink = (metaState.ink || 0) - c;
        (metaState.upgrades as any)[u.key] = curLv + 1;
        MetaSystem.save(metaState);
        // Refresh tab
        body.innerHTML = '';
        body.appendChild(renderUpgrades());
      };
      bottomRow.appendChild(btn);
      card.appendChild(bottomRow);
      card.appendChild(el('div', { fontSize: '10px', color: '#334155', marginTop: '2px' }, maxed ? '— MAX LEVEL —' : `Cost: ${cost} Ink`));
      grid.appendChild(card);
    });
    wrap.appendChild(grid);
    return wrap;
  }

  // ── Tab: PRESTIGE ──────────────────────────────────────────────────────────
  function renderPrestige(): HTMLElement {
    const { default: metaSaveManagerModule } = { default: null } as any;
    let highestWave = 0, totalRuns = 0, prestigeLevel = 0, voidEssence = 0;
    try {
      const raw = localStorage.getItem('td_meta_save');
      if (raw) {
        const d = JSON.parse(raw);
        highestWave = d?.statistics?.highestWave || 0;
        totalRuns   = d?.statistics?.totalRuns || 0;
        prestigeLevel = d?.prestigeLevel || 0;
        voidEssence   = d?.voidEssence || 0;
      }
    } catch (e) {}

    const wrap = el('div', { display: 'flex', flexDirection: 'column', gap: '14px' });

    const statGrid = el('div', { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' });
    ([['Prestige Lv', String(prestigeLevel)], [`Wave ${highestWave}`, 'BEST WAVE'], [String(totalRuns), 'TOTAL RUNS']] as [string,string][]).forEach(([val, lbl]) => {
      const card = el('div', { background: '#0f1e35', border: '1px solid rgba(255,255,255,.07)', borderRadius: '10px', padding: '14px', textAlign: 'center' });
      card.appendChild(el('div', { fontSize: '20px', fontWeight: '700', color: '#f8fafc', marginBottom: '4px' }, val));
      card.appendChild(el('div', { fontSize: '10px', color: '#475569', letterSpacing: '1px' }, lbl));
      statGrid.appendChild(card);
    });
    wrap.appendChild(statGrid);

    const voidCard = el('div', { background: '#0f1e35', border: '1px solid rgba(255,255,255,.07)', borderRadius: '12px', padding: '18px' });
    voidCard.appendChild(el('div', { fontSize: '10px', color: '#334155', letterSpacing: '2px', marginBottom: '10px' }, 'VOID ESSENCE'));
    const voidRow = el('div', { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' });
    voidRow.appendChild(el('div', { fontSize: '26px', fontWeight: '700', color: '#c4b5fd' }, String(voidEssence)));
    voidRow.appendChild(el('div', { fontSize: '11px', color: '#6b7280', lineHeight: '1.6' }, 'Earned through Prestige.\nUsed to unlock and upgrade Relics.'));
    voidCard.appendChild(voidRow);
    wrap.appendChild(voidCard);

    const presCard = el('div', { background: 'rgba(139,92,246,.08)', border: '1px solid rgba(139,92,246,.25)', borderRadius: '12px', padding: '16px', display: 'flex', alignItems: 'center', gap: '14px' });
    const presInfo = el('div', { flex: '1' });
    presInfo.appendChild(el('div', { fontSize: '13px', color: '#c4b5fd', fontWeight: '600', marginBottom: '4px' }, 'Perform Prestige'));
    presInfo.appendChild(el('div', { fontSize: '11px', color: '#6b7280', lineHeight: '1.6' }, 'Resets the current run. Earn Void Essence\nbased on the highest wave reached.'));
    const presBtn = document.createElement('button');
    presBtn.textContent = 'Prestige ✦';
    Object.assign(presBtn.style, { padding: '10px 18px', borderRadius: '8px', background: 'linear-gradient(135deg,#7c3aed,#4f46e5)', color: '#fff', border: 'none', fontSize: '12px', fontWeight: '600', cursor: 'pointer', fontFamily: F, whiteSpace: 'nowrap' });
    presBtn.onclick = () => {
      const game = (window as any).gameInstance;
      if (!game) {
        showCustomAlert("Game not running.");
        return;
      }
      
      const stats = game.getRunStats();
      const reward = game.prestigeSystem.calculateReward(stats);

      const confirmMsg = `Prestige Reward: +${reward.total} Void Essence\n\nWave: ${stats.highestWave}\n\nContinue?`;

      showCustomConfirm(confirmMsg, () => {
        game.prestigeSystem.performPrestige(stats);
        game.prestigeSystem.resetRun(game);

        location.reload();
      });
    };
    presCard.appendChild(presInfo); presCard.appendChild(presBtn);
    wrap.appendChild(presCard);
    return wrap;
  }

  // ── Tab: CORRUPTION ────────────────────────────────────────────────────────
  const CORRUPTIONS = [
    { name: 'Unstable Core', desc: '+40% damage, 20% miss chance',        tags: ['DMG +40%', 'MISS 20%'] },
    { name: 'Blood Pact',    desc: '+50% damage, attack speed −60%',      tags: ['DMG +50%', 'SPD −60%'] },
    { name: 'Overclock',     desc: '+50% attack speed, −40% damage',      tags: ['SPD +50%', 'DMG −40%'] },
    { name: 'Frozen Core',   desc: '+50% slow duration, −25% damage',     tags: ['SLOW +50%', 'DMG −25%'] },
    { name: 'Firework',      desc: '+3 projectiles, +25% splash & range', tags: ['PROJ +3', 'SPLASH +25%'] },
  ];

  function renderCorruption(): HTMLElement {
    let shards = 0;
    try {
      const raw = localStorage.getItem('td_meta_save');
      if (raw) shards = JSON.parse(raw)?.corruptedShards || 0;
    } catch (e) {}

    const wrap = el('div', { display: 'flex', flexDirection: 'column', gap: '12px' });

    const shardBar = el('div', { background: 'rgba(239,68,68,.08)', border: '1px solid rgba(239,68,68,.2)', borderRadius: '10px', padding: '11px 16px', display: 'flex', alignItems: 'center', gap: '10px' });
    shardBar.appendChild(el('div', { fontSize: '20px' }, '◆'));
    const shardInfo = el('div');
    shardInfo.appendChild(el('div', { fontSize: '18px', fontWeight: '700', color: '#f87171' }, `${shards} Corrupted Shards`));
    shardInfo.appendChild(el('div', { fontSize: '10px', color: '#4b5563', letterSpacing: '1px' }, 'AVAILABLE'));
    shardBar.appendChild(shardInfo);
    wrap.appendChild(shardBar);

    const grid = el('div', { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' });
    CORRUPTIONS.forEach(c => {
      const card = el('div', { background: '#0f1e35', border: '1px solid rgba(239,68,68,.15)', borderRadius: '12px', padding: '13px' });
      card.appendChild(el('div', { fontSize: '12px', fontWeight: '600', color: '#fca5a5', marginBottom: '5px' }, c.name));
      card.appendChild(el('div', { fontSize: '11px', color: '#475569', lineHeight: '1.5', marginBottom: '8px' }, c.desc));
      const tagsRow = el('div', { display: 'flex', gap: '5px', flexWrap: 'wrap' });
      c.tags.forEach(t => tagsRow.appendChild(el('span', { padding: '2px 7px', borderRadius: '4px', fontSize: '10px', background: 'rgba(239,68,68,.12)', color: '#fca5a5', border: '1px solid rgba(239,68,68,.2)' }, t)));
      card.appendChild(tagsRow);
      grid.appendChild(card);
    });
    wrap.appendChild(grid);
    return wrap;
  }

  // ── switchMTab ─────────────────────────────────────────────────────────────
  const mRenderers: Record<MTab, () => HTMLElement> = {
    UPGRADES: renderUpgrades, PRESTIGE: renderPrestige, CORRUPTION: renderCorruption,
  };

  function switchMTab(tab: MTab) {
    activeTab = tab;
    MTABS.forEach(t => {
      const btn = mTabBtns[t]!;
      btn.style.color = t === tab ? '#facc15' : '#334155';
      btn.style.borderBottom = t === tab ? '2px solid #facc15' : '2px solid transparent';
    });
    body.innerHTML = '';
    body.appendChild(mRenderers[tab]());
  }

  // ── Assemble ───────────────────────────────────────────────────────────────
  panel.appendChild(header); panel.appendChild(tabBar); panel.appendChild(body);
  overlay.appendChild(panel);
  switchMTab('UPGRADES');
  return overlay;
}
