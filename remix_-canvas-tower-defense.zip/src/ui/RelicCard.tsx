import React from 'react';
import { RelicDefinition, RelicTier } from '../game/systems/relic/RelicDefinitions';

interface RelicCardProps {
  relic: RelicDefinition;
  currentLevel: number;
  nextLevel: number;
  nextCost: number;
  maxLevel: number;
  canAfford: boolean;
  isUnlocked: boolean;
  onPurchase: (relicId: string) => void;
  onReset?: (relicId: string) => void;
}

const TIER_COLORS = {
  [RelicTier.COMMON]: { border: 'border-gray-400', bg: 'bg-gray-100', text: 'text-gray-700', name: 'COMMON' },
  [RelicTier.UNCOMMON]: { border: 'border-green-500', bg: 'bg-green-50', text: 'text-green-700', name: 'UNCOMMON' },
  [RelicTier.RARE]: { border: 'border-blue-500', bg: 'bg-blue-50', text: 'text-blue-700', name: 'RARE' },
  [RelicTier.EPIC]: { border: 'border-purple-500', bg: 'bg-purple-50', text: 'text-purple-700', name: 'EPIC' },
  [RelicTier.LEGENDARY]: { border: 'border-yellow-500', bg: 'bg-yellow-50', text: 'text-yellow-700', name: 'LEGENDARY' },
};

export function RelicCard(props: RelicCardProps) {
  const { relic, currentLevel, nextLevel, nextCost, maxLevel, canAfford, isUnlocked, onPurchase, onReset } = props;
  const tierStyle = TIER_COLORS[relic.tier];
  
  const isMaxed = currentLevel >= maxLevel;
  const progressPercent = Math.min(100, (currentLevel / maxLevel) * 100);

  // Calculate current bonus string
  let currentBonusStr = '';
  if (currentLevel > 0) {
    const effectKeys = Object.keys(relic.effect) as (keyof typeof relic.effect)[];
    const bonuses = effectKeys.map(key => {
      const val = relic.effect[key]! * currentLevel;
      // Format as percentage if it's a percent stat, else flat
      if (key.includes('Percent') || key === 'critChance') {
        return `+${Math.round(val * 100)}% ${key.replace('Percent', '')}`;
      }
      return `+${val} ${key}`;
    });
    currentBonusStr = bonuses.join(', ');
  }

  return (
    <div className={`relative border-2 ${tierStyle.border} ${tierStyle.bg} rounded-xl p-4 flex flex-col gap-3 shadow-sm hover:shadow-md transition-shadow group`}>
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-bold text-lg text-slate-800 leading-tight">{relic.name}</h3>
          <span className={`text-xs font-bold tracking-wider ${tierStyle.text}`}>{tierStyle.name}</span>
        </div>
        <div className="text-right">
          <div className="text-sm font-semibold text-slate-700">Lv {currentLevel} / {maxLevel}</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 transition-all duration-300" 
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Description & Bonus */}
      <div className="flex-1">
        <p className="text-sm text-slate-600 mb-2">{relic.description}</p>
        {currentLevel > 0 && (
          <p className="text-sm font-bold text-indigo-600">{currentBonusStr}</p>
        )}
      </div>

      {/* Action Area */}
      <div className="mt-auto pt-3 border-t border-slate-200/50 flex items-center justify-between">
        {!isUnlocked ? (
          <div className="w-full text-center py-2 text-sm font-bold text-slate-500 bg-slate-200 rounded-lg">
            Unlock at wave {relic.unlockedAtWave}
          </div>
        ) : isMaxed ? (
          <button disabled className="w-full py-2 bg-green-500 text-white font-bold rounded-lg cursor-not-allowed">
            MAX LEVEL
          </button>
        ) : (
          <button
            onClick={() => onPurchase(relic.id)}
            disabled={!canAfford}
            aria-label={`Upgrade ${relic.name} for ${nextCost} void essence`}
            className={`w-full py-2 font-bold rounded-lg transition-colors flex justify-center items-center gap-2 ${
              canAfford 
                ? 'bg-blue-500 hover:bg-blue-600 text-white shadow-sm' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            <span>Upgrade</span>
            <span className="text-xs bg-black/20 px-2 py-0.5 rounded-full">{nextCost} VE</span>
          </button>
        )}
      </div>

      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-slate-900 text-slate-200 text-xs rounded-lg shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-10 hidden md:block">
        <div className="font-bold text-white mb-1">{relic.name}</div>
        <div className="mb-2 text-slate-400">{relic.description}</div>
        
        {!isMaxed && (
          <div className="border-t border-slate-700 pt-2 mt-2">
            <div className="font-semibold text-slate-300 mb-1">Next Levels:</div>
            <div className="flex justify-between"><span>Lv {nextLevel}</span><span className="text-purple-400">{nextCost} VE</span></div>
            {nextLevel + 1 <= maxLevel && (
              <div className="flex justify-between"><span>Lv {nextLevel + 1}</span><span className="text-purple-400">{Math.floor(relic.baseCost * Math.pow(1.15, nextLevel))} VE</span></div>
            )}
            {nextLevel + 2 <= maxLevel && (
              <div className="flex justify-between"><span>Lv {nextLevel + 2}</span><span className="text-purple-400">{Math.floor(relic.baseCost * Math.pow(1.15, nextLevel + 1))} VE</span></div>
            )}
          </div>
        )}
      </div>

      {/* Reset Button (Optional) */}
      {onReset && currentLevel > 20 && (
        <button 
          onClick={() => onReset(relic.id)}
          className="absolute -top-2 -right-2 w-6 h-6 bg-slate-200 hover:bg-red-100 text-slate-500 hover:text-red-500 rounded-full flex items-center justify-center text-xs shadow-sm transition-colors"
          title="Reset Relic"
        >
          ✕
        </button>
      )}
    </div>
  );
}
