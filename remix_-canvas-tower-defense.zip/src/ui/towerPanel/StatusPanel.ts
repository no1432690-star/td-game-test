import { CorruptionType } from "../../game/entities/Tower"

export function createStatusPanel(tower: any) {
  const panel = document.createElement("div")
  panel.style.marginTop = "8px"

  if (tower.isLegendary) {
    const text = document.createElement("div")
    text.innerText = "+50% all base stats"
    panel.appendChild(text)
  }

  if (tower.corruptionType !== null && tower.corruptionType !== undefined) {
    const text = document.createElement("div")
    let cType = tower.corruptionType;
    if (typeof cType === 'number') {
      cType = CorruptionType[cType];
    }
    text.innerText = "Corruption: " + cType
    panel.appendChild(text)
  }

  return panel
}
