export function getTowerStatBreakdown(tower: any) {
  const breakdown = {
    base: tower.baseDamage || 0,
    flat: [] as string[],
    percent: [] as string[],
    multiplier: [] as string[]
  };

  if (tower.level > 1) {
    const originalBase = tower.baseDamage / Math.pow(1.15, tower.level - 1);
    breakdown.base = Number(originalBase.toFixed(2));
    const upgradeBonus = tower.baseDamage - originalBase;
    if (upgradeBonus > 0.01) {
      breakdown.flat.push(`+${Number(upgradeBonus.toFixed(2))} upgrade`);
    }
  } else {
    breakdown.base = Number(tower.baseDamage.toFixed(2));
  }

  if (tower.bonusDamageMultiplier && tower.bonusDamageMultiplier !== 1) {
    breakdown.multiplier.push(`×${Number(tower.bonusDamageMultiplier.toFixed(2))} meta`);
  }

  if (tower.isLegendary) {
    breakdown.multiplier.push(`×1.5 mutation`);
  }

  const expectedDamage = tower.baseDamage * (tower.bonusDamageMultiplier || 1) * (tower.isLegendary ? 1.5 : 1);
  const ratio = tower.damage / expectedDamage;
  
  if (Math.abs(ratio - 1) > 0.01) {
    const percent = Math.round((ratio - 1) * 100);
    if (tower.corruptionType !== null && tower.corruptionType !== undefined) {
      breakdown.percent.push(`${percent > 0 ? '+' : ''}${percent}% corruption/run`);
    } else {
      breakdown.percent.push(`${percent > 0 ? '+' : ''}${percent}% run`);
    }
  }

  return breakdown;
}

export function createStatModifiersPanel(tower: any) {
  const breakdown = getTowerStatBreakdown(tower);
  
  const hasModifiers = breakdown.flat.length > 0 || breakdown.percent.length > 0 || breakdown.multiplier.length > 0;
  if (!hasModifiers) return null;

  const container = document.createElement("div");
  container.style.marginTop = "12px";
  container.style.paddingTop = "12px";
  container.style.borderTop = "1px solid #334155";
  container.style.fontSize = "12px";
  container.style.color = "#94a3b8";

  const title = document.createElement("div");
  title.innerText = "Stat Modifiers";
  title.style.fontWeight = "bold";
  title.style.color = "#e2e8f0";
  title.style.marginBottom = "4px";
  container.appendChild(title);

  const baseRow = document.createElement("div");
  baseRow.innerText = `Base: ${breakdown.base}`;
  container.appendChild(baseRow);

  breakdown.flat.forEach(mod => {
    const row = document.createElement("div");
    row.innerText = mod;
    container.appendChild(row);
  });

  breakdown.percent.forEach(mod => {
    const row = document.createElement("div");
    row.innerText = mod;
    container.appendChild(row);
  });

  breakdown.multiplier.forEach(mod => {
    const row = document.createElement("div");
    row.innerText = mod;
    container.appendChild(row);
  });

  try {
    const game = (window as any).gameInstance;
    if (game && game.upgradeManager) {
      const activeBuffs = Object.entries(game.upgradeManager.activeUpgrades || {})
        .filter(([, v]) => (v as number) > 0)
        .slice(0, 4);
      
      if (activeBuffs.length > 0) {
        const title = document.createElement("div");
        title.innerText = "ACTIVE RUN UPGRADES";
        title.style.fontSize = "8px";
        title.style.letterSpacing = "2px";
        title.style.color = "#1e3a5f";
        title.style.marginBottom = "4px";
        title.style.marginTop = "8px";
        title.style.fontFamily = '"Segoe UI", system-ui, sans-serif';
        container.appendChild(title);

        activeBuffs.forEach(([id, stacks]) => {
          const name = id.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
          const row = document.createElement("div");
          row.style.display = "flex";
          row.style.justifyContent = "space-between";
          row.style.padding = "2px 0";
          
          const nameSpan = document.createElement("span");
          nameSpan.style.fontSize = "11px";
          nameSpan.style.color = "#4b5563";
          nameSpan.style.fontFamily = '"Segoe UI", system-ui, sans-serif';
          nameSpan.innerText = name;
          
          const stackSpan = document.createElement("span");
          stackSpan.style.fontSize = "11px";
          stackSpan.style.color = "#34d399";
          stackSpan.style.fontWeight = "500";
          stackSpan.style.fontFamily = '"Segoe UI", system-ui, sans-serif';
          stackSpan.innerText = `×${stacks}`;
          
          row.appendChild(nameSpan);
          row.appendChild(stackSpan);
          container.appendChild(row);
        });
      }
    }
  } catch (_) {}

  return container;
}
