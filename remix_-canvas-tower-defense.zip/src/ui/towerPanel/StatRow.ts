export function createStatRow(name: string, value: any, previewValue: any = null) {
  const row = document.createElement("div")
  row.style.display = "flex"
  row.style.justifyContent = "space-between"
  row.style.marginBottom = "4px"

  const label = document.createElement("span")
  label.innerText = name

  const valueText = document.createElement("span")

  if (previewValue !== null && previewValue !== value) {
    valueText.innerText = value + " → " + previewValue
  } else {
    valueText.innerText = value
  }

  row.appendChild(label)
  row.appendChild(valueText)

  return row
}
