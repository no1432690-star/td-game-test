import { ENABLE_TESLA_FLOW, ENABLE_TESLA_ADVANCED_FLOW, getFlowMultiplier } from "../../game/systems/TeslaTopologySystem";

export function createTeslaDebugPanel(tower: any) {
  if (!ENABLE_TESLA_FLOW) return null;

  const container = document.createElement("div");
  container.style.marginTop = "12px";
  container.style.padding = "8px";
  container.style.background = "rgba(0, 0, 0, 0.3)";
  container.style.borderRadius = "6px";
  container.style.fontSize = "12px";
  container.style.fontFamily = "monospace";

  if (tower.constructor.name === "Tesla") {
    const title = document.createElement("div");
    title.textContent = "TESLA";
    title.style.fontWeight = "bold";
    title.style.color = "#fbbf24";
    title.style.marginBottom = "4px";
    container.appendChild(title);

    const mode = document.createElement("div");
    mode.textContent = `Mode: ${tower.flowMode || "BALANCED"}`;
    container.appendChild(mode);

    const energy = document.createElement("div");
    energy.textContent = `Energy: ${Math.round(tower.energy || 100)}`;
    container.appendChild(energy);

    const upgradeManager = (window as any).gameInstance?.upgradeManager;
    if (upgradeManager) {
      const extraBuffStrength = upgradeManager.getRawClassStat('Tesla', 'tesla_buff_global');
      const extraLinks = upgradeManager.getRawClassStat('Tesla', 'tesla_max_links');
      const extraEnergy = upgradeManager.getRawClassStat('Tesla', 'tesla_energy_bonus');
      const extraTopology = upgradeManager.getRawClassStat('Tesla', 'tesla_topology_bonus');
      const extraFocused = upgradeManager.getRawClassStat('Tesla', 'tesla_focused_bonus');

      if (extraBuffStrength > 0 || extraLinks > 0 || extraEnergy > 0 || extraTopology > 0 || extraFocused > 0) {
        const upgradesTitle = document.createElement("div");
        upgradesTitle.textContent = "RUN UPGRADES";
        upgradesTitle.style.fontWeight = "bold";
        upgradesTitle.style.color = "#34d399";
        upgradesTitle.style.marginTop = "8px";
        upgradesTitle.style.marginBottom = "4px";
        container.appendChild(upgradesTitle);

        if (extraBuffStrength > 0) {
          const div = document.createElement("div");
          div.textContent = `Buff Strength: +${Math.round(extraBuffStrength * 100)}%`;
          container.appendChild(div);
        }
        if (extraLinks > 0) {
          const div = document.createElement("div");
          div.textContent = `Max Links: +${extraLinks}`;
          container.appendChild(div);
        }
        if (extraEnergy > 0) {
          const div = document.createElement("div");
          div.textContent = `Starting Energy: +${extraEnergy}`;
          container.appendChild(div);
        }
        if (extraTopology > 0) {
          const div = document.createElement("div");
          div.textContent = `Topology Bonus: +${Math.round(extraTopology * 100)}%`;
          container.appendChild(div);
        }
        if (extraFocused > 0) {
          const div = document.createElement("div");
          div.textContent = `Focused Mode: +${Math.round(extraFocused * 100)}%`;
          container.appendChild(div);
        }
      }
    }

    if (ENABLE_TESLA_ADVANCED_FLOW) {
      const depth = document.createElement("div");
      depth.textContent = `Depth: ${tower.depth || 0}`;
      container.appendChild(depth);
    }

    const target = document.createElement("div");
    let targetText = "None";
    if (tower.flowTarget) {
      targetText = `Tesla at (${Math.round(tower.flowTarget.position.x)}, ${Math.round(tower.flowTarget.position.y)})`;
    }
    if (ENABLE_TESLA_ADVANCED_FLOW) {
      target.textContent = `Flow: → ${targetText}`;
    } else {
      target.textContent = `Target: ${targetText}`;
    }
    container.appendChild(target);

    if (ENABLE_TESLA_ADVANCED_FLOW && tower.cluster) {
      const clusterTitle = document.createElement("div");
      clusterTitle.textContent = "TESLA GRID";
      clusterTitle.style.fontWeight = "bold";
      clusterTitle.style.color = "#a78bfa";
      clusterTitle.style.marginTop = "8px";
      clusterTitle.style.marginBottom = "4px";
      container.appendChild(clusterTitle);

      const topology = document.createElement("div");
      topology.textContent = `Topology: ${tower.cluster.topologyType || "NONE"}`;
      container.appendChild(topology);

      let totalEnergy = 0;
      for (let t of tower.cluster) {
        totalEnergy += t.energy || 0;
      }
      const avgEnergy = tower.cluster.length > 0 ? Math.round(totalEnergy / tower.cluster.length) : 0;

      const energyAvg = document.createElement("div");
      energyAvg.textContent = `Energy Avg: ${avgEnergy}`;
      container.appendChild(energyAvg);

      const decay = document.createElement("div");
      decay.textContent = `Decay: ${tower.cluster.decayReduction ? `-${Math.round(tower.cluster.decayReduction * 100)}%` : "0%"}`;
      container.appendChild(decay);

      const transfer = document.createElement("div");
      transfer.textContent = `Transfer: ${tower.cluster.transferBoost ? `+${Math.round(tower.cluster.transferBoost * 100)}%` : "0%"}`;
      container.appendChild(transfer);
    }

  } else {
    if (!tower.teslaLinks || tower.teslaLinks.length === 0) return null;

    const title = document.createElement("div");
    title.textContent = "TESLA INPUT";
    title.style.fontWeight = "bold";
    title.style.color = "#60a5fa";
    title.style.marginBottom = "4px";
    container.appendChild(title);

    const links = document.createElement("div");
    links.textContent = `Links: ${tower.teslaLinks.length}`;
    container.appendChild(links);

    for (let t of tower.teslaLinks) {
      const linkInfo = document.createElement("div");
      linkInfo.style.color = "#9ca3af";
      linkInfo.textContent = `E:${Math.round(t.energy)} M:${t.flowMode} C:${t.connections?.length || 0} Topo:${t.cluster?.topologyType || 'NONE'}`;
      container.appendChild(linkInfo);
    }

    let flowBonus = 0;
    for (const tesla of tower.teslaLinks) {
      flowBonus += getFlowMultiplier(tesla) - 1;
    }
    if (ENABLE_TESLA_ADVANCED_FLOW) {
      flowBonus = Math.min(flowBonus, 1.5);
    } else {
      flowBonus = Math.min(flowBonus, 1.0);
    }

    const bonus = document.createElement("div");
    bonus.textContent = `Flow Bonus: +${Math.round(flowBonus * 100)}%`;
    container.appendChild(bonus);
  }

  return container;
}
