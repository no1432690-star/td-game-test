import { TARGET_MODE_LIST, TARGET_MODES } from "../../tower/targetModes"

export function createTargetModeButton(tower: any) {
  const container = document.createElement("div")
  container.style.marginTop = "10px"
  container.style.marginBottom = "10px"
  container.style.display = "flex"
  container.style.justifyContent = "space-between"
  container.style.alignItems = "center"

  const label = document.createElement("span")
  label.innerText = "Target Priority:"
  label.style.fontSize = "14px"

  const button = document.createElement("button")
  
  // Safe fallback
  if (!TARGET_MODE_LIST.includes(tower.targetMode)) {
    tower.targetMode = TARGET_MODES.FIRST;
  }
  
  button.id = "target-mode-btn"
  button.innerText = tower.targetMode
  button.style.background = "#1e293b" // slate-800
  button.style.color = "#cbd5e1" // slate-300
  button.style.border = "1px solid #475569" // slate-600
  button.style.padding = "4px 12px"
  button.style.cursor = "pointer"
  button.style.borderRadius = "6px"
  button.style.fontWeight = "bold"
  button.style.fontSize = "12px"

  button.onmouseup = () => {
    if (typeof tower.cycleTargetMode === 'function') {
      tower.cycleTargetMode()
    } else {
      const list = TARGET_MODE_LIST
      const i = list.indexOf(tower.targetMode)
      tower.targetMode = list[(i + 1) % list.length]
    }
    button.innerText = tower.targetMode
  }

  container.appendChild(label)
  container.appendChild(button)

  return container
}
