export function createUpgradeButton(tower: any, gameGold: number, onUpgrade: (tower: any) => void) {
  const btn = document.createElement("button")

  btn.style.width = "100%"
  btn.style.padding = "8px 16px"
  btn.style.borderRadius = "8px"
  btn.style.fontWeight = "bold"
  btn.style.marginTop = "10px"
  btn.style.transition = "background-color 0.2s"

  if (tower.level >= 25) {
    btn.innerText = "MAX LEVEL"
    btn.disabled = true
    btn.style.background = "#1e293b" // slate-800
    btn.style.color = "#64748b" // slate-500
    btn.style.cursor = "not-allowed"
  } else {
    const cost = tower.getUpgradeCost ? tower.getUpgradeCost() : tower.upgradeCost;
    btn.innerText = `Upgrade (${cost}g)`
    
    if (gameGold < cost) {
      btn.disabled = true
      btn.style.background = "#1e293b" // slate-800
      btn.style.color = "#64748b" // slate-500
      btn.style.cursor = "not-allowed"
    } else {
      btn.style.background = "#2563eb" // blue-600
      btn.style.color = "white"
      btn.style.cursor = "pointer"
      btn.onmouseup = () => {
        onUpgrade(tower)
      }
    }
  }

  return btn
}
