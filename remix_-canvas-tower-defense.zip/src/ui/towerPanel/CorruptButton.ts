import { CorruptedShardManager } from "../../game/systems/CorruptedShardManager"

export function createCorruptButton(tower: any, onCorrupt: (tower: any) => void) {
  const btn = document.createElement("button")

  const cost = CorruptedShardManager.instance.getCorruptionCost()
  
  btn.innerHTML = `Corrupt<br><span style="font-size: 12px; font-weight: normal;">Cost: ${cost} Shards</span>`
  btn.style.background = "#581c87" // purple-900
  btn.style.color = "#e9d5ff" // purple-200
  btn.style.border = "1px solid #7e22ce" // purple-700
  btn.style.padding = "8px 16px"
  btn.style.cursor = "pointer"
  btn.style.borderRadius = "8px"
  btn.style.fontWeight = "bold"
  btn.style.width = "100%"
  btn.style.marginTop = "10px"

  btn.onmouseup = () => {
    onCorrupt(tower)
  }

  return btn
}
