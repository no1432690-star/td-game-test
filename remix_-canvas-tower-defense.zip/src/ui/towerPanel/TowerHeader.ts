export function createTowerHeader(tower: any) {
  const header = document.createElement("div")
  header.style.marginBottom = "10px"

  const title = document.createElement("div")
  const typeName = tower.type || tower.constructor.name;
  title.innerText = typeName.toUpperCase() + " TOWER"

  const level = document.createElement("div")
  level.innerText = "Level " + tower.level + " / 25"

  const status = document.createElement("div")

  if (tower.isLegendary) {
    status.innerText = "LEGENDARY"
    status.style.color = "#D4AF37"
  } else if (tower.isCorrupted) {
    status.innerText = "CORRUPTED"
    status.style.color = "#7A00FF"
  }

  header.appendChild(title)
  header.appendChild(level)
  header.appendChild(status)

  return header
}
