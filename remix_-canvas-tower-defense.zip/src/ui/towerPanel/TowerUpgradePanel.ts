import { createStatModifiersPanel } from './StatModifiersPanel';
import { createTeslaDebugPanel }    from './TeslaDebugPanel';
import { TARGET_MODE_LIST, TARGET_MODES } from '../../tower/targetModes';
import { CorruptionType } from '../../game/entities/Tower';

const F = '"Segoe UI", system-ui, sans-serif';

const TOWER_META: Record<string, { icon: string; color: string; rgb: string; role: string }> = {
  archer:       { icon: '🏹', color: '#22c55e', rgb: '34,197,94',  role: 'Single Target · DPS' },
  cursedarcher: { icon: '🏹', color: '#f87171', rgb: '248,113,113', role: 'Single Target · Cursed' },
  bomber:       { icon: '💣', color: '#f97316', rgb: '249,115,22', role: 'AoE · Crowd Control' },
  frost:        { icon: '❄️',  color: '#38bdf8', rgb: '56,189,248', role: 'Support · Slow' },
  tesla:        { icon: '⚡',  color: '#facc15', rgb: '250,204,21', role: 'Network · Buff' },
};

function el(tag: string, styles: Partial<CSSStyleDeclaration> = {}, text?: string): HTMLElement {
  const e = document.createElement(tag);
  Object.assign(e.style, styles);
  if (text !== undefined) e.textContent = text;
  return e;
}

function makeDivider(): HTMLElement {
  return el('div', { borderTop: '1px solid rgba(255,255,255,.06)', margin: '8px 0' });
}

function sectionLabel(text: string): HTMLElement {
  return el('div', {
    fontSize: '8px', letterSpacing: '2px', color: '#1e3a5f',
    marginBottom: '4px', marginTop: '8px', fontFamily: F,
  }, text);
}

export class TowerUpgradePanel {
  private container: HTMLElement;

  constructor(container: HTMLElement) {
    this.container = container;
  }

  showTower(
    tower: any, stats: any, previewStats: any, gameGold: number,
    onUpgrade: (t: any) => void,
    onCorrupt?: (t: any) => void
  ) {
    this.container.innerHTML = '';

    const typeName = (tower.type || tower.constructor.name).toLowerCase();
    const meta = TOWER_META[typeName] || { icon: '🗼', color: '#94a3b8', rgb: '148,163,184', role: 'Tower' };

    // ── Outer panel ──────────────────────────────────────────────────────────
    const panel = el('div', {
      width: '280px',
      background: '#0a1525',
      border: `1px solid rgba(${meta.rgb},.2)`,
      borderRadius: '14px',
      color: 'white',
      fontFamily: F,
      pointerEvents: 'auto',
      overflow: 'hidden',
    });

    // ── Header ────────────────────────────────────────────────────────────────
    const header = el('div', {
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: '10px',
      borderBottom: '1px solid rgba(255,255,255,.07)',
    });

    const iconBox = el('div', {
      width: '34px', height: '34px', borderRadius: '9px', flexShrink: '0',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: '16px',
      background: `rgba(${meta.rgb},.15)`,
      border: `1px solid rgba(${meta.rgb},.25)`,
    }, meta.icon);

    const headerText = el('div');
    const titleLine = el('div', { fontSize: '13px', fontWeight: '700', color: '#f8fafc' });

    // Badge for special states
    const towerLabel = (tower.type || tower.constructor.name).charAt(0).toUpperCase()
      + (tower.type || tower.constructor.name).slice(1).toLowerCase();
    if (tower.isLegendary) {
      titleLine.textContent = towerLabel;
      const badge = el('span', {
        fontSize: '8px', padding: '1px 5px', borderRadius: '3px',
        background: 'rgba(212,175,55,.15)', color: '#D4AF37',
        border: '1px solid rgba(212,175,55,.3)', marginLeft: '6px',
        letterSpacing: '1px', fontWeight: '600', verticalAlign: 'middle',
      }, 'LEGENDARY');
      titleLine.appendChild(badge);
    } else if (tower.isCorrupted) {
      titleLine.textContent = towerLabel;
      const badge = el('span', {
        fontSize: '8px', padding: '1px 5px', borderRadius: '3px',
        background: 'rgba(122,0,255,.15)', color: '#a855f7',
        border: '1px solid rgba(122,0,255,.3)', marginLeft: '6px',
        letterSpacing: '1px', fontWeight: '600', verticalAlign: 'middle',
      }, 'CORRUPTED');
      titleLine.appendChild(badge);
    } else {
      titleLine.textContent = towerLabel;
    }

    const subLine = el('div', { fontSize: '10px', color: '#475569', marginTop: '1px' },
      `Lv. ${tower.level} / ${tower.maxLevel || 25}  ·  ${meta.role}`);

    headerText.appendChild(titleLine);
    headerText.appendChild(subLine);
    header.appendChild(iconBox);
    header.appendChild(headerText);
    panel.appendChild(header);

    // ── Compact stats ─────────────────────────────────────────────────────────
    const compactSection = el('div', { padding: '10px 14px' });

    // Group 1: Core stats (only show damage, attack speed, range)
    const CORE = ['Damage', 'Attack Speed', 'Range'];
    compactSection.appendChild(sectionLabel('CORE STATS'));
    CORE.forEach(key => {
      if (stats[key] === undefined) return;
      const row = el('div', { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '2px 0' });
      row.appendChild(el('span', { fontSize: '11px', color: '#64748b' }, key));
      const valWrap = el('span');
      const cur = el('span', { fontSize: '11px', color: '#e2e8f0', fontWeight: '500' },
        typeof stats[key] === 'number' ? String(Math.round(stats[key] * 100) / 100) : String(stats[key]));
      valWrap.appendChild(cur);
      if (previewStats && previewStats[key] !== undefined && previewStats[key] !== stats[key]) {
        const arr = el('span', { fontSize: '10px', color: '#334155', margin: '0 3px' }, '→');
        const nxt = el('span', { fontSize: '11px', color: '#34d399', fontWeight: '600' },
          typeof previewStats[key] === 'number' ? String(Math.round(previewStats[key] * 100) / 100) : String(previewStats[key]));
        valWrap.appendChild(arr);
        valWrap.appendChild(nxt);
      }
      row.appendChild(valWrap);
      compactSection.appendChild(row);
    });

    // Group 2: Special stats per type
    const SPECIAL: Record<string, string[]> = {
      bomber:       ['Splash Radius', 'Splash Damage'],
      frost:        ['Slow Effect', 'Slow Duration'],
      archer:       ['Crit Chance', 'Crit Damage'],
      cursedarcher: ['Crit Chance', 'Crit Damage'],
      tesla:        ['Energy', 'Connection Radius'],
    };
    const specialKeys = SPECIAL[typeName] || [];
    if (specialKeys.length > 0) {
      const hasAny = specialKeys.some(k => stats[k] !== undefined);
      if (hasAny) {
        const labelText: Record<string, string> = {
          bomber: 'SPLASH', frost: 'SLOW', archer: 'CRIT',
          cursedarcher: 'CRIT', tesla: 'ENERGY',
        };
        compactSection.appendChild(sectionLabel(labelText[typeName] || 'SPECIAL'));
        specialKeys.forEach(key => {
          if (stats[key] === undefined) return;
          const row = el('div', { display: 'flex', justifyContent: 'space-between', padding: '2px 0' });
          row.appendChild(el('span', { fontSize: '11px', color: '#64748b' }, key));
          row.appendChild(el('span', { fontSize: '11px', color: '#e2e8f0', fontWeight: '500' },
            String(stats[key])));
          compactSection.appendChild(row);
        });
      }
    }

    panel.appendChild(compactSection);

    // ── See More toggle ───────────────────────────────────────────────────────
    let expanded = false;
    const expandedSection = el('div', { display: 'none', padding: '0 14px 10px' });

    // Damage Breakdown
    const modPanel = createStatModifiersPanel(tower);
    if (modPanel) expandedSection.appendChild(modPanel);

    // Tesla block
    const teslaPanel = createTeslaDebugPanel(tower);
    if (teslaPanel) expandedSection.appendChild(teslaPanel);

    // Remaining stats (hidden in compact)
    const HIDDEN_STATS = ['Crit Chance', 'Crit Damage', 'Splash Radius', 'Splash Damage',
      'Slow Effect', 'Slow Duration', 'Burn Damage', 'Burn Duration',
      'Multi-target', 'Max Visual Projectiles', 'Energy', 'Next Energy',
      'Connection Radius', 'Electric Field Radius', 'Chain Targets'];

    const remainingKeys = Object.keys(stats).filter(k =>
      !CORE.includes(k) && !specialKeys.includes(k) && HIDDEN_STATS.includes(k));

    if (remainingKeys.length > 0) {
      expandedSection.appendChild(sectionLabel('ALL STATS'));
      remainingKeys.forEach(key => {
        const row = el('div', { display: 'flex', justifyContent: 'space-between', padding: '2px 0' });
        row.appendChild(el('span', { fontSize: '11px', color: '#64748b' }, key));
        row.appendChild(el('span', { fontSize: '11px', color: '#94a3b8' }, String(stats[key])));
        expandedSection.appendChild(row);
      });
    }

    // Corruption status
    if (tower.isCorrupted && tower.corruptionType !== null && tower.corruptionType !== undefined) {
      expandedSection.appendChild(sectionLabel('CORRUPTION'));
      let cType = tower.corruptionType;
      if (typeof cType === 'number') cType = CorruptionType[cType];
      const cRow = el('div', { display: 'flex', justifyContent: 'space-between', padding: '2px 0' });
      cRow.appendChild(el('span', { fontSize: '11px', color: '#64748b' }, 'Type'));
      cRow.appendChild(el('span', { fontSize: '11px', color: '#a855f7', fontWeight: '600' }, String(cType)));
      expandedSection.appendChild(cRow);
    }

    panel.appendChild(expandedSection);

    const toggleBtn = el('div', {
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '7px 14px', gap: '4px',
      borderTop: '1px solid rgba(255,255,255,.05)',
      borderBottom: '1px solid rgba(255,255,255,.05)',
      background: 'rgba(255,255,255,.02)',
      cursor: 'pointer', fontSize: '10px', color: '#334155',
      letterSpacing: '1px', fontFamily: F,
      userSelect: 'none',
    });
    toggleBtn.textContent = 'SEE MORE  ▾';
    toggleBtn.onmouseenter = () => { toggleBtn.style.color = '#64748b'; toggleBtn.style.background = 'rgba(255,255,255,.04)'; };
    toggleBtn.onmouseleave = () => { toggleBtn.style.color = expanded ? '#94a3b8' : '#334155'; toggleBtn.style.background = 'rgba(255,255,255,.02)'; };
    toggleBtn.onclick = () => {
      expanded = !expanded;
      expandedSection.style.display = expanded ? 'block' : 'none';
      toggleBtn.textContent = expanded ? 'SEE LESS  ▴' : 'SEE MORE  ▾';
      toggleBtn.style.color = expanded ? '#94a3b8' : '#334155';
    };
    panel.appendChild(toggleBtn);

    // ── Target Priority ───────────────────────────────────────────────────────
    const targetRow = el('div', {
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '8px 14px',
    });
    targetRow.appendChild(el('span', { fontSize: '10px', color: '#4b5563', fontFamily: F }, 'Target Priority'));
    const targetBtn = el('button', {
      padding: '3px 10px', borderRadius: '5px', fontSize: '10px',
      border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.04)',
      color: '#94a3b8', cursor: 'pointer', fontFamily: F, fontWeight: '600',
    }) as HTMLButtonElement;

    if (!TARGET_MODE_LIST.includes(tower.targetMode)) tower.targetMode = TARGET_MODES.FIRST;
    targetBtn.textContent = tower.targetMode + ' ↺';
    targetBtn.onmouseup = () => {
      if (typeof tower.cycleTargetMode === 'function') tower.cycleTargetMode();
      else {
        const i = TARGET_MODE_LIST.indexOf(tower.targetMode);
        tower.targetMode = TARGET_MODE_LIST[(i + 1) % TARGET_MODE_LIST.length];
      }
      targetBtn.textContent = tower.targetMode + ' ↺';
    };
    targetRow.appendChild(targetBtn);
    panel.appendChild(targetRow);

    // ── Buttons ───────────────────────────────────────────────────────────────
    const btnArea = el('div', { padding: '8px 14px 12px', display: 'flex', flexDirection: 'column', gap: '6px' });

    const cost = tower.getUpgradeCost ? tower.getUpgradeCost() : (tower.upgradeCost || 0);
    const canAfford = gameGold >= cost;
    const isMaxed  = tower.level >= (tower.maxLevel || 25);

    const refund = Math.floor((tower.baseCost || 100) * tower.level * 0.5);

    const upgBtn = el('button', {
      width: '100%', padding: '9px', borderRadius: '8px', border: 'none',
      fontSize: '12px', fontWeight: '700', cursor: isMaxed ? 'not-allowed' : canAfford ? 'pointer' : 'not-allowed',
      fontFamily: F, letterSpacing: '.5px',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
      background: isMaxed
        ? '#1e293b'
        : canAfford
        ? 'linear-gradient(135deg,#d97706,#b45309)'
        : '#1e293b',
      color: isMaxed ? '#475569' : canAfford ? '#fff' : '#475569',
    }) as HTMLButtonElement;
    upgBtn.disabled = isMaxed || !canAfford;

    if (isMaxed) {
      upgBtn.textContent = '— MAX LEVEL —';
    } else {
      upgBtn.innerHTML = `⬆ Upgrade &nbsp;<span style="opacity:.65;font-size:11px;">${cost}g</span>`;
      if (canAfford) {
        upgBtn.onmouseenter = () => { upgBtn.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)'; };
        upgBtn.onmouseleave = () => { upgBtn.style.background = 'linear-gradient(135deg,#d97706,#b45309)'; };
        upgBtn.onmouseup = () => onUpgrade(tower);
      }
    }
    btnArea.appendChild(upgBtn);

    const sellBtn = el('button', {
      width: '100%', padding: '6px', borderRadius: '7px',
      border: '1px solid rgba(239,68,68,.2)', background: 'rgba(239,68,68,.06)',
      color: '#f87171', fontSize: '11px', cursor: 'pointer', fontFamily: F,
    }, `Sell  ·  refund ${refund}g`) as HTMLButtonElement;
    (sellBtn as any)._isSellBtn = true;
    btnArea.appendChild(sellBtn);

    if (onCorrupt && tower.level >= 16 && !tower.isLegendary && tower.corruptionType === null) {
      const corruptBtn = el('button', {
        width: '100%', padding: '6px', borderRadius: '7px',
        border: '1px solid rgba(139,0,255,.3)', background: 'rgba(122,0,255,.08)',
        color: '#a855f7', fontSize: '11px', cursor: 'pointer', fontFamily: F,
      }, '⚗ Corrupt') as HTMLButtonElement;
      corruptBtn.onmouseup = () => onCorrupt(tower);
      btnArea.appendChild(corruptBtn);
    }

    panel.appendChild(btnArea);
    this.container.appendChild(panel);
  }
}
