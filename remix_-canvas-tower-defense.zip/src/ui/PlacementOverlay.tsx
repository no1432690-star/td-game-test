import React from 'react';

type PlacementOverlayProps = {
  towerType: string | null;
  gold: number;
  costMultiplier: number;
  onCancel: () => void;
};

export const PlacementOverlay: React.FC<PlacementOverlayProps> = ({ towerType, gold, costMultiplier, onCancel }) => {
  if (!towerType) return null;

  const baseCosts: Record<string, number> = {
    Archer: 100,
    Bomber: 120,
    Frost: 110,
    CursedArcher: 100
  };
  const baseCost = baseCosts[towerType] || 100;
  const finalCost = Math.floor(baseCost * costMultiplier);
  const canAfford = gold >= finalCost;

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-start pt-20 pointer-events-none z-40 transition-opacity duration-300">
      <div className="bg-slate-900/90 backdrop-blur-md px-8 py-4 rounded-full border border-slate-700 shadow-2xl flex items-center gap-6 pointer-events-auto">
        <div>
          <h2 className="text-2xl font-bold text-white text-center">
            Place Your <span className="text-blue-400">{towerType}</span>
          </h2>
          <div className="flex justify-center gap-4 mt-2 text-sm font-mono">
            <span className="text-amber-400">Gold: {gold}g</span>
            <span className={canAfford ? 'text-slate-300' : 'text-red-400'}>Cost: {finalCost}g</span>
          </div>
          {!canAfford && (
            <p className="text-red-400 text-xs text-center mt-1 font-bold">
              Insufficient Gold!
            </p>
          )}
        </div>
        <button 
          onClick={onCancel}
          className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg font-bold transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
