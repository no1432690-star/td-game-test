import { GameState } from "../core/GameState";

export class UIManager {
  private container: HTMLElement;

  constructor() {
    this.container = document.createElement("div");
    this.container.id = "ui-root";

    Object.assign(this.container.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "100vw",
      height: "100vh",
      pointerEvents: "none",
      zIndex: "9999"
    });

    document.body.appendChild(this.container);
  }

  clear() {
    this.container.innerHTML = "";
  }

  show(element: HTMLElement) {
    this.clear();
    element.style.pointerEvents = "auto";
    this.container.appendChild(element);
  }
}
