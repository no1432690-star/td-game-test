import React, { useMemo } from 'react';
import { EnemyType } from '../game/entities/EnemyType';
import { EnemyFactory } from '../game/entities/EnemyFactory';

interface EnemyStatsPanelProps {
  wave: number;
}

export const EnemyStatsPanel: React.FC<EnemyStatsPanelProps> = ({ wave }) => {
  const stats = useMemo(() => {
    const types = [
      { type: EnemyType.Red, name: 'Grunt' },
      { type: EnemyType.Yellow, name: 'Runner' },
      { type: EnemyType.Gray, name: 'Tank' },
      { type: EnemyType.BossRed, name: 'Boss: Titan' },
      { type: EnemyType.BossYellow, name: 'Boss: Swift' },
      { type: EnemyType.BossGray, name: 'Boss: Juggernaut' },
    ];

    return types.map(t => {
      const base = EnemyFactory.calculateStatsForType(t.type, 1);
      const current = EnemyFactory.calculateStatsForType(t.type, wave);
      const next = EnemyFactory.calculateStatsForType(t.type, wave + 1);

      return {
        name: t.name,
        isBoss: t.type.startsWith('Boss'),
        hp: {
          base: Math.round(base.maxHealth),
          current: Math.round(current.maxHealth),
          next: Math.round(next.maxHealth)
        },
        speed: {
          base: Number(base.speed.toFixed(1)),
          current: Number(current.speed.toFixed(1)),
          next: Number(next.speed.toFixed(1))
        }
      };
    });
  }, [wave]);

  const nextBossWave = useMemo(() => {
    if (wave < 5) return 5;
    if (wave < 10) return 10;
    if (wave <= 15) return 15;
    return null;
  }, [wave]);

  return (
    <div className="bg-slate-900/90 backdrop-blur border border-slate-700 rounded-xl p-6 shadow-2xl text-white min-w-[300px] pointer-events-auto max-h-[80vh] flex flex-col">
      <h2 className="text-xl font-bold mb-4 text-center border-b border-slate-700 pb-2 shrink-0">Enemy Information</h2>
      
      <div className="space-y-4 overflow-y-auto pr-2 custom-scrollbar flex-1">
        {stats.map((stat, idx) => (
          <div key={idx} className={`p-3 rounded-lg border ${stat.isBoss ? 'bg-red-900/20 border-red-900/50' : 'bg-slate-800/50 border-slate-700'}`}>
            <h3 className={`font-bold mb-2 ${stat.isBoss ? 'text-red-400' : 'text-slate-200'}`}>{stat.name}</h3>
            <div className="space-y-1 text-sm font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">HP:</span>
                <span>
                  <span className="text-slate-300">{stat.hp.base}</span>{' '}
                  <span className="text-yellow-400">[{stat.hp.current}]</span>{' '}
                  <span className="text-orange-400">({stat.hp.next})</span>
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SPD:</span>
                <span>
                  <span className="text-slate-300">{stat.speed.base}</span>{' '}
                  <span className="text-yellow-400">[{stat.speed.current}]</span>{' '}
                  <span className="text-orange-400">({stat.speed.next})</span>
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {nextBossWave && (
        <div className="mt-4 pt-4 border-t border-slate-700 text-center shrink-0">
          <span className="text-slate-400 text-sm">Next Boss Wave: </span>
          <span className="text-red-400 font-bold">({nextBossWave})</span>
        </div>
      )}
    </div>
  );
};
