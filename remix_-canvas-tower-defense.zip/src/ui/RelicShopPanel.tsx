import React, { useState } from 'react';
import { RelicShopState } from '../meta/MetaSave';
import { RelicDefinition, RELIC_DEFINITIONS, RelicTier } from '../game/systems/relic/RelicDefinitions';
import { RelicCard } from './RelicCard';

interface RelicShopPanelProps {
  voidEssence: number;
  relicShop: RelicShopState;
  onPurchaseRelic: (relicId: string) => void;
  onResetRelic?: (relicId: string) => void;
  currentWave?: number;
  voidEssenceHistory?: { gained: number; spent: number; netBalance: number };
}

export function RelicShopPanel(props: RelicShopPanelProps) {
  const { voidEssence, relicShop, onPurchaseRelic, onResetRelic, currentWave = 0, voidEssenceHistory } = props;
  const [filter, setFilter] = useState<RelicTier | 'ALL'>('ALL');
  const [confirmDialog, setConfirmDialog] = useState<{ relicId: string; cost: number; level: number } | null>(null);
  const [showHelp, setShowHelp] = useState(false);

  const handlePurchase = (relicId: string) => {
    const relic = RELIC_DEFINITIONS[relicId];
    if (!relic) return;
    
    const currentLevel = relicShop.ownedRelics[relicId] || 0;
    const nextCost = Math.floor(relic.baseCost * Math.pow(1.15, currentLevel));
    
    setConfirmDialog({ relicId, cost: nextCost, level: currentLevel + 1 });
  };

  const confirmPurchase = () => {
    if (confirmDialog) {
      onPurchaseRelic(confirmDialog.relicId);
      setConfirmDialog(null);
    }
  };

  // Filter and sort relics
  const filteredRelics = Object.values(RELIC_DEFINITIONS).filter(relic => {
    if (filter === 'ALL') return true;
    return relic.tier === filter;
  });

  const sortedRelics = [...filteredRelics].sort((a, b) => {
    const levelA = relicShop.ownedRelics[a.id] || 0;
    const levelB = relicShop.ownedRelics[b.id] || 0;
    
    const unlockedA = currentWave >= a.unlockedAtWave;
    const unlockedB = currentWave >= b.unlockedAtWave;

    // 1. Owned first
    if (levelA > 0 && levelB === 0) return -1;
    if (levelB > 0 && levelA === 0) return 1;

    // 2. Unlocked next
    if (unlockedA && !unlockedB) return -1;
    if (!unlockedA && unlockedB) return 1;

    // 3. Sort by tier
    if (a.tier !== b.tier) return a.tier - b.tier;

    return a.name.localeCompare(b.name);
  });

  return (
    <div className="flex flex-col h-full w-full bg-slate-900 text-slate-200 p-6 overflow-y-auto font-sans">
      {/* Top Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
            <span className="text-purple-500">✦</span> Relic Shop
          </h1>
          <div className="text-slate-400 text-sm">
            Spend Void Essence to permanently upgrade your towers across all runs.
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex flex-col items-end min-w-[200px]">
          <div className="text-sm text-slate-400 font-semibold mb-1 uppercase tracking-wider">Void Essence</div>
          <div className="text-3xl font-bold text-purple-400 font-mono">{voidEssence}</div>
          {voidEssenceHistory && (
            <div className="text-xs text-slate-500 mt-2">
              Earned: {voidEssenceHistory.gained} | Spent: {voidEssenceHistory.spent}
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div className="flex gap-2 bg-slate-800 p-1 rounded-lg overflow-x-auto max-w-full">
          {(['ALL', RelicTier.COMMON, RelicTier.UNCOMMON, RelicTier.RARE, RelicTier.EPIC, RelicTier.LEGENDARY] as const).map(t => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors whitespace-nowrap ${
                filter === t 
                  ? 'bg-purple-600 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700'
              }`}
            >
              {t === 'ALL' ? 'All' : RelicTier[t]}
            </button>
          ))}
        </div>
        
        <button 
          onClick={() => setShowHelp(!showHelp)}
          className="text-slate-400 hover:text-white text-sm flex items-center gap-2"
        >
          <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-xs">?</span>
          How it works
        </button>
      </div>

      {/* Help Section */}
      {showHelp && (
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5 mb-6 text-sm text-slate-300 leading-relaxed">
          <h3 className="text-white font-bold mb-2">About Relics</h3>
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>Void Essence</strong> is earned by prestiging. The higher the wave, the more you earn.</li>
            <li>Relics provide <strong>permanent bonuses</strong> that apply to all future runs.</li>
            <li>Bonuses stack <strong>multiplicatively</strong> with in-game upgrades and artifacts.</li>
            <li>Upgrade costs increase by 15% per level.</li>
            <li>New relics unlock automatically as you reach higher waves.</li>
          </ul>
        </div>
      )}

      {/* Relic Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {sortedRelics.map(relic => {
          const currentLevel = relicShop.ownedRelics[relic.id] || 0;
          const nextCost = Math.floor(relic.baseCost * Math.pow(1.15, currentLevel));
          const canAfford = voidEssence >= nextCost;
          const isUnlocked = currentWave >= relic.unlockedAtWave;

          return (
            <RelicCard
              key={relic.id}
              relic={relic}
              currentLevel={currentLevel}
              nextLevel={currentLevel + 1}
              nextCost={nextCost}
              maxLevel={relic.maxLevel}
              canAfford={canAfford}
              isUnlocked={isUnlocked}
              onPurchase={handlePurchase}
              onReset={onResetRelic}
            />
          );
        })}
      </div>

      {/* Empty State */}
      {sortedRelics.length === 0 && (
        <div className="text-center py-12 text-slate-500">
          No relics found for this filter.
        </div>
      )}

      {/* Confirmation Dialog */}
      {confirmDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">Confirm Purchase</h3>
            
            <div className="space-y-3 mb-6">
              <p className="text-slate-300">
                Upgrade <span className="font-bold text-purple-400">{RELIC_DEFINITIONS[confirmDialog.relicId]?.name}</span> to Level {confirmDialog.level}?
              </p>
              
              <div className="bg-slate-900 rounded-lg p-3 flex justify-between items-center border border-slate-700">
                <span className="text-slate-400">Cost</span>
                <span className="font-bold text-red-400">-{confirmDialog.cost} VE</span>
              </div>
              
              <div className="bg-slate-900 rounded-lg p-3 flex justify-between items-center border border-slate-700">
                <span className="text-slate-400">Remaining</span>
                <span className="font-bold text-purple-400">{voidEssence - confirmDialog.cost} VE</span>
              </div>
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={() => setConfirmDialog(null)}
                className="flex-1 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-semibold transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmPurchase}
                className="flex-1 py-2.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-lg shadow-purple-900/50 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
