import { MetaProgression } from "./metaProgression";

export const RESEARCH_TREE = {
  atk1: {
    id: "atk1",
    name: "Precision Targeting",
    maxLevel: 5,
    effect: { atkPercent: 0.01 }
  },
  speed1: {
    id: "speed1",
    name: "Rapid Loader",
    maxLevel: 5,
    effect: { atkSpeedPercent: 0.01 }
  },
  eco1: {
    id: "eco1",
    name: "Gold Contract",
    maxLevel: 5,
    effect: { goldBonus: 0.02 }
  },
  range1: {
    id: "range1",
    name: "Extended Optics",
    maxLevel: 5,
    effect: { rangePercent: 0.01 }
  }
};

export function getResearchBonus(meta: MetaProgression) {
  const bonus = {
    atkPercent: 0,
    atkSpeedPercent: 0,
    rangePercent: 0,
    goldBonus: 0
  };

  for (const [researchId, level] of Object.entries(meta.research)) {
    const research = (RESEARCH_TREE as any)[researchId];
    if (research && research.effect) {
      if (research.effect.atkPercent) bonus.atkPercent += level * research.effect.atkPercent;
      if (research.effect.atkSpeedPercent) bonus.atkSpeedPercent += level * research.effect.atkSpeedPercent;
      if (research.effect.rangePercent) bonus.rangePercent += level * research.effect.rangePercent;
      if (research.effect.goldBonus) bonus.goldBonus += level * research.effect.goldBonus;
    }
  }

  return bonus;
}
