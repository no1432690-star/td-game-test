import { MetaProgression } from "./metaProgression";
import { getRelicBonus } from "./relics";
import { getResearchBonus } from "./research";

export interface MetaBonus {
  atkPercent: number;
  atkSpeedPercent: number;
  rangePercent: number;
  goldBonus: number;
  slowDuration?: number;
}

export function calculateMetaBonus(meta: MetaProgression): MetaBonus {
  try {
    const relicBonus = getRelicBonus(meta);
    const researchBonus = getResearchBonus(meta);

    return {
      atkPercent: relicBonus.atkPercent + researchBonus.atkPercent,
      atkSpeedPercent: relicBonus.atkSpeedPercent + researchBonus.atkSpeedPercent,
      rangePercent: relicBonus.rangePercent + researchBonus.rangePercent,
      goldBonus: relicBonus.goldBonus + researchBonus.goldBonus,
      slowDuration: relicBonus.slowDuration
    };
  } catch (e) {
    console.error("Failed to calculate meta bonus", e);
    return {
      atkPercent: 0,
      atkSpeedPercent: 0,
      rangePercent: 0,
      goldBonus: 0,
      slowDuration: 0
    };
  }
}
