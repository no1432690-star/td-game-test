export interface MetaSave {
  corruptedShards: number;
  prestigeLevel: number;
  voidEssence: number;
  voidEssenceHistory: {
    gained: number;
    spent: number;
    netBalance: number;
  };
  relicShop: {
    ownedRelics: Record<string, number>;
  };
  statistics: {
    highestWave: number;
    totalRuns: number;
    totalEnemiesKilled: number;
    totalPrestiges: number;
    prestigeStreak: number;
  };
}
