import { MetaProgression } from "./metaProgression";

export const RELICS = {
  bronzeGear: {
    id: "bronzeGear",
    name: "Bronze Gear",
    effect: { atkPercent: 0.02 }
  },
  chronoCore: {
    id: "chronoCore",
    name: "Chrono Core",
    effect: { atkSpeedPercent: 0.03 }
  },
  arcaneLens: {
    id: "arcaneLens",
    name: "Arcane Lens",
    effect: { rangePercent: 0.03 }
  },
  goldMagnet: {
    id: "goldMagnet",
    name: "Gold Magnet",
    effect: { goldBonus: 0.10 }
  },
  frostCrystal: {
    id: "frostCrystal",
    name: "Frost Crystal",
    effect: { slowDuration: 0.05 }
  }
};

export function getRelicBonus(meta: MetaProgression) {
  const bonus = {
    atkPercent: 0,
    atkSpeedPercent: 0,
    rangePercent: 0,
    goldBonus: 0,
    slowDuration: 0
  };

  for (const [relicId, level] of Object.entries(meta.relics)) {
    const relic = (RELICS as any)[relicId];
    if (relic && relic.effect) {
      if (relic.effect.atkPercent) bonus.atkPercent += level * relic.effect.atkPercent;
      if (relic.effect.atkSpeedPercent) bonus.atkSpeedPercent += level * relic.effect.atkSpeedPercent;
      if (relic.effect.rangePercent) bonus.rangePercent += level * relic.effect.rangePercent;
      if (relic.effect.goldBonus) bonus.goldBonus += level * relic.effect.goldBonus;
      if (relic.effect.slowDuration) bonus.slowDuration += level * relic.effect.slowDuration;
    }
  }

  return bonus;
}
