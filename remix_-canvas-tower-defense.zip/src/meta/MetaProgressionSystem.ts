import { MetaSaveManager } from "./MetaSaveManager";

export class MetaProgressionSystem {
  constructor(private saveManager: MetaSaveManager) {}

  grantEndRunShards(wave: number) {
    const reward = Math.floor(wave * 0.5);
    this.saveManager.addShards(reward);
  }
}
