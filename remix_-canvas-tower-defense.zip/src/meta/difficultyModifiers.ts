import { MetaProgression } from "./metaProgression";

export const DIFFICULTY_MODIFIERS = {
  enemyHP: {
    id: "enemyHP",
    value: 0.25
  },
  enemySpeed: {
    id: "enemySpeed",
    value: 0.20
  },
  enemySpawn: {
    id: "enemySpawn",
    value: 0.30
  }
};

export function getDifficultyMultiplier(meta: MetaProgression) {
  try {
    const hpMultiplier = 1 + meta.difficultyLevel * 0.1;
    const speedMultiplier = 1 + meta.difficultyLevel * 0.05;
    
    return {
      hpMultiplier,
      speedMultiplier
    };
  } catch (e) {
    console.error("Failed to calculate difficulty multiplier", e);
    return {
      hpMultiplier: 1,
      speedMultiplier: 1
    };
  }
}
