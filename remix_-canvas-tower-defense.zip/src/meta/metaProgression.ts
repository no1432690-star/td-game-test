export interface MetaProgression {
  relics: Record<string, number>;
  research: Record<string, number>;
  difficultyLevel: number;
}

export const defaultMetaProgression: MetaProgression = {
  relics: {},
  research: {},
  difficultyLevel: 0
};

export function loadMetaProgression(): MetaProgression {
  try {
    const data = localStorage.getItem("td_meta_progression");
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Failed to load meta progression", e);
  }
  return defaultMetaProgression;
}

export function saveMetaProgression(data: MetaProgression) {
  try {
    localStorage.setItem("td_meta_progression", JSON.stringify(data));
  } catch (e) {
    console.error("Failed to save meta progression", e);
  }
}
