import { MetaSave } from "./MetaSave";

const STORAGE_KEY = "td_meta_save";

export class MetaSaveManager {
  private save: MetaSave;

  constructor() {
    this.save = this.load();
  }

  private defaultSave(): MetaSave {
    return {
      corruptedShards: 0,
      prestigeLevel: 0,
      voidEssence: 0,
      voidEssenceHistory: { gained: 0, spent: 0, netBalance: 0 },
      relicShop: { ownedRelics: {} },
      statistics: {
        highestWave: 0,
        totalRuns: 0,
        totalEnemiesKilled: 0,
        totalPrestiges: 0,
        prestigeStreak: 0
      }
    };
  }

  private load(): MetaSave {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return this.defaultSave();
      const data = JSON.parse(raw);
      
      // Ensure nested objects exist
      const defaultData = this.defaultSave();
      return {
        ...defaultData,
        ...data,
        voidEssenceHistory: {
          ...defaultData.voidEssenceHistory,
          ...(data.voidEssenceHistory || {})
        },
        relicShop: {
          ...defaultData.relicShop,
          ...(data.relicShop || {})
        },
        statistics: {
          ...defaultData.statistics,
          ...(data.statistics || {})
        }
      };
    } catch {
      return this.defaultSave();
    }
  }

  saveGame() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.save));
    } catch {}
  }

  getSave(): MetaSave {
    return this.save;
  }

  addShards(amount: number) {
    this.save.corruptedShards += amount;
    this.saveGame();
  }

  recordRun(wave: number) {
    this.save.statistics.totalRuns++;
    if (wave > this.save.statistics.highestWave) {
      this.save.statistics.highestWave = wave;
    }
    this.save.statistics.prestigeStreak = 0;
    this.saveGame();
  }
}
