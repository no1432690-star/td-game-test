export interface RunUpgrade {
  id: string;
  name: string;
  description: string;
  type: 'damage' | 'speed' | 'gold' | 'range';
  value: number;
}

export interface RunModifiers {
  damageMultiplier: number;
  speedMultiplier: number;
  goldMultiplier: number;
  rangeMultiplier: number;
}

export class RunSystem {
  public modifiers: RunModifiers;
  public pendingChoices: RunUpgrade[] | null = null;
  public choiceTimer: number = 0;
  public readonly CHOICE_DURATION: number = 10.0;

  private availableUpgrades: RunUpgrade[] = [
    { id: 'dmg_1', name: 'Sharpened Weapons', description: '+10% Damage', type: 'damage', value: 0.1 },
    { id: 'spd_1', name: 'Haste', description: '+10% Attack Speed', type: 'speed', value: 0.1 },
    { id: 'gld_1', name: 'Bounty', description: '+10% Gold Gain', type: 'gold', value: 0.1 },
    { id: 'rng_1', name: 'Eagle Eye', description: '+10% Range', type: 'range', value: 0.1 },
    { id: 'dmg_2', name: 'Brute Force', description: '+15% Damage', type: 'damage', value: 0.15 },
    { id: 'spd_2', name: 'Adrenaline', description: '+15% Attack Speed', type: 'speed', value: 0.15 },
  ];

  constructor() {
    this.modifiers = this.getDefaultModifiers();
  }

  private getDefaultModifiers(): RunModifiers {
    return {
      damageMultiplier: 1.0,
      speedMultiplier: 1.0,
      goldMultiplier: 1.0,
      rangeMultiplier: 1.0,
    };
  }

  public reset(): void {
    this.modifiers = this.getDefaultModifiers();
    this.pendingChoices = null;
    this.choiceTimer = 0;
  }

  public generateUpgradeChoices(): void {
    const shuffled = [...this.availableUpgrades].sort(() => 0.5 - Math.random());
    this.pendingChoices = shuffled.slice(0, 3);
    this.choiceTimer = this.CHOICE_DURATION;
  }

  public applyUpgrade(choiceId: string): void {
    if (!this.pendingChoices) return;
    const choice = this.pendingChoices.find(c => c.id === choiceId);
    if (choice) {
      if (choice.type === 'damage') this.modifiers.damageMultiplier += choice.value;
      if (choice.type === 'speed') this.modifiers.speedMultiplier += choice.value;
      if (choice.type === 'gold') this.modifiers.goldMultiplier += choice.value;
      if (choice.type === 'range') this.modifiers.rangeMultiplier += choice.value;
    }
    this.pendingChoices = null;
    this.choiceTimer = 0;
  }

  public update(dt: number): boolean {
    if (this.pendingChoices) {
      this.choiceTimer -= dt;
      if (this.choiceTimer <= 0) {
        const randomChoice = this.pendingChoices[Math.floor(Math.random() * this.pendingChoices.length)];
        this.applyUpgrade(randomChoice.id);
        return true; // Auto-picked
      }
    }
    return false;
  }
}
