import { CorruptionSystem, CorruptionModifiers } from './CorruptionSystem';

export class DifficultySystem {
  public wave: number = 1;
  public threatLevel: number = 1;
  public enemyHpMultiplier: number = 1;
  public enemySpeedMultiplier: number = 1;
  public spawnRateMultiplier: number = 1;
  public eliteChance: number = 0;
  public waveThreatBudget: number = 0;

  public corruption: CorruptionSystem = new CorruptionSystem();

  private clamp(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, value));
  }

  public calculateThreatBudget(wave: number): number {
    return 10 + wave * 5;
  }

  public reset(): void {
    this.corruption.reset();
  }

  public updateForWave(wave: number): void {
    if (wave > 1 && wave % 10 === 0 && this.wave !== wave) {
      this.corruption.applyMutation();
    }
    this.wave = wave;
    this.threatLevel = wave;
    
    // hpMultiplier = min(1.12^wave, 200)
    let hpMult = Math.pow(1.12, wave);
    // Do NOT exceed 3x HP before wave 15
    if (wave < 15) {
      hpMult = Math.min(hpMult, 3);
    }
    this.enemyHpMultiplier = this.clamp(hpMult, 1, 200) * this.corruption.modifiers.enemyHpMultiplier;

    // speedMultiplier = 1 + wave * 0.01
    this.enemySpeedMultiplier = this.clamp(1 + wave * 0.01, 1, 10);

    // spawnRateMultiplier = min(1.05^wave, 10)
    this.spawnRateMultiplier = this.clamp(Math.pow(1.05, wave), 1, 10);

    // eliteChance = min(0.3, wave * 0.01)
    this.eliteChance = this.clamp(wave * 0.01, 0, 0.3);

    this.waveThreatBudget = this.calculateThreatBudget(wave);
  }

  public getCurrentMultipliers() {
    return {
      hp: this.enemyHpMultiplier,
      speed: this.enemySpeedMultiplier,
      spawnRate: 1 / this.spawnRateMultiplier, // Convert rate multiplier to interval
      eliteChance: this.eliteChance
    };
  }

  public getCorruptionModifiers(): CorruptionModifiers {
    return this.corruption.modifiers;
  }
}
