import { Tower } from '../entities/Tower';

export class SynergySystem {
    static calculate(towers: Tower[]) {
        const counts: Record<string, number> = {};

        for (const t of towers) {
            counts[t.constructor.name] = (counts[t.constructor.name] || 0) + 1;
        }

        return counts;
    }

    static getDamageBonus(type: string, count: number): number {
        if (count >= 5) return 1.4;
        if (count >= 3) return 1.2;
        return 1;
    }
}
