export interface CorruptionModifiers {
  enemyHpMultiplier: number;
  enemyShieldMultiplier: number;
  enemyDeathSpawnMini: number;
  towerFireRateMultiplier: number;
  goldRewardMultiplier: number;
}

export class CorruptionSystem {
  public modifiers: CorruptionModifiers;

  constructor() {
    this.modifiers = this.getDefaultModifiers();
  }

  public getDefaultModifiers(): CorruptionModifiers {
    return {
      enemyHpMultiplier: 1.0,
      enemyShieldMultiplier: 0.0,
      enemyDeathSpawnMini: 0,
      towerFireRateMultiplier: 1.0,
      goldRewardMultiplier: 1.0
    };
  }

  public reset(): void {
    this.modifiers = this.getDefaultModifiers();
  }

  public applyMutation(): void {
    const mutations = [
      () => { this.modifiers.enemyHpMultiplier += 0.15; },
      () => { this.modifiers.enemyShieldMultiplier += 0.20; }, // 20% max hp as shield
      () => { this.modifiers.enemyDeathSpawnMini += 1; },
      () => { this.modifiers.towerFireRateMultiplier -= 0.05; }, // -5% fire rate
      () => { this.modifiers.goldRewardMultiplier -= 0.05; } // -5% gold
    ];

    const randomMutation = mutations[Math.floor(Math.random() * mutations.length)];
    randomMutation();
  }
}
