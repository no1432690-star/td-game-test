import { Enemy } from '../entities/Enemy';
import { Map } from './Map';
import { difficultyScaler } from './DifficultyScaler';
import { DifficultySystem } from '../systems/DifficultySystem';

export class WaveManager {
  public wave: number = 1;
  public isWaveActive: boolean = false;
  public waveDelayTimer: number = 3.0; // 3 seconds before first wave
  
  private spawnTimer: number = 0;
  private spawnInterval: number = 1.0; // 1 second between spawns
  private readonly waveDelay: number = 5.0; // 5 seconds between waves
  
  private spentThreat: number = 0;
  public difficultySystem: DifficultySystem;

  constructor(private map: Map, private enemies: Enemy[], private enemyPool: Enemy[]) {
    this.difficultySystem = new DifficultySystem();
  }

  public reset(): void {
    this.wave = 1;
    this.isWaveActive = false;
    this.waveDelayTimer = 3.0;
    this.spawnTimer = 0;
    this.spentThreat = 0;
    difficultyScaler.reset();
    this.difficultySystem.reset();
    this.difficultySystem.updateForWave(this.wave);
  }

  public update(dt: number): void {
    difficultyScaler.update(dt);

    if (!this.isWaveActive) {
      this.waveDelayTimer -= dt;
      if (this.waveDelayTimer <= 0) {
        this.startWave();
      }
      return;
    }

    // Spawning logic
    const canSpawn = this.spentThreat < this.difficultySystem.waveThreatBudget;

    if (canSpawn) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        try {
          this.spawnEnemy();
          const multipliers = this.difficultySystem.getCurrentMultipliers();
          this.spawnInterval = multipliers.spawnRate;
          this.spawnTimer = this.spawnInterval;
        } catch (e) {
          console.error("Spawn error, falling back", e);
          this.spawnTimer = this.spawnInterval;
        }
      }
    } else if (this.enemies.length === 0) {
      // Wave complete when all enemies are spawned and destroyed/reached end
      this.endWave();
    }
  }

  private startWave(): void {
    this.isWaveActive = true;
    this.spentThreat = 0;
    this.spawnTimer = 0; // Spawn first enemy immediately
    this.difficultySystem.updateForWave(this.wave);
  }

  private endWave(): void {
    this.isWaveActive = false;
    this.wave++;
    this.waveDelayTimer = this.waveDelay;
  }

  private spawnEnemy(): void {
    let enemy: Enemy;
    if (this.enemyPool.length > 0) {
      enemy = this.enemyPool.pop()!;
      enemy.reset(this.map.waypoints);
    } else {
      enemy = new Enemy(this.map.waypoints);
    }
    
    const multipliers = this.difficultySystem.getCurrentMultipliers();
    const corruption = this.difficultySystem.getCorruptionModifiers();
    
    // HP scaling
    const baseHP = 100;
    enemy.maxHealth = baseHP * multipliers.hp;
    enemy.health = enemy.maxHealth;
    
    // Speed scaling
    enemy.speed = 100 * multipliers.speed;

    // Corruption
    enemy.shield = enemy.maxHealth * corruption.enemyShieldMultiplier;
    enemy.maxShield = enemy.shield;
    enemy.deathSpawnMini = corruption.enemyDeathSpawnMini;
    
    this.enemies.push(enemy);
    this.spentThreat += enemy.threatCost;
  }

  public spawnMini(position: { x: number, y: number }, targetIndex: number): void {
    let enemy: Enemy;
    if (this.enemyPool.length > 0) {
      enemy = this.enemyPool.pop()!;
      enemy.reset(this.map.waypoints);
    } else {
      enemy = new Enemy(this.map.waypoints);
    }
    
    const multipliers = this.difficultySystem.getCurrentMultipliers();
    
    enemy.maxHealth = 50 * multipliers.hp;
    enemy.health = enemy.maxHealth;
    enemy.speed = 150 * multipliers.speed;
    enemy.position.x = position.x + (Math.random() * 20 - 10);
    enemy.position.y = position.y + (Math.random() * 20 - 10);
    enemy.setTargetIndex(targetIndex);
    enemy.threatCost = 0;
    enemy.shield = 0;
    enemy.maxShield = 0;
    enemy.deathSpawnMini = 0;
    
    this.enemies.push(enemy);
  }
}
