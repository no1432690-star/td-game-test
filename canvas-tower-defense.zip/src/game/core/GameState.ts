import { RunUpgrade } from '../systems/RunSystem';
import { TowerDraftEntry } from '../systems/TowerDraftSystem';

export interface GameState {
  gold: number;
  lives: number;
  wave: number;
  isWaveActive: boolean;
  waveDelayTimer: number;
  isPaused: boolean;
  speedMultiplier: number;
  pendingUpgrades: RunUpgrade[] | null;
  upgradeTimer: number;
  pendingDraft: TowerDraftEntry[] | null;
}
