export class GameCore {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animationFrameId: number | null = null;
  private lastTime: number = 0;

  // Game Settings
  public speedMultiplier: number = 1;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('Could not get 2D context');
    }
    this.ctx = context;

    // Initial resize
    this.resize();
    window.addEventListener('resize', this.bindResize);
  }

  public start(): void {
    if (this.animationFrameId !== null) return;
    
    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public stop(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    window.removeEventListener('resize', this.bindResize);
  }

  public setSpeed(multiplier: number): void {
    this.speedMultiplier = multiplier;
  }

  private bindResize = (): void => {
    this.resize();
  };

  private resize(): void {
    const parent = this.canvas.parentElement;
    if (parent) {
      this.canvas.width = parent.clientWidth;
      this.canvas.height = parent.clientHeight;
    }
  }

  private loop = (timestamp: number): void => {
    // Calculate Delta Time
    const rawDt = (timestamp - this.lastTime) / 1000;
    this.lastTime = timestamp;

    // Cap dt to prevent huge jumps (e.g. switching tabs)
    const safeDt = Math.min(rawDt, 0.1);

    // Apply Speed Multiplier
    const dt = safeDt * this.speedMultiplier;

    this.update(dt);
    this.draw();

    this.animationFrameId = requestAnimationFrame(this.loop);
  };

  private update(dt: number): void {
    // Core update logic (Empty for now)
  }

  private draw(): void {
    // Clear screen
    this.ctx.fillStyle = '#111827'; // Gray-900
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Debug Info
    this.ctx.fillStyle = '#10b981'; // Emerald-500
    this.ctx.font = '14px monospace';
    this.ctx.fillText(`CORE LOOP RUNNING`, 20, 30);
    this.ctx.fillText(`Speed: ${this.speedMultiplier}x`, 20, 50);
    this.ctx.fillText(`Canvas: ${this.canvas.width}x${this.canvas.height}`, 20, 70);
  }
}
