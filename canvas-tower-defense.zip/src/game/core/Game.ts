import { Loop } from './Loop';
import { Map } from './Map';
import { WaveManager } from './WaveManager';
import { MetaSystem, MetaState, MetaBonuses } from './MetaSystem';
import { GameState } from './GameState';
import { RunSystem } from '../systems/RunSystem';
import { TowerDraftSystem } from '../systems/TowerDraftSystem';
import { SynergySystem } from '../systems/SynergySystem';
import { Enemy } from '../entities/Enemy';
import { Tower } from '../entities/Tower';
import { Archer } from '../entities/Archer';
import { Bomber } from '../entities/Bomber';
import { Frost } from '../entities/Frost';
import { Projectile } from '../entities/Projectile';

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private loop: Loop;
  private map: Map;
  private waveManager: WaveManager;
  public runSystem: RunSystem;
  public draftSystem: TowerDraftSystem;
  
  public metaState: MetaState;
  public metaBonuses: MetaBonuses;
  
  public gold: number;
  public lives: number;
  public costMultiplier: number = 1;

  private enemies: Enemy[] = [];
  private enemyPool: Enemy[] = [];
  private towers: Tower[] = [];
  private projectiles: Projectile[] = [];

  // Engine State
  public speedMultiplier: number = 1.0;
  public isPaused: boolean = false;
  private timeElapsed: number = 0;
  private frameCount: number = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('Could not get 2D context');
    }
    this.ctx = context;

    this.runSystem = new RunSystem();
    this.draftSystem = new TowerDraftSystem();

    // Load Meta System
    this.metaState = MetaSystem.load();
    
    // For testing purposes, give some initial meta upgrades if empty
    if (this.metaState.ink === 0 && this.metaState.upgrades.damage === 0) {
      this.metaState.ink = 500;
      this.metaState.upgrades.damage = 2; // +20% damage
      this.metaState.upgrades.crit = 2;   // +10% crit chance
      this.metaState.upgrades.gold = 1;   // +10% starting gold
      this.metaState.upgrades.life = 1;   // +5 starting lives
      MetaSystem.save(this.metaState);
    }
    
    // Calculate bonuses ONCE at game start
    this.metaBonuses = MetaSystem.getBonuses(this.metaState);

    // Apply starting resources based on meta
    this.gold = Math.floor(100 * this.metaBonuses.goldMultiplier);
    this.lives = 20 + this.metaBonuses.extraLife;

    // Initialize Map
    this.map = new Map();

    // Initialize WaveManager
    this.waveManager = new WaveManager(this.map, this.enemies, this.enemyPool);

    // Manual test spawn for towers
    /*
    const archer1 = new Archer(this.map.buildSlots[0].position.x, this.map.buildSlots[0].position.y);
    archer1.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
    archer1.upgrade();
    archer1.upgrade(); // Level 3 (Rapid Fire)
    this.towers.push(archer1);

    const bomber1 = new Bomber(this.map.buildSlots[4].position.x, this.map.buildSlots[4].position.y, this.enemies);
    bomber1.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
    bomber1.upgrade(); // Level 2
    this.towers.push(bomber1);

    const frost1 = new Frost(this.map.buildSlots[2].position.x, this.map.buildSlots[2].position.y);
    frost1.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
    frost1.upgrade();
    frost1.upgrade(); // Level 3 (Deep Freeze)
    this.towers.push(frost1);

    const archer2 = new Archer(this.map.buildSlots[5].position.x, this.map.buildSlots[5].position.y);
    archer2.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
    this.towers.push(archer2);
    */

    if (process.env.NODE_ENV === 'development') {
      if (this.towers.length === 0 && this.map.buildSlots.length > 0) {
        const slot = this.map.buildSlots[0];
        const testArcher = new Archer(slot.position.x, slot.position.y);
        testArcher.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance);
        this.towers.push(testArcher);
        slot.occupied = true;
        slot.tower = testArcher;
      }
    }

    // Initialize Loop
    this.loop = new Loop(this.update.bind(this), this.draw.bind(this));

    // Handle Resize
    this.resize();
    window.addEventListener('resize', this.resize.bind(this));
    this.canvas.addEventListener('click', this.handleClick.bind(this));
  }

  private handleClick(event: MouseEvent): void {
    if (!this.draftSystem.pendingDraft) return;

    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    for (const slot of this.map.buildSlots) {
      if (slot.occupied || slot.id >= this.map.unlockedSlots) continue;

      const dx = slot.position.x - x;
      const dy = slot.position.y - y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < 20) { // slot radius
        const draftType = this.draftSystem.pendingDraft[0].type; // Pick first draft item for now
        let newTower: Tower | null = null;
        let isCursed = false;

        if (draftType === 'Archer') {
          newTower = new Archer(slot.position.x, slot.position.y);
        } else if (draftType === 'Bomber') {
          newTower = new Bomber(slot.position.x, slot.position.y, this.enemies);
        } else if (draftType === 'Frost') {
          newTower = new Frost(slot.position.x, slot.position.y);
        } else if (draftType === 'CursedArcher') {
          newTower = new Archer(slot.position.x, slot.position.y);
          isCursed = true;
        }

        if (newTower) {
          const finalCost = Math.floor(newTower.baseCost * this.costMultiplier);
          if (this.gold >= finalCost) {
            this.gold -= finalCost;
            newTower.applyMeta(this.metaBonuses.damageMultiplier, this.metaBonuses.critChance, isCursed);
            this.towers.push(newTower);
            slot.occupied = true;
            slot.tower = newTower;
            console.log(`Built ${draftType} at slot ${slot.id} for ${finalCost}`);
            this.draftSystem.clearDraft();
          }
        }
        break;
      }
    }
  }

  public start(): void {
    this.loop.start();
  }

  public restart(): void {
    this.enemies.length = 0;
    this.projectiles.length = 0;
    this.towers.length = 0;
    this.gold = Math.floor(100 * this.metaBonuses.goldMultiplier);
    this.lives = 20 + this.metaBonuses.extraLife;
    this.costMultiplier = 1;
    this.map.unlockedSlots = 3;
    this.waveManager.reset();
    this.runSystem.reset();
    this.draftSystem.clearDraft();
    this.timeElapsed = 0;
    this.frameCount = 0;
    this.isPaused = false;
  }

  public destroy(): void {
    this.loop.stop();
    window.removeEventListener('resize', this.resize.bind(this));
    this.enemies.length = 0;
    this.enemyPool.length = 0;
    this.projectiles.length = 0;
    this.towers.length = 0;
  }

  public setSpeed(multiplier: number): void {
    this.speedMultiplier = multiplier;
  }

  public togglePause(): void {
    this.isPaused = !this.isPaused;
  }

  public applyUpgrade(choiceId: string): void {
    this.runSystem.applyUpgrade(choiceId);
    this.isPaused = false;
  }

  public getState(): GameState {
    return {
      gold: this.gold,
      lives: this.lives,
      wave: this.waveManager.wave,
      isWaveActive: this.waveManager.isWaveActive,
      waveDelayTimer: this.waveManager.waveDelayTimer,
      isPaused: this.isPaused,
      speedMultiplier: this.speedMultiplier,
      pendingUpgrades: this.runSystem.pendingChoices,
      upgradeTimer: this.runSystem.choiceTimer,
      pendingDraft: this.draftSystem.pendingDraft
    };
  }

  private resize(): void {
    const parent = this.canvas.parentElement;
    if (parent) {
      this.canvas.width = parent.clientWidth;
      this.canvas.height = parent.clientHeight;
    }
  }

  private update(rawDt: number): void {
    if (this.runSystem.pendingChoices) {
      const autoPicked = this.runSystem.update(rawDt);
      if (autoPicked) {
        this.isPaused = false;
      }
    }

    if (this.isPaused) return;

    // Apply speed multiplier to delta time
    const dt = rawDt * this.speedMultiplier;
    
    this.timeElapsed += dt;
    this.frameCount++;

    const wasWaveActive = this.waveManager.isWaveActive;

    // Update WaveManager
    this.waveManager.update(dt);

    if (wasWaveActive && !this.waveManager.isWaveActive) {
      if ((this.waveManager.wave - 1) % 5 === 0) {
        this.map.unlockedSlots = Math.min(this.map.buildSlots.length, this.map.unlockedSlots + 1);
      }
      if ((this.waveManager.wave - 1) % 3 === 0 && this.waveManager.wave > 1) {
        this.costMultiplier = Math.min(3, this.costMultiplier + 0.05);
      }
      this.runSystem.generateUpgradeChoices();
      this.draftSystem.generateDraft(this.waveManager.wave, this.waveManager.difficultySystem.corruption);
      this.isPaused = true;
    }

    // Update towers
    const corruption = this.waveManager.difficultySystem.getCorruptionModifiers();
    const baseModifiers = {
      ...this.runSystem.modifiers,
      speedMultiplier: this.runSystem.modifiers.speedMultiplier * corruption.towerFireRateMultiplier,
      goldMultiplier: this.runSystem.modifiers.goldMultiplier * corruption.goldRewardMultiplier
    };

    const synergies = SynergySystem.calculate(this.towers);

    for (const tower of this.towers) {
      const type = tower.constructor.name;
      const synergyBonus = SynergySystem.getDamageBonus(type, synergies[type] || 0);
      
      const combinedModifiers = {
        ...baseModifiers,
        damageMultiplier: baseModifiers.damageMultiplier * synergyBonus
      };

      const projectile = tower.update(dt, this.enemies, combinedModifiers);
      if (projectile) {
        this.projectiles.push(projectile);
      }
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.update(dt);
      if (!p.active) {
        this.projectiles.splice(i, 1);
      }
    }

    // Update enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.update(dt);
      
      // Remove inactive enemies (e.g., reached the end or died)
      if (!enemy.active) {
        if (enemy.health <= 0 && enemy.deathSpawnMini > 0) {
          for (let j = 0; j < enemy.deathSpawnMini; j++) {
            this.waveManager.spawnMini(enemy.position, enemy.targetIndex);
          }
        }
        this.enemyPool.push(enemy);
        this.enemies.splice(i, 1);
      }
    }
  }

  private draw(): void {
    // Clear screen
    this.ctx.fillStyle = '#111';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw Map
    this.map.draw(this.ctx);

    // Draw Towers
    for (const tower of this.towers) {
      tower.draw(this.ctx);
    }

    // Draw Enemies
    for (const enemy of this.enemies) {
      enemy.draw(this.ctx);
    }

    // Draw Projectiles
    for (const p of this.projectiles) {
      p.draw(this.ctx);
    }
  }
}
