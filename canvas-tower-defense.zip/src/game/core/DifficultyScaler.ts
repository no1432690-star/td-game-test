export class DifficultyScaler {
  public totalDamageDealt: number = 0;
  public totalKillTime: number = 0;
  public kills: number = 0;
  public dps: number = 0;
  
  private timeTracking: number = 0;
  private damageAccumulator: number = 0;

  public reset(): void {
    this.totalDamageDealt = 0;
    this.totalKillTime = 0;
    this.kills = 0;
    this.dps = 0;
    this.timeTracking = 0;
    this.damageAccumulator = 0;
  }

  public reportDamage(amount: number): void {
    this.totalDamageDealt += amount;
    this.damageAccumulator += amount;
  }

  public reportKill(timeAlive: number): void {
    this.totalKillTime += timeAlive;
    this.kills++;
  }

  public update(dt: number): void {
    this.timeTracking += dt;
    // Update DPS every second
    if (this.timeTracking >= 1.0) {
      this.dps = this.damageAccumulator / this.timeTracking;
      this.damageAccumulator = 0;
      this.timeTracking = 0;
    }
  }

  public getAverageKillTime(): number {
    return this.kills === 0 ? 0 : this.totalKillTime / this.kills;
  }

  public getWaveBudget(wave: number): number {
    const baseEnemyHP = 100 * (1 + wave * 0.18);
    
    // Pre-wave 20: exactly 10 enemies worth of budget
    if (wave < 20) {
       return 10 * baseEnemyHP;
    }

    // Soft cap after wave 100
    let effectiveWave = wave;
    if (wave > 100) {
       effectiveWave = 100 + Math.pow(wave - 100, 0.5);
    }

    // Base budget scales with effective wave
    let budget = 10 * (100 * (1 + effectiveWave * 0.18)) * (effectiveWave / 15);

    // Dynamic scaling based on player performance
    const avgKillTime = this.getAverageKillTime();
    
    // If killing very fast (under 3 seconds on average), increase budget
    if (avgKillTime > 0 && avgKillTime < 3.0) {
       budget *= 1.5;
    } else if (avgKillTime > 0 && avgKillTime < 5.0) {
       budget *= 1.2;
    }

    // If DPS is extremely high, add a multiplier
    if (this.dps > budget * 0.5) {
       budget *= 1.5;
    }

    return budget;
  }
}

export const difficultyScaler = new DifficultyScaler();
