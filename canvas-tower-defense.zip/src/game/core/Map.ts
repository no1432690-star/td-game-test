import { Vector2 } from '../utils/Vector2';
import { Tower } from '../entities/Tower';

export interface BuildSlot {
  id: number;
  position: Vector2;
  occupied: boolean;
  tower?: Tower;
}

export class Map {
  public waypoints: Vector2[];
  public buildSlots: BuildSlot[];
  public unlockedSlots: number = 3;

  constructor() {
    // Define the path waypoints
    this.waypoints = [
      new Vector2(0, 300),
      new Vector2(200, 300),
      new Vector2(200, 100),
      new Vector2(600, 100),
      new Vector2(600, 500),
      new Vector2(800, 500),
      new Vector2(800, 300),
      new Vector2(1200, 300)
    ];

    // Define 14 build slots strategically placed around the path
    const rawSlots = [
      new Vector2(100, 240), // 1
      new Vector2(100, 360), // 2
      new Vector2(260, 200), // 3
      new Vector2(140, 200), // 4
      new Vector2(300, 40),  // 5
      new Vector2(300, 160), // 6
      new Vector2(500, 40),  // 7
      new Vector2(500, 160), // 8
      new Vector2(540, 300), // 9
      new Vector2(660, 300), // 10
      new Vector2(700, 440), // 11
      new Vector2(700, 560), // 12
      new Vector2(900, 240), // 13
      new Vector2(900, 360)  // 14
    ];

    this.buildSlots = rawSlots.map((pos, index) => ({
      id: index,
      position: pos,
      occupied: false
    }));
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    // Draw Path
    if (this.waypoints.length > 0) {
      ctx.beginPath();
      ctx.moveTo(this.waypoints[0].x, this.waypoints[0].y);
      for (let i = 1; i < this.waypoints.length; i++) {
        ctx.lineTo(this.waypoints[i].x, this.waypoints[i].y);
      }
      ctx.strokeStyle = '#374151'; // Gray-700
      ctx.lineWidth = 40;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
      
      // Draw path center line for clarity
      ctx.strokeStyle = '#4b5563'; // Gray-600
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Draw Build Slots
    for (const slot of this.buildSlots) {
      ctx.beginPath();
      ctx.arc(slot.position.x, slot.position.y, 20, 0, Math.PI * 2);
      
      if (slot.id < this.unlockedSlots) {
        ctx.fillStyle = 'rgba(59, 130, 246, 0.2)'; // Blue-500 with opacity
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.5)';
      } else {
        ctx.fillStyle = 'rgba(75, 85, 99, 0.2)'; // Gray-600 with opacity
        ctx.strokeStyle = 'rgba(75, 85, 99, 0.5)';
      }
      
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.closePath();

      if (slot.id >= this.unlockedSlots) {
        // Draw a small X for locked slots
        ctx.beginPath();
        ctx.moveTo(slot.position.x - 5, slot.position.y - 5);
        ctx.lineTo(slot.position.x + 5, slot.position.y + 5);
        ctx.moveTo(slot.position.x + 5, slot.position.y - 5);
        ctx.lineTo(slot.position.x - 5, slot.position.y + 5);
        ctx.strokeStyle = 'rgba(156, 163, 175, 0.5)'; // Gray-400
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }

    // Draw Base (End Node)
    const endNode = this.waypoints[this.waypoints.length - 1];
    ctx.beginPath();
    ctx.arc(endNode.x, endNode.y, 30, 0, Math.PI * 2);
    ctx.fillStyle = '#3b82f6'; // Blue-500
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('BASE', endNode.x, endNode.y);
    ctx.textAlign = 'left'; // Reset
  }
}
