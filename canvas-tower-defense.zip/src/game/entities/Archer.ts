import { Tower } from './Tower';

export class Archer extends Tower {
  constructor(x: number, y: number) {
    // range: 150, cooldown: 1.0s, damage: 25
    super(x, y, 150, 1.0, 25);
    this.baseCost = 50;
  }

  public upgrade(): void {
    super.upgrade();
    if (this.level === 3) {
      this.cooldown *= 0.5; // Level 3 Special: Rapid Fire
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    // Range indicator (faint)
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.range, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(34, 197, 94, 0.05)'; // Green-500
    ctx.fill();
    ctx.strokeStyle = 'rgba(34, 197, 94, 0.2)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.closePath();

    // Tower base
    ctx.fillStyle = '#1e293b'; // Slate-800
    ctx.fillRect(this.position.x - 15, this.position.y - 15, 30, 30);

    // Turret (Archer)
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 10, 0, Math.PI * 2);
    ctx.fillStyle = '#22c55e'; // Green-500
    ctx.fill();
    ctx.closePath();

    this.drawLevel(ctx);
  }
}
