import { Vector2 } from '../utils/Vector2';
import { difficultyScaler } from '../core/DifficultyScaler';

export interface StatusEffect {
  type: 'slow';
  multiplier: number;
  duration: number;
}

export class Enemy {
  public position: Vector2;
  private _health: number;
  public maxHealth: number;
  public speed: number = 100;
  public active: boolean = true;
  public effects: StatusEffect[] = [];
  public timeAlive: number = 0;
  public threatCost: number = 1;

  public shield: number = 0;
  public maxShield: number = 0;
  public deathSpawnMini: number = 0;
  
  private path: Vector2[];
  public targetIndex: number = 1;

  constructor(path: Vector2[], xOffset: number = 0) {
    this.path = path;
    // Start at the first waypoint, with an optional offset to space out test spawns
    this.position = new Vector2(path[0].x + xOffset, path[0].y);
    this.maxHealth = 100;
    this._health = this.maxHealth;
  }

  public setTargetIndex(index: number): void {
    this.targetIndex = index;
  }

  public get health(): number {
    return this._health;
  }

  public set health(value: number) {
    let damage = this._health - value;
    if (damage <= 0) {
      this._health = value;
      return;
    }

    if (this.shield > 0) {
      if (damage <= this.shield) {
        this.shield -= damage;
        damage = 0;
      } else {
        damage -= this.shield;
        this.shield = 0;
      }
    }

    if (damage > 0) {
      difficultyScaler.reportDamage(damage);
    }
    this._health -= damage;
    if (this._health <= 0 && this.active) {
      difficultyScaler.reportKill(this.timeAlive);
    }
  }

  public reset(path: Vector2[], xOffset: number = 0): void {
    this.path = path;
    this.targetIndex = 1;
    this.position = new Vector2(path[0].x + xOffset, path[0].y);
    this.active = true;
    this.effects = [];
    this.timeAlive = 0;
    this._health = this.maxHealth;
    this.shield = 0;
    this.maxShield = 0;
    this.deathSpawnMini = 0;
  }

  public applyEffect(effect: StatusEffect): void {
    // Check if we already have a slow effect to prevent infinite stacking
    // For simplicity, we just add it, but we could also replace or extend
    this.effects.push({ ...effect });
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    this.timeAlive += dt;
    
    if (this.targetIndex >= this.path.length) return;

    // Process status effects
    let currentSpeedMultiplier = 1.0;
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const effect = this.effects[i];
      effect.duration -= dt;
      if (effect.duration <= 0) {
        this.effects.splice(i, 1);
      } else {
        if (effect.type === 'slow') {
          // You can choose to stack multiplicatively or take the minimum
          // We'll take the minimum multiplier (strongest slow) for better gameplay
          currentSpeedMultiplier = Math.min(currentSpeedMultiplier, effect.multiplier);
        }
      }
    }

    const target = this.path[this.targetIndex];
    const dir = target.sub(this.position);
    const dist = dir.mag();

    // If close enough to the waypoint, move to the next one
    if (dist < 5) {
      this.targetIndex++;
      if (this.targetIndex >= this.path.length) {
        this.active = false; // Reached the end of the path
      }
    } else {
      // Move towards the target waypoint
      const effectiveSpeed = this.speed * currentSpeedMultiplier;
      const move = dir.normalize().mult(effectiveSpeed * dt);
      this.position = this.position.add(move);
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    if (!this.active) return;

    const isSlowed = this.effects.some(e => e.type === 'slow');

    // Draw enemy body
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 12, 0, Math.PI * 2);
    ctx.fillStyle = isSlowed ? '#60a5fa' : '#ef4444'; // Blue-400 if slowed, else Red-500
    ctx.fill();
    ctx.strokeStyle = isSlowed ? '#2563eb' : '#991b1b'; // Blue-600 if slowed, else Red-800
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.closePath();

    // Draw HP bar
    const hpPercent = Math.max(0, this.health / this.maxHealth);
    ctx.fillStyle = '#333';
    ctx.fillRect(this.position.x - 15, this.position.y - 22, 30, 4);
    ctx.fillStyle = '#22c55e'; // Green-500
    ctx.fillRect(this.position.x - 15, this.position.y - 22, 30 * hpPercent, 4);

    if (this.shield > 0) {
      ctx.strokeStyle = '#3b82f6'; // blue-500
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(this.position.x, this.position.y, 14, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
}
