import { Projectile } from './Projectile';
import { Enemy } from './Enemy';
import { Vector2 } from '../utils/Vector2';

export class BombProjectile extends Projectile {
  private enemies: Enemy[];
  public aoeRadius: number = 80;

  constructor(start: Vector2, target: Enemy, damage: number, enemies: Enemy[]) {
    super(start, target, damage);
    this.enemies = enemies;
    this.speed = 250; // Slower than normal projectiles
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    // If target is dead, explode at current position
    if (!this.target.active) {
      this.explode();
      return;
    }

    const dir = this.target.position.sub(this.position);
    const dist = dir.mag();

    if (dist < 10) {
      this.explode();
    } else {
      const move = dir.normalize().mult(this.speed * dt);
      this.position = this.position.add(move);
    }
  }

  private explode(): void {
    this.active = false;
    
    // Apply AoE Damage to all enemies within radius
    for (const enemy of this.enemies) {
      if (!enemy.active) continue;
      
      if (this.position.dist(enemy.position) <= this.aoeRadius) {
        enemy.health -= this.damage;
        if (enemy.health <= 0) {
          enemy.active = false;
        }
      }
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    if (!this.active) return;
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 6, 0, Math.PI * 2);
    ctx.fillStyle = '#111827'; // Gray-900
    ctx.fill();
    ctx.strokeStyle = '#ef4444'; // Red-500
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.closePath();
  }
}
