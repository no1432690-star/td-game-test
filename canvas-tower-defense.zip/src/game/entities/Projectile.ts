import { Vector2 } from '../utils/Vector2';
import { Enemy } from './Enemy';

export class Projectile {
  public position: Vector2;
  public target: Enemy;
  public speed: number = 400;
  public damage: number;
  public active: boolean = true;

  constructor(start: Vector2, target: Enemy, damage: number) {
    this.position = start.clone();
    this.target = target;
    this.damage = damage;
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    // If target is dead or inactive, destroy projectile
    if (!this.target.active) {
      this.active = false;
      return;
    }

    const dir = this.target.position.sub(this.position);
    const dist = dir.mag();

    // Check collision
    if (dist < 10) {
      this.target.health -= this.damage;
      if (this.target.health <= 0) {
        this.target.active = false;
      }
      this.active = false;
    } else {
      // Move towards target
      const move = dir.normalize().mult(this.speed * dt);
      this.position = this.position.add(move);
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    if (!this.active) return;
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#fbbf24'; // Amber-400
    ctx.fill();
    ctx.closePath();
  }
}
