import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { FrostProjectile } from './FrostProjectile';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';

export class Frost extends Tower {
  constructor(x: number, y: number) {
    // range: 100, cooldown: 1.5s, damage: 10
    super(x, y, 100, 1.5, 10);
    this.baseCost = 75;
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers): Projectile {
    const p = new FrostProjectile(this.position, target, this.getCalculatedDamage(runModifiers));
    if (this.level >= 3) {
      p.slowMultiplier = 0.2; // Level 3 Special: Deep Freeze (80% slow)
      p.slowDuration = 4.0;
    }
    return p;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    // Range indicator (faint blue)
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.range, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(59, 130, 246, 0.05)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.closePath();

    // Tower base
    ctx.fillStyle = '#1e293b'; // Slate-800
    ctx.fillRect(this.position.x - 15, this.position.y - 15, 30, 30);

    // Turret (Frost - blue triangle)
    ctx.beginPath();
    ctx.moveTo(this.position.x, this.position.y - 12);
    ctx.lineTo(this.position.x + 10, this.position.y + 8);
    ctx.lineTo(this.position.x - 10, this.position.y + 8);
    ctx.fillStyle = '#3b82f6'; // Blue-500
    ctx.fill();
    ctx.closePath();

    this.drawLevel(ctx);
  }
}
