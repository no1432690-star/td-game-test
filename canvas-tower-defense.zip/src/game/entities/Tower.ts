import { Vector2 } from '../utils/Vector2';
import { Enemy } from './Enemy';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';

export abstract class Tower {
  public position: Vector2;
  public range: number;
  public cooldown: number;
  public damage: number;
  protected timer: number = 0;

  public level: number = 1;
  public baseCost: number = 100;
  public critChance: number = 0;

  constructor(x: number, y: number, range: number, cooldown: number, damage: number) {
    this.position = new Vector2(x, y);
    this.range = range;
    this.cooldown = cooldown;
    this.damage = damage;
  }

  public applyMeta(damageMultiplier: number, critChance: number, isCursed: boolean = false): void {
    this.damage = Math.floor(this.damage * damageMultiplier);
    if (isCursed) {
      this.damage = Math.floor(this.damage * 1.4); // +40% damage
      this.cooldown = this.cooldown * 1.25; // -20% fire rate (takes 25% longer to fire)
    }
    this.critChance = critChance;
  }

  public getUpgradeCost(): number {
    return Math.floor(this.baseCost * this.level * 1.5);
  }

  public upgrade(): void {
    this.level++;
    this.damage += Math.floor(this.damage * 0.5); // 50% more damage per level
  }

  public update(dt: number, enemies: Enemy[], runModifiers?: RunModifiers): Projectile | null {
    const speedMult = runModifiers ? runModifiers.speedMultiplier : 1.0;
    this.timer -= (dt * speedMult);
    
    if (this.timer <= 0) {
      const target = this.findTarget(enemies, runModifiers);
      if (target) {
        this.timer = this.cooldown;
        return this.attack(target, runModifiers);
      }
    }
    return null;
  }

  protected findTarget(enemies: Enemy[], runModifiers?: RunModifiers): Enemy | null {
    let nearest: Enemy | null = null;
    const rangeMult = runModifiers ? runModifiers.rangeMultiplier : 1.0;
    let minDist = this.range * rangeMult;

    for (const enemy of enemies) {
      if (!enemy.active) continue;
      
      const dist = this.position.dist(enemy.position);
      if (dist <= minDist) {
        minDist = dist;
        nearest = enemy;
      }
    }

    return nearest;
  }

  protected getCalculatedDamage(runModifiers?: RunModifiers): number {
    const dmgMult = runModifiers ? runModifiers.damageMultiplier : 1.0;
    let finalDamage = this.damage * dmgMult;
    if (Math.random() < this.critChance) {
      return finalDamage * 2; // 2x damage on crit
    }
    return finalDamage;
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers): Projectile {
    return new Projectile(this.position, target, this.getCalculatedDamage(runModifiers));
  }

  public abstract draw(ctx: CanvasRenderingContext2D): void;

  protected drawLevel(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = '#fff';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Lv.${this.level}`, this.position.x, this.position.y - 20);
    if (this.level >= 3) {
      ctx.fillStyle = '#fbbf24'; // Gold star for special ability
      ctx.fillText('★', this.position.x, this.position.y - 30);
    }
    ctx.textAlign = 'left';
  }
}
