import { Tower } from './Tower';
import { Enemy } from './Enemy';
import { BombProjectile } from './BombProjectile';
import { Projectile } from './Projectile';
import { RunModifiers } from '../systems/RunSystem';

export class Bomber extends Tower {
  private enemiesRef: Enemy[];

  constructor(x: number, y: number, enemies: Enemy[]) {
    // range: 120, cooldown: 2.0s, damage: 40
    super(x, y, 120, 2.0, 40);
    this.baseCost = 100;
    this.enemiesRef = enemies;
  }

  protected attack(target: Enemy, runModifiers?: RunModifiers): Projectile {
    const p = new BombProjectile(this.position, target, this.getCalculatedDamage(runModifiers), this.enemiesRef);
    if (this.level >= 3) {
      p.aoeRadius = 120; // Level 3 Special: Huge Explosion
    }
    return p;
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    // Range indicator (faint red)
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.range, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.05)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.2)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.closePath();

    // Tower base
    ctx.fillStyle = '#1e293b'; // Slate-800
    ctx.fillRect(this.position.x - 15, this.position.y - 15, 30, 30);

    // Turret (Bomber - larger red circle)
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 12, 0, Math.PI * 2);
    ctx.fillStyle = '#ef4444'; // Red-500
    ctx.fill();
    ctx.closePath();

    this.drawLevel(ctx);
  }
}
