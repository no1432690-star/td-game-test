import { Projectile } from './Projectile';
import { Enemy } from './Enemy';
import { Vector2 } from '../utils/Vector2';

export class FrostProjectile extends Projectile {
  public slowMultiplier: number = 0.5;
  public slowDuration: number = 2.0;

  constructor(start: Vector2, target: Enemy, damage: number) {
    super(start, target, damage);
    this.speed = 500; // Faster projectile
  }

  public update(dt: number): void {
    if (!this.active) return;
    
    if (!this.target.active) {
      this.active = false;
      return;
    }

    const dir = this.target.position.sub(this.position);
    const dist = dir.mag();

    if (dist < 10) {
      // Apply damage
      this.target.health -= this.damage;
      
      // Apply slow effect
      this.target.applyEffect({ type: 'slow', multiplier: this.slowMultiplier, duration: this.slowDuration });
      
      if (this.target.health <= 0) {
        this.target.active = false;
      }
      this.active = false;
    } else {
      const move = dir.normalize().mult(this.speed * dt);
      this.position = this.position.add(move);
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    if (!this.active) return;
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#60a5fa'; // Blue-400
    ctx.fill();
    ctx.closePath();
  }
}
