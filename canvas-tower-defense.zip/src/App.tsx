/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { Game } from './game/core/Game';
import { GameState } from './game/core/GameState';
import { Play, Pause, FastForward } from 'lucide-react';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize game
    gameRef.current = new Game(canvasRef.current);
    gameRef.current.start();

    // Poll game state for UI updates
    const interval = setInterval(() => {
      if (gameRef.current) {
        setGameState(gameRef.current.getState());
      }
    }, 100);

    // Cleanup
    return () => {
      clearInterval(interval);
      if (gameRef.current) {
        gameRef.current.destroy();
        gameRef.current = null;
      }
    };
  }, []);

  const handleTogglePause = () => {
    if (gameRef.current) {
      gameRef.current.togglePause();
      setGameState(gameRef.current.getState());
    }
  };

  const handleSpeedChange = () => {
    if (gameRef.current && gameState) {
      const newSpeed = gameState.speedMultiplier === 1 ? 2 : 1;
      gameRef.current.setSpeed(newSpeed);
      setGameState(gameRef.current.getState());
    }
  };

  const handleUpgradeChoice = (choiceId: string) => {
    if (gameRef.current) {
      gameRef.current.applyUpgrade(choiceId);
      setGameState(gameRef.current.getState());
    }
  };

  return (
    <div className="w-full h-screen bg-black flex flex-col items-center justify-center overflow-hidden relative font-sans">
      {/* UI Layer */}
      {gameState && (
        <div className="absolute top-0 left-0 w-full p-4 z-10 flex justify-between items-start pointer-events-none">
          {/* Top Left: Resources */}
          <div className="flex gap-4">
            <div className="bg-slate-900/80 backdrop-blur border border-slate-700 rounded-lg px-4 py-2 flex flex-col items-center shadow-lg">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Gold</span>
              <span className="text-amber-400 font-mono text-xl font-bold">{gameState.gold}</span>
            </div>
            <div className="bg-slate-900/80 backdrop-blur border border-slate-700 rounded-lg px-4 py-2 flex flex-col items-center shadow-lg">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Lives</span>
              <span className="text-red-400 font-mono text-xl font-bold">{gameState.lives}</span>
            </div>
          </div>

          {/* Top Center: Wave Info */}
          <div className="bg-slate-900/80 backdrop-blur border border-slate-700 rounded-lg px-6 py-2 flex flex-col items-center shadow-lg">
            <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Wave</span>
            <span className="text-white font-mono text-xl font-bold">
              {gameState.wave}
            </span>
            {!gameState.isWaveActive && !gameState.pendingUpgrades && (
              <span className="text-slate-400 text-xs mt-1">
                Next in {Math.ceil(gameState.waveDelayTimer)}s
              </span>
            )}
          </div>

          {/* Top Right: Controls */}
          <div className="flex gap-2 pointer-events-auto">
            <button 
              onClick={handleTogglePause}
              disabled={!!gameState.pendingUpgrades}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-lg border border-slate-600 transition-colors shadow-lg flex items-center justify-center"
            >
              {gameState.isPaused && !gameState.pendingUpgrades ? <Play size={20} /> : <Pause size={20} />}
            </button>
            <button 
              onClick={handleSpeedChange}
              disabled={!!gameState.pendingUpgrades}
              className={`p-3 rounded-lg border transition-colors flex items-center gap-1 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                gameState.speedMultiplier > 1 
                  ? 'bg-blue-600 hover:bg-blue-500 border-blue-400 text-white' 
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-300'
              }`}
            >
              <FastForward size={20} />
              <span className="font-mono font-bold text-sm">{gameState.speedMultiplier}x</span>
            </button>
          </div>
        </div>
      )}
      
      <div className="relative w-full h-full max-w-7xl max-h-[90vh] aspect-video bg-slate-900 shadow-2xl border border-slate-800 rounded-xl overflow-hidden">
        <canvas
          ref={canvasRef}
          className="block w-full h-full"
        />
        {gameState?.isPaused && !gameState.pendingUpgrades && (
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center pointer-events-none">
            <span className="text-white text-4xl font-bold tracking-widest uppercase">Paused</span>
          </div>
        )}
        
        {/* Upgrade Choices Overlay */}
        {gameState?.pendingUpgrades && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-8 z-50">
            <h2 className="text-3xl font-bold text-white mb-2">Wave Complete!</h2>
            <p className="text-slate-400 mb-8">Choose an upgrade for the next wave</p>
            
            <div className="flex gap-6 max-w-4xl w-full justify-center">
              {gameState.pendingUpgrades.map((upgrade) => (
                <button
                  key={upgrade.id}
                  onClick={() => handleUpgradeChoice(upgrade.id)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 border-2 border-slate-600 hover:border-blue-500 rounded-xl p-6 flex flex-col items-center text-center transition-all hover:scale-105 hover:shadow-xl hover:shadow-blue-900/20 group"
                >
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-400">{upgrade.name}</h3>
                  <p className="text-slate-300">{upgrade.description}</p>
                </button>
              ))}
            </div>
            
            <div className="mt-8 text-slate-500 font-mono">
              Auto-picking in {Math.ceil(gameState.upgradeTimer)}s...
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
